/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__UPLOADWIZARD_H_INCLUDED__)
#define __UPLOADWIZARD_H_INCLUDED__

/* System Headers */

/* Local Headers */
#include "WizardDlg.h"
#ifdef ZOTO_TAGGING
#include "TagPage.h"
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
#include "GalleryPage.h"
#include "NewGalleryPage.h"
#include "TemplatePage.h"
#endif // ZOTO_GALLERIES

/* Macros */

namespace ZOTO
{

class ZOptionsPage;
class ZUserInfo;

/**
 *  @class      ZUploadWizard
 *  @brief      Walks the user through the process of uploading.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		29-Mar-2006
 */
class ZUploadWizard : public ZWizardDlg
{
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZUploadWizard(QWidget *pParent = 0, const char *pName = 0, bool pModal = false, WFlags pFlags = 0);
	virtual ~ZUploadWizard();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
#ifdef ZOTO_TAGGING
	int					GetTagList(QStringList &pTags) const;
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	int					GetGalleryList(QStringList &pGalleries) const;
#endif // ZOTO_GALLERIES

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				Init(ZUserInfo *pInfo);

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected slots:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				OnNext();
	void				OnReady();

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	ZOptionsPage		*mOptions;
#ifdef ZOTO_TAGGING
	ZTagPage			*mTags;
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
	ZGalleryPage		*mGalleries;
	ZNewGalleryPage		*mNewGallery;
	ZTemplatePage		*mTemplates;
#endif // ZOTO_GALLERIES
	ZUserInfo			*pInfo;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

#ifdef ZOTO_TAGGING
/**
 *	Gets the list of selected tags.  Returns the number of tags in the list.
 */
inline
int ZUploadWizard::GetTagList(QStringList &pTags) const
{
	mTags->GetSelectedTags(pTags);
	return pTags.count();
}
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
/**
 *	Gets the list of selected galleries.  Returns the number of
 *	galleries in the list.	
 */
inline
int ZUploadWizard::GetGalleryList(QStringList &pGalleries) const
{
	return mGalleries->GetSelectedGalleries(pGalleries);
}
#endif // ZOTO_GALLERIES

} // End Namespace

#endif // __UPLOADWIZARD_H_INCLUDED__

/* vi: set ts=4: */
