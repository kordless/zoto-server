/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__OPTIONSPAGE_H_INCLUDED__)
#define __OPTIONSPAGE_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qcheckbox.h>
#include <qradiobutton.h>

/* Local Headers */
#include "WizardPage.h"

/* Macros */

namespace ZOTO
{

class ZUserInfo;

/**
 *  @class      ZOptionsPage
 *  @brief      Gives the user the ability to change uploading options.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		05-Dec-2006
 */
class ZOptionsPage : public ZWizardPage
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZOptionsPage(QWidget *pParent = 0, const char *pName = 0, WFlags pFlags = 0);
	virtual ~ZOptionsPage();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	QString				GetMainText() const;
	QString				GetDescText() const;
#ifdef ZOTO_TAGGING
	bool				GetTags() const;
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	bool				GetGalleries() const;
#endif // ZOTO_GALLERIES
	bool				GetRemember() const;

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				Init(ZUserInfo *pInfo);
	void				SetActive(bool pActive);
	void				StoreData();

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected slots:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				Checks(bool on);

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QRadioButton		*mYes;
#ifdef ZOTO_TAGGING
	QCheckBox			*mTags;
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	QCheckBox			*mGalleries;
#endif // ZOTO_GALLERIES
	QRadioButton		*mNo;
	QCheckBox			*mRemember;
	ZUserInfo			*mUserInfo;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

inline
QString ZOptionsPage::GetMainText() const
{
	return tr("User Options");
}

inline
QString ZOptionsPage::GetDescText() const
{
	return tr("Add smart tags, create galleries, or upload all of your photos now!");
}

#ifdef ZOTO_TAGGING
inline
bool ZOptionsPage::GetTags() const
{
	if (mNo->isChecked())
		return false;
	else
		return mTags->isChecked();
}
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
inline
bool ZOptionsPage::GetGalleries() const
{
	if (mNo->isChecked())
		return false;
	else
		return mGalleries->isChecked();
}
#endif // ZOTO_GALLERIES

inline
bool ZOptionsPage::GetRemember() const
{
	return true;
	//return mRemember->isChecked();
}
		
} // End Namespace

#endif // __OPTIONSPAGE_H_INCLUDED__

/* vi: set ts=4: */
