/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__LOGINDLG_H_INCLUDED__)
#define __LOGINDLG_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qdialog.h>
#include <qlineedit.h>
#include <qcombobox.h>
#include <qcheckbox.h>

/* Local Headers */
#include "MD5Hasher.h"

/* Macros */

class QPushButton;

namespace ZOTO
{

class ZURLLabel;

/**
 *  @class      ZLoginDlg
 *  @brief      Prompts the user to login, allowing them to retrieve their password
 *  			or create a new account.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		28-Dec-2005
 */
class ZLoginDlg : public QDialog
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZLoginDlg(QWidget *pParent = 0, const char *pName = 0, bool pModal = false,
					WFlags pFlags = 0);
	virtual ~ZLoginDlg();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	const QString		GetUser() const;
	const QString		GetPswd() const;
	bool				GetAuto() const;

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected slots:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				UserEdited(const QString &pText);
	void				UserChanged(int pIndex);
	void				UserAccepted();
	void				ShowNotImplemented();

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QComboBox			*mUserEdit;
	QLineEdit			*mPswdEdit;
	QCheckBox			*mRemember;
	ZURLLabel			*mForgotUserLink;
	ZURLLabel			*mForgotPswdLink;
	QPushButton			*mLoginButton;
	QPushButton			*mNewButton;
	QPushButton			*mCancelButton;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Gets the username selected in the user box.
 */
inline
const QString ZLoginDlg::GetUser() const
{
	return mUserEdit->currentText();
}

/**
 *	Gets the password entered in the password field.
 */
inline
const QString ZLoginDlg::GetPswd() const
{
	char vHash[33];

	ZMD5Hasher::HashString(mPswdEdit->text().latin1(),
			mPswdEdit->text().length(), vHash, sizeof(vHash));
	return QString(vHash);
}

/**
 *	Returns whether or not the "remember me" box is checked.
 */
inline
bool ZLoginDlg::GetAuto() const
{
	return mRemember->isChecked();
}

} // End Namespace

#endif // __LOGINDLG_H_INCLUDED__

/* vi: set ts=4: */
