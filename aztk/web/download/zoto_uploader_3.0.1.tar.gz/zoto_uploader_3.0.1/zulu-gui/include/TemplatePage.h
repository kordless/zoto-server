/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__TEMPLATEPAGE_H_INCLUDED__)
#define __TEMPLATEPAGE_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qlistbox.h>
#include <qcombobox.h>

/* Local Headers */
#include "WizardPage.h"

/* Macros */

class QListBox;
class QLabel;

namespace ZOTO
{

/**
 *	@class		ZTemplateItem
 *	@brief		Extends to allow each item to hold it's template id/thumbnail.
 *	@author		Josh Williams (josh@zoto.com)
 *	@veraion	0.1.0
 *	@date		31-Mar-2006
 */
class ZTemplateItem : public QListBoxText
{
public:
	ZTemplateItem(QListBox *pParent, const ZTemplateInfo *pInfo)
		: QListBoxText(pParent, pInfo->mName), mInfo(pInfo) {}
	virtual ~ZTemplateItem() {}
	const ZTemplateInfo* GetInfo() { return mInfo; }
private:
	const ZTemplateInfo	*mInfo;
};

/**
 *  @class      ZTemplatePage
 *  @brief      Allows the user to choose a template for a new gallery.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		31-Mar-2006
 */
class ZTemplatePage : public ZWizardPage
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZTemplatePage(QWidget *pParent = 0, const char *pName = 0, WFlags pFlags = 0);
	virtual ~ZTemplatePage();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	QString				GetMainText() const;
	QString				GetDescText() const;
	int					GetSelectedTemplate() const;
	QString				GetSelectedWrapper() const;

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				Init(ZUserInfo *pInfo);
	void				SetActive(bool pActive);
	void				StoreData();

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected slots:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				UpdateThumb(QListBoxItem *pItem);

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QListBox			*mTemplates;
	QLabel				*mTemplLbl;
	QLabel				*mTemplName;
	QLabel				*mThumb;
	QComboBox			*mWrappers;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

inline
QString ZTemplatePage::GetMainText() const
{
	return tr("Template");
}

inline
QString ZTemplatePage::GetDescText() const
{
	return tr("Select A Gallery Style");
}

inline
QString ZTemplatePage::GetSelectedWrapper() const
{
	return mWrappers->currentText();
}

} // End Namespace

#endif // __TEMPLATEPAGE_H_INCLUDED__

/* vi: set ts=4: */
