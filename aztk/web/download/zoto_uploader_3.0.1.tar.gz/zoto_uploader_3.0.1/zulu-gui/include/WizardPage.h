/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__WIZARDPAGE_H_INCLUDED__)
#define __WIZARDPAGE_H_INCLUDED__

/* System Headers */
#include <map>
#include <qwidget.h>

/* Local Headers */
#include "Types.h"

/* Macros */

namespace ZOTO
{

class ZUserInfo;
class ZWizardPage;

/**
 *	@class		PageMaker
 *	@brief		Allow for construction of Wizard pages on the fly.
 *	@author		Josh Williams (josh@zoto.com)
 *	@version	0.1.0
 *	@date		30-Mar_2006
 */
class PageMaker
{
	typedef std::map<QString, PageMaker*>	PageMakerMap;
public:
	PageMaker(const QString &pType)
	{
		get_map()->insert(std::make_pair(pType, this));
	}
	virtual ~PageMaker() {}
	static ZWizardPage* CreatePage(const QString &pType, QWidget *pParent,
			const char *pName, ZUINT pFlags)
	{
		try
		{
			PageMaker *vMaker = get_map()->find(pType)->second;
			if (vMaker)
			{
				return vMaker->MakePage(pParent, pName, pFlags);
			}
			else
			{
				qDebug("Unable to find suitable maker for " + pType);
				return NULL;
			}
		}
		catch (...)
		{
			qDebug("***EXCEPTION***");
			return NULL;
		}
	}

	static PageMakerMap* get_map()
	{
		static PageMakerMap vRegistry;
		return &vRegistry;
	}
protected:
	virtual ZWizardPage*	MakePage(QWidget *pParent, const char *pName, ZUINT pFlags) = 0;
};

/**
 *  @class      ZWizardPage
 *  @brief      Base class for all ZWizardDlg pages.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		27-Mar-2006
 */
class ZWizardPage : public QWidget
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZWizardPage(QWidget *pParent = 0, const char *pName = 0, WFlags pFlags = 0)
		: QWidget(pParent, pName, pFlags) {}

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	virtual QString		GetMainText() const = 0;
	virtual QString		GetDescText() const = 0;

signals:
	void				Ready();
	void				NotReady();
	void				GoNext();

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	virtual void		Init(ZUserInfo *pInfo) = 0;
	virtual void		SetActive(bool pActive) = 0;
	virtual void		StoreData() = 0;

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

} // End Namespace

#endif // __WIZARDPAGE_H_INCLUDED__

/* vi: set ts=4: */
