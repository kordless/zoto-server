/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__NEWGALLERYPAGE_H_INCLUDED__)
#define __NEWGALLERYPAGE_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qlineedit.h>
#include <qtextedit.h>
#include <qradiobutton.h>

/* Local Headers */
#include "WizardPage.h"

/* Macros */

class QLabel;
class QRadioButton;
class QPushButton;

namespace ZOTO
{

/**
 *  @class      ZNewGalleryPage
 *  @brief      Allows the user to create a new gallery.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		11-Jan-2006
 */
class ZNewGalleryPage : public ZWizardPage
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZNewGalleryPage(QWidget *pParent = 0, const char *pName = 0, WFlags pFlags = 0);
	virtual ~ZNewGalleryPage();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	QString				GetMainText() const;
	QString				GetDescText() const;
	QString				GetTitle() const;
	QString				GetName() const;
	QString				GetDesc() const;
	bool				GetPwProtect() const;
	QString				GetPassword() const;


public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				Init(ZUserInfo *pInfo);
	void				SetActive(bool pActive);
	void				StoreData();

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected slots:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				PasswordChecked(bool pOn);
	void				ValidateURL();
	void				TextChanged(const QString &pText);
	void				CheckIfReady();

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QLineEdit			*mTitle;
	QLabel				*mURLLbl2;
	QLineEdit			*mURL;
	QTextEdit			*mDesc;
	QRadioButton		*mPublic;
	QRadioButton		*mPrivate;
	QLineEdit			*mPswd;
	ZUserInfo			*mUserInfo;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

inline
QString ZNewGalleryPage::GetMainText() const
{
	return tr("New Gallery");
}

inline
QString ZNewGalleryPage::GetDescText() const
{
	return tr("Create A Title & Description For Your Gallery");
}

inline
QString ZNewGalleryPage::GetTitle() const
{
	return mTitle->text();
}

inline
QString ZNewGalleryPage::GetName() const
{
	return mURL->text();
}

inline
QString ZNewGalleryPage::GetDesc() const
{
	return mDesc->text();
}

inline
bool ZNewGalleryPage::GetPwProtect() const
{
	return mPrivate->isChecked();
}

inline
QString ZNewGalleryPage::GetPassword() const
{
	return mPswd->text();
}

} // End Namespace

#endif // __NEWGALLERYPAGE_H_INCLUDED__

/* vi: set ts=4: */
