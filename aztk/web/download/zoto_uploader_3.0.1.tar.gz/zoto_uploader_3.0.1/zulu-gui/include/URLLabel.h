/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__URLLABEL_H_INCLUDED__)
#define __URLLABEL_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qlabel.h>

/* Local Headers */

/* Macros */

namespace ZOTO
{

/**
 *  @class      ZURLLabel
 *  @brief      Label to allow a URL to be included in a dialog.
 *  @author     Josh Williams (josh@zoto.com)
 *  @date		24-Apr-2005
 *  @version    0.1.0
 */
class ZURLLabel : public QLabel
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZURLLabel(const QColor &pNormal, const QColor& pActive, QWidget *pParent, const char *pName, WFlags pFlags = 0);
	~ZURLLabel();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
signals:
	void				Clicked();

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				setText(const QString& pText);
	void				SetColors(const QColor& pNormal, const QColor& pActive);
	void				SetURL(const QString& pURL);

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				enterEvent(QEvent *pEvt);
	void				leaveEvent(QEvent *pEvt);
	void				mouseMoveEvent(QMouseEvent *pEvt);
	void				mouseReleaseEvent(QMouseEvent *pEvt);
	void				resizeEvent(QResizeEvent *pEvent);

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	void				CalculateHitBox(const QSize& vSize);
	void				SetMouseOver();
	void				SetMouseOut();

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QColor				mNormalColor;	/**< Color used when the label is displayed */
	QColor				mActiveColor;	/**< Color used when the label is moused over */
	QString				mURL;			/**< URL used when label is clicked */
	QRect				mHitBox;		/**< Rectangle that will recieve mouse events */
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Sets the colors used for the two states of the label.
 */
inline
void ZURLLabel::SetColors(const QColor& pNormal, const QColor& pActive)
{
	mNormalColor = pNormal;
	mActiveColor = pActive;
}

/**
 *	Sets the URL to be navigated to when the label is clicked.
 */
inline
void ZURLLabel::SetURL(const QString& pURL)
{
	mURL = pURL;
}

} // End Namespace

#endif // __URLLABEL_H_INCLUDED__

/* vi: set ts=4: */
