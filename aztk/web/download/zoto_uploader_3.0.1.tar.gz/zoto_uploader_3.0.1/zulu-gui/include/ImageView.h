/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__IMAGEVIEW_H_INCLUDED__)
#define __IMAGEVIEW_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qiconview.h>

/* Local Headers */
#include "Types.h"

/* Macros */
#define BORDER_WIDTH	3
#define BORDER_COLOR	QColor(192, 187, 187)
#define SELECTED_COLOR	QColor(140, 197, 66)

namespace ZOTO
{

class ZImageViewItem;

/**
 *  @class      ZImageView
 *  @brief      Widget to allow user to select images for upload.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 */
class ZImageView : public QIconView
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZImageView(QWidget *pParent = 0, const char *pName = 0, WFlags pFlags = 0);
	virtual ~ZImageView();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	int					GetThumbWidth() const;
	int					GetThumbHeight() const;

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				AddFile(const ZFileInfo &pFile);
	void				RemoveFile(ZULONG pFile);
	ZImageViewItem*		FindByKey(ZULONG pKey);	
signals:
	void				CountChanged(int pCount);
	void				SelectionCount(int pCount);

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	virtual void		drawContents(QPainter *p, int clipx, int clipy, int clipw, int cliph);
	virtual void		customEvent(QCustomEvent *evt);	

public slots:
	virtual void		resizeEvent(QResizeEvent *pEvt);
	virtual void		dropEvent(QDropEvent *pEvt, const QValueList<QIconDragItem> &pList);
	virtual void		keyPressEvent(QKeyEvent *pEvt);
	virtual void		contentsMouseReleaseEvent(QMouseEvent *pEvt);
	virtual void		drawPopupMenu(QIconViewItem *pItem, const QPoint &pPos);
	void				ClearAll();
	void				DeleteSelectedItems();
	void				RotateSelectedItems();
	void				UpdateSelection();

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QPixmap				*mDefaultPix;	/**< Default pixmap ("loading...") */
	QPixmap				*mCenter;		/**< Pixmap displayed when no images loaded */
	QSize				mCenterSize;	/**< Size of the center pixmap */
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Return the maximum width for thumbnails.
 */
inline
int ZImageView::GetThumbWidth() const
{
	return gridX() - (spacing() * 2);
}

/**
 *	Return the maximum height for thumbnails.
 */
inline
int ZImageView::GetThumbHeight() const
{
	return gridY() - (spacing() * 2);
}

} // End Namespace

#endif // __IMAGEVIEW_H_INCLUDED__

/* vi: set ts=4: */
