/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__UPLOADBATCH_H_INCLUDED__)
#define __UPLOADBATCH_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qframe.h>
#include <qlabel.h>
#include <qprogressbar.h>
#include <qwaitcondition.h>
#include <qwidgetstack.h>

/* Local Headers */
#include "Types.h"
#include "Events.h"


/* Macros */

class QPushButton;

namespace ZOTO
{

class ZURLLabel;
class ZXferInfo;
class ZZSPThread;
class ZZAPIThread;
class ZClient;

typedef QValueList<int> ZCatIDList;

enum ZBatchStatus
{
	BATCH_PENDING,
	BATCH_ACTIVE,
	BATCH_PAUSED,
	BATCH_COMPLETE,
	BATCH_CLOSED,
	BATCH_CANCELLED,
	BATCH_FAILED
};

/**
 *  @class      ZUploadBatch
 *  @brief      Manages a single upload batch.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		13-Jan-2006
 *
 *	@remarks	Handles managing the actual upload, as well as displaying
 *				progress information on the screen.
 */
class ZUploadBatch : public QWidgetStack
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZUploadBatch(const ZFileList &pFiles, ZULONG pTotalBytes,
			QWidget *pParent = 0, const char *pName = 0, WFlags pFlags = 0);
	virtual ~ZUploadBatch();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	ZULONG				GetId() const;
	const ZFileList&	GetFiles() const;

signals:
	void				StatusChanged(ZULONG pId, ZBatchStatus pStatus);

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
#ifdef ZOTO_TAGGING
	void				SetTags(QStringList &pTagList);
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	void				SetGalleries(QStringList &pGalleries);
#endif // ZOTO_GALLERIES
	void				SetTotalSteps(ZULONG pSteps);
	void				SetCurrThumb(QPixmap *pThumb);
	void				SetCount(const QString &pCount);
	void				SetCurrFile(const QString &pFile);
	void				SetCurrSize(const QString &pSize);
	void				SetCurrPercent(const QString &pPercent);
	void				SetSpeed(const QString &pSpeed);
	void				SetProgress(const ZULONG pProgress);
	void				SetActive();

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				customEvent(QCustomEvent *pEvt);
public:
	void				StatusUpdate(ZSPEvent *pInfo);
public slots:
	void				CancelBatch();
	void				PauseResumeBatch();

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	void				CreateActivePage(const QFont &pTextFont, const QFont &pButtonFont,
											ZUSHORT pWidth);
	void				CreateFinishedPage(const QFont &pTextFont, const QFont &pButtonFont,
											ZUSHORT pWidth);
	void				SwitchFile(const ZFileInfo &pInfo, ZUINT pFile);
	void				FinalizeUpload(ZSPEvent *pInfo, ZULONG pKey);
	void				SetComplete();
	void				StartNextUpload();
	void				UpdateDisplay(float pCurrPerc, float pSpeed);
	void				Rotate(const QString &pMD5, int pCount);
#ifdef ZOTO_TAGGING
	void				Tag(const QString &pMD5);
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	void				Galleryize();
#endif // ZOTO_GALLERIES

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QLabel				*mCurrThumb;
	QLabel				*mCount;
	QLabel				*mCurrFile;
	QLabel				*mCurrPercent;
	QLabel				*mSpeed;
	QProgressBar		*mProgress;
	ZURLLabel			*mPauseResume;
	QLabel				*mPCsep;
	ZURLLabel			*mView;
	ZURLLabel			*mCancel;
	ZZSPThread			*mZSPThread;
	ZZAPIThread			*mZAPIThread;
	ZClient				*mClient;

	ZULONG				mID;			/**< Unique identifier for thie batch */
	ZFileList			mFiles;			/**< List of files to be uploaded */
#ifdef ZOTO_TAGGING
	QStringList			mTags;			/**< Tags to apply to the photos */
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	QStringList			mGalleryImgs;	/**< Image ID's to add to galleries */
	QStringList			mGalleries;		/**< Galleries to add the photos to */
#endif // ZOTO_GALLERIES
	ZULONG				mTotalBytes;	/**< Total bytes to be uploaded. */
	ZULONG				mUploadBytes;	/**< Total bytes uploaded for the batch */
	ZULONG				mCurrentBytes;	/**< Bytes uploaded for the current file. */
	ZUINT				mCurrentFile;	/**< Index of the current file in mFiles. */
	ZUINT				mTotalFiles;	/**< Total files to be uploaded */
	ZBatchStatus		mStatus;		/**< Current state of upload */
#ifdef ZOTO_TAGGING
	int					mTagStatus;		/**< Status of the last tagging operation. */
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	int					mGalleryStatus;
#endif // ZOTO_GALLERIES
	QSize				mThumbSize;		/**< Global thumbnail size. */
	static QString		mDoneMessages[];
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

inline
ZULONG ZUploadBatch::GetId() const
{
	return mID;
}

inline
const ZFileList& ZUploadBatch::GetFiles() const
{
	return mFiles;
}

#ifdef ZOTO_TAGGING
inline
void ZUploadBatch::SetTags(QStringList &pTagList)
{
	mTags = pTagList;
}
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
inline
void ZUploadBatch::SetGalleries(QStringList &pGalleries)
{
	mGalleries = pGalleries;
}
#endif // ZOTO_GALLERIES

inline
void ZUploadBatch::SetTotalSteps(ZULONG pSteps)
{
	mProgress->setTotalSteps(pSteps);
}

inline
void ZUploadBatch::SetCurrThumb(QPixmap *pThumb)
{
	mCurrThumb->setPixmap(*pThumb);
}

inline
void ZUploadBatch::SetCount(const QString &pCount)
{
	mCount->setText(pCount);
}

inline
void ZUploadBatch::SetCurrFile(const QString &pFile)
{
	mCurrFile->setText(pFile);
}

inline
void ZUploadBatch::SetCurrPercent(const QString &pPercent)
{
	mCurrPercent->setText(pPercent);
}

inline
void ZUploadBatch::SetSpeed(const QString &pSpeed)
{
	mSpeed->setText(pSpeed);
}

inline
void ZUploadBatch::SetProgress(const ZULONG pProgress)
{
	mProgress->setProgress(pProgress);
	mProgress->update();
}

} // End Namespace

#endif // __UPLOADBATCH_H_INCLUDED__

/* vi: set ts=4: */
