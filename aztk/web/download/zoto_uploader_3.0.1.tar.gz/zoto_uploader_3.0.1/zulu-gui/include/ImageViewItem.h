/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__IMAGEVIEWITEM_H_INCLUDED__)
#define __IMAGEVIEWITEM_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qiconview.h>
#include <qfileinfo.h>

/* Local Headers */
#include "Types.h"

namespace ZOTO
{

/**
 *  @class      ZImageViewItem
 *  @brief      Handles drawing of an image selected for upload in the view.
 *  @author     Josh Williams
 *  @version    0.1.0
 *  @date		01-Apr-2005
 */
class ZImageViewItem : public QIconViewItem
{
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZImageViewItem(QIconView *pParent, const QString& pURI, int pID);
	virtual ~ZImageViewItem();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	QPixmap*			pixmap() const;
	int					GetID() const;
	ZULONG				GetKey() const;

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				setPixmap(const QPixmap& pIcon);
	void				setText(const QString& pText);
	void				SetKey(ZULONG pKey);
	void				RotateThumb();

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	virtual void		paintItem(QPainter *pPainter, const QColorGroup& pCg);
	virtual void		paintFocus(QPainter *pPainter, const QColorGroup& pCg);
	virtual void		calcRect(const QString& pText);
	void				dropped(QDropEvent *pEvt, const QValueList<QIconDragItem>& pList);

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	void				UpdateItemRect();

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	static int			mBorderWidth;	/**< full width of the border */
	QFileInfo   		mFileInfo;		/**< information about the current file */
	QPixmap				*mThumb;		/**< current thumbnail */
	int					mID;			/**< unique identifier of this icon */
	ZULONG				mKey;			/**< Hashed/XOR'd key for this file */
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Returns the pixmap (thumbnail) associated with this item.
 */
inline
QPixmap* ZImageViewItem::pixmap() const
{
	return mThumb;
}

/**
 *	Gets the internal ID associated with this item.
 */
inline
int ZImageViewItem::GetID() const
{
	return mID;
}

/**
 *	Returns the key (file name MD5) of the image represented by
 *	this item.
 */
inline
ZULONG ZImageViewItem::GetKey() const
{
	return mKey;
}

/**
 *	Sets the file hash of this item.
 */
inline
void ZImageViewItem::SetKey(ZULONG pKey)
{
	mKey = pKey;
}

/**
 *	Overridden to prevent Qt from trying to control focus painting.
 */
inline
void ZImageViewItem::paintFocus(QPainter *pPainter, const QColorGroup& pCg)
{
	Q_UNUSED(pPainter);
	Q_UNUSED(pCg);
}

} // End Namespace

#endif // __IMAGEVIEWITEM_H_INCLUDED__

/* vi: set ts=4: */

