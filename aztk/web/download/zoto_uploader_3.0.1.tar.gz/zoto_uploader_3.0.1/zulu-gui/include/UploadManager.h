/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__UPLOADMANAGER_H_INCLUDED__)
#define __UPLOADMANAGER_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qframe.h>
#include <map>

/* Local Headers */
#include "Types.h"
#include "UploadBatch.h"

/* Macros */

class QVBoxLayout;

namespace ZOTO
{

typedef std::map<ZULONG, ZUploadBatch *> ZUploadQueue;

/**
 *  @class      ZUploadManager
 *  @brief		Manages all currently queued uploads.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		12-Jan-2006
 */
class ZUploadManager : public QFrame
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZUploadManager(QWidget *pParent = 0, const char *pName = 0, WFlags pFlags = 0);
	virtual ~ZUploadManager();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	static ZUploadBatch*	GetCurrentBatch();

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				AddBatch(const ZFileList &pFiles, ZULONG pTotalBytes,
									QStringList &pTagList, QStringList &vGalleries);

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected slots:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				BatchUpdate(ZULONG pID, ZBatchStatus pStatus);

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	void				StartBatch(ZUploadBatch *pBatch);

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	static ZUploadBatch	*smCurrentBatch;
	ZUploadQueue		mPendingBatches;
	ZUploadQueue		mCompletedBatches;
	QFrame				*mWidgetFrame;
	QVBoxLayout			*mWidgetLayout;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

inline
ZUploadBatch* ZUploadManager::GetCurrentBatch()
{
	return smCurrentBatch;
}

} // End Namespace

#endif // __UPLOADMANAGER_H_INCLUDED__

/* vi: set ts=4: */
