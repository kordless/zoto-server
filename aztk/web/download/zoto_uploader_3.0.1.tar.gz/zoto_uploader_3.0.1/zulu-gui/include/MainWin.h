/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__MAINWIN_H_INCLUDED__)
#define __MAINWIN_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qmainwindow.h>
#include <qpopupmenu.h>

/* Local Headers */
#include "Utils.h"
#include "Globals.h"

/* Macros */

class QVBox;
class QToolButton;
class QPushButton;
class QLabel;

namespace ZOTO
{

class ZImageView;
class ZURLLabel;
class ZUploadManager;

/**
 *  @class      ZMainWin
 *  @brief      Main window of the Zoto Uploader application.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 */
class ZMainWin : public QMainWindow
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZMainWin(QWidget *pParent = 0, const char *pName = 0, WFlags pFlags = WType_TopLevel);
	virtual ~ZMainWin();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	ZImageView*			GetImageView() const;
	ZUploadManager*		GetUploadManager();

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				SwitchUser();
	void				UpdateStatus(const ZUserInfo *vInfo);

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected slots:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				AddImages();
	void				DeleteImages();
	void				RotateImages();
	void				GoToZotoCom();
	void				TestOptions();
#ifdef ZOTO_TAGGING
	void				TestTags();
#else
	void				TestTags() {}
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	void				TestGallery();
	void				TestNewGallery();
	void				TestTemplates();
#else
	void				TestGallery() {}
	void				TestNewGallery() {}
	void				TestTemplates() {}
#endif // ZOTO_GALLERIES
	void				ShowFonts();
	void				ShowPrefs();
	void				UpdateButtons(int pCount);
	void				UpdateSelection(int pCount);

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	bool				CreateToolbar();
	bool				CreateButtonFrame(QVBox *pParent);
	void				ShowTestDialog(const QString &pType);

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	ZImageView			*mImageView;	/**< Widget for drag/drop of images */
	QVBox				*mLblBox;		/**< Box containing all the user specific information */
	QLabel				*mUserLbl;		/**< Logged in as label */
	ZURLLabel			*mURLLabel;		/**< Link to user's homepage */
	QLabel				*mUsage;		/**< Current usage information */
	QPushButton			*mUploadBtn;	/**< Button to start the upload process */
	ZUploadManager		*mUploadMgr;
	QToolButton			*mImgAdd;
	QToolButton			*mImgRem;
	QToolButton			*mImgRot;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Returns the image view widget.
 */
inline
ZImageView* ZMainWin::GetImageView() const
{
	return mImageView;
}

inline
ZUploadManager* ZMainWin::GetUploadManager()
{
	return mUploadMgr;
}

inline
void ZMainWin::TestOptions()
{
	ShowTestDialog("ZOptionsPage");
}

#ifdef ZOTO_TAGGING
inline
void ZMainWin::TestTags()
{
	ShowTestDialog("ZTagPage");
}
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
inline
void ZMainWin::TestGallery()
{
	ShowTestDialog("ZGalleryPage");
}

inline
void ZMainWin::TestNewGallery()
{
	ShowTestDialog("ZNewGalleryPage");
}

inline
void ZMainWin::TestTemplates()
{
	ShowTestDialog("ZTemplatePage");
}
#endif // ZOTO_GALLERIES

} // End Namespace

#endif // __MAINWIN_H_INCLUDED__

/* vi: set ts=4: */
