/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__STATUSAREA_H_INCLUDED__)
#define __STATUSAREA_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qwidget.h>
#include <qlabel.h>

/* Local Headers */
#include "Types.h"

/* Macros */

namespace ZOTO
{

class ZURLLabel;

/**
 *  @class      ZStatusArea
 *  @brief      Small class to allow us add more complex stuff to the status area in
 *  			the main window.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 */
class ZStatusArea : public QWidget
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZStatusArea(QWidget *pParent = 0, const char *pName = 0, WFlags pFlags = 0);
	virtual ~ZStatusArea();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				SetUsageQuota(ZULONG pUsage, ZULONG pQuota);
	void				SetPhotoCount(ZULONG pPhotos);
	void				SetAccountType(const QString &pType);
	void				Clear();

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	void				RedrawStatus();

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QLabel				*mStatus;
	ZURLLabel			*mUpgrade;

	ZULONG				mUsage;
	ZULONG				mQuota;
	ZULONG				mPhotos;
	QString				mType;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Sets the internal usage and quota variables and redraws the status
 *	text.
 */
inline
void ZStatusArea::SetUsageQuota(ZULONG pUsage, ZULONG pQuota)
{
	mUsage = pUsage;
	mQuota = pQuota;

	RedrawStatus();
}

/**
 *	Sets the internal photo count and redraws the status text.
 */
inline
void ZStatusArea::SetPhotoCount(ZULONG pPhotos)
{
	mPhotos = pPhotos;

	RedrawStatus();
}

/**
 *	Sets the account type text and redraws the status text.
 */
inline
void ZStatusArea::SetAccountType(const QString &pType)
{
	mType = pType;

	RedrawStatus();
}

} // End Namespace

#endif // __STATUSAREA_H_INCLUDED__

/* vi: set ts=4: */
