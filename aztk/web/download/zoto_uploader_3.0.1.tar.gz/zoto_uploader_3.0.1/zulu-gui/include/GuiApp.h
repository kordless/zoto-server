/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__GUIAPP_H_INCLUDED__)
#define __GUIAPP_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qptrqueue.h>

/* Local Headers */
#include "App.h"
#include "Events.h"

/* Macros */
#define ZULU_GUI_APP()	static_cast<ZGuiApp*>(qApp)

namespace ZOTO
{

class ZImageThread;
class ZUploadManager;

/**
 *  @class      ZGuiApp
 *  @brief      GUI version of the application wrapper.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		19-Dec-2005
 */
class ZGuiApp : public ZApp
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZGuiApp(int &argc, char **argv);
	virtual ~ZGuiApp();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	const QString&		GetLastBrowse() const;
	const QString&		GetLastFormat() const;
	const QString		GetWindowCaption();

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				StartThread();
	bool				Initialize();
	void				Shutdown();
	bool				Authenticate(bool pForcePrompt = false);
	ZRESULT				ConnectAndAuth(QString& pUser, QString& pPswdHash);	
	bool				AddFile(const QString& pURI);
	void				RemoveFile(ZULONG pID);
	void				RotateFile(ZULONG pID);
#if ZULU_PLATFORM == PLATFORM_WINDOWS
	bool				winEventFilter(MSG *);
#endif
	bool				PreviousInstance(int& argc, char **argv);
	void    			SetLastBrowse(const QString& pDir);
	void				SetLastFormat(const QString& pExt);
	static int			ShowCommError(const QString &pCaption = "");

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
public slots:
	void				Reset();
	void				CreateBatch();

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	ZULONG				CreateKey(const QString& pFileName);
	int					ShowUpgradeMessage(bool pRequired, const QString &pVersion);
	void				Upgrade();

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QString         	mLastBrowse;	/**< Last folder browsed in the main window */
	QString				mLastFormat;	/**< Last format (extension) selected by the user */
	ZFileList			mFiles;			/**< List of files currently available for upload */
	ZULONG				mTotalBytes;	/**< Total size of files to be uploaded */
	ZImageThread		*mThread;		/**< Thread to handle creating thumbnails */
	bool				mVersionOk;
	ZULONG				mPhotoCount;	/**< Global count of photos added to the image view
										  	 This is used to assign a unique index to each
											 image so the list of images can be uploaded
											 in order. */
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Returns the last directory browsed for images in the main window.
 */
inline
const QString& ZGuiApp::GetLastBrowse() const
{
	return mLastBrowse;
}

/**
 *	Returns the last format (extension) browsed by the user.
 */
inline
const QString& ZGuiApp::GetLastFormat() const
{
	return mLastFormat;
}

/**
 *	Stores the last directory the user browsed for images in the
 *	main window.
 */
inline
void ZGuiApp::SetLastBrowse(const QString& pDir)
{
	mLastBrowse = pDir;
}

/**
 *	Stores the last format (extension) browsed by the user.
 */
inline
void ZGuiApp::SetLastFormat(const QString& pFormat)
{
	mLastFormat = pFormat;
}

} // End Namespace

#endif // __GUIAPP_H_INCLUDED__

/* vi: set ts=4: */

