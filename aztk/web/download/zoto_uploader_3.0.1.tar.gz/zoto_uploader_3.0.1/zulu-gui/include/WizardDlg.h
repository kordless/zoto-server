/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__WIZARDDLG_H_INCLUDED__)
#define __WIZARDDLG_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qdialog.h>
#include <qptrlist.h>
#include <qwidgetstack.h>
#include <qpushbutton.h>

/* Local Headers */

/* Macros */

class QLabel;

namespace ZOTO
{

class ZUserInfo;
//class ZHeaderBar;
class ZWizardPage;

enum ePages
{
	PAGE_OPTIONS = 1,
	PAGE_TAGS,
#ifdef ZOTO_GALLERIES
	PAGE_GALLERIES,
	PAGE_NEW_GALLERY
#endif
};

/**
 *  @class      ZWizardDlg
 *  @brief      Allows stepping through the various upload options.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		27-Mar-2006
 */
class ZWizardDlg : public QDialog
{
	class Page
	{
	public:
		Page(ZWizardPage *pPage, int pId, bool pAppropriate)
			: mWidget(pPage), mId(pId), mAppropriate(pAppropriate) {}
		ZWizardPage	*mWidget;
		int			mId;
		bool		mAppropriate;
	};
	typedef QPtrList<Page> ZPageList;

	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZWizardDlg(QWidget *pParent = 0, const char *pName = 0, bool pModal = false, WFlags pFlags = 0);
	virtual ~ZWizardDlg();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	int					GetPageCount() const;
	ZWizardPage*		GetCurrentPage() const;

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				show();
	int					Execute();
	virtual int			AddPage(ZWizardPage *pPage);
	virtual void 		ShowPage(ZWizardPage *pPage);
	virtual void		SetAppropriate(ZWizardPage *pPage, bool pAppropriate);

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	void				SetNextText(const QString &pText);
public slots:
	virtual void		OnNext();
	virtual void		OnBack();
	virtual void		OnReady();
	virtual void		OnNotReady();

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	Page*				FindPage(ZWizardPage *pPage);

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	int					mPageCount;
	Page*				mCurPage;
	QLabel				*mHeader;

	QWidgetStack		*mStack;

	ZPageList			mPages;

	QPushButton			*mBack;
	QPushButton			*mNext;
	QPushButton			*mCancel;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Gets the number of pages this wizard will display.
 */
inline
int ZWizardDlg::GetPageCount() const
{
	return mPageCount;
}

/**
 *	Gets the currently displayed wizard page.
 */
inline
ZWizardPage* ZWizardDlg::GetCurrentPage() const
{
	if (mCurPage)
		return mCurPage->mWidget;
	else
		return NULL;
}

/**
 *	Sets the text to be displayed on the Next button.
 */
inline
void ZWizardDlg::SetNextText(const QString &pText)
{
	mNext->setText(pText);
}

} // End Namespace

#endif // __WIZARDDLG_H_INCLUDED__

/* vi: set ts=4: */
