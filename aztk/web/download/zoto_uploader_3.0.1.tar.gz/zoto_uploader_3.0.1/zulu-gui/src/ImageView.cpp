/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "ImageView.h"

/* System Headers */
#include <qpainter.h>
#include <qmessagebox.h>
#include <qfileinfo.h>
#include <qpopupmenu.h>

/* Local Headers */
#include "GuiApp.h"
#include "Utils.h"
#include "ImageViewItem.h"
#include "Events.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZImageView::ZImageView(QWidget *pParent /*=0*/, const char *pName/*=0*/, WFlags pFlags /*=0*/)
	: QIconView(pParent, pName, pFlags)
{
	this->setResizeMode(Adjust);
	//this->setBackgroundMode(Qt::NoBackground);
	this->setGridX(110);
	this->setGridY(110);
	this->setItemsMovable(false);
	this->setSelectionMode(Extended);
	this->setFrameStyle(QFrame::NoFrame);


	/*
	 * Load the images for the empty view.
	 */
	mDefaultPix = new QPixmap(QPixmap::fromMimeSource("loading.png"));
	mCenter = new QPixmap(QPixmap::fromMimeSource("center.png"));
	mCenterSize = mCenter->size();

	/*
	 * Mask the center image so it doesn't obscure the flowers.
	 */
	QImage vImg(mCenter->convertToImage());
	QBitmap vBitmap;
	if (!mCenter->mask())
	{
		if (vImg.hasAlphaBuffer())
		{
			vBitmap = vImg.createAlphaMask();
			mCenter->setMask(vBitmap);
		}
		else
		{
			vBitmap = vImg.createHeuristicMask();
			mCenter->setMask(vBitmap);
		}
	}

	/*
	 * Signals and slots
	 */
	connect(this, SIGNAL(dropped(QDropEvent *, const QValueList<QIconDragItem>&)),
			this, SLOT(dropEvent(QDropEvent *, const QValueList<QIconDragItem>&)));
    connect(this, SIGNAL( contextMenuRequested(QIconViewItem*,const QPoint&) ),
			this, SLOT( drawPopupMenu(QIconViewItem*,const QPoint&) ));
	connect(this, SIGNAL( selectionChanged()), this, SLOT(UpdateSelection()));
}

ZImageView::~ZImageView()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								AddFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Adds the specified file to the list of displayed
 *				images.
 *
 *	@author		Josh Williams
 *	@date		07-Apr-2005
 *
 *	@param		pFile
 *					Object containing info about the file.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::AddFile(const ZFileInfo& pFile)
{
	QFileInfo		vFileInfo;
	ZImageViewItem	*vIvi;
	QStringList		vInvalid;

	vIvi = new ZImageViewItem(this, pFile.mName, pFile.mKey);
	vIvi->setPixmap(*mDefaultPix); // stock "Loading..." pixmap
	vIvi->SetKey(pFile.mKey);
	repaintItem(vIvi);
	emit CountChanged(this->count());
}

void ZImageView::RemoveFile(ZULONG pFile)
{
	ZImageViewItem *vIvi = FindByKey(pFile);
	if (vIvi != NULL)
	{
		delete vIvi;
	}
	arrangeItemsInGrid();
	updateContents();
	emit CountChanged(this->count());
}

/*------------------------------------------------------------------*
 *								FindByKey()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Attempts to locate the item based on the supplied
 *				unique identifier.
 *
 *	@author		Josh Williams
 *	@date		07-Apr-2005
 *
 *	@param		pID
 *					Unique identifier to search for
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
ZImageViewItem*	ZImageView::FindByKey(ZULONG pKey)
{
	ZImageViewItem *vIvi, *vRet = NULL;
	vIvi = static_cast<ZImageViewItem *>(firstItem());
	while (vIvi)
	{
		if (vIvi->GetKey() == pKey)
		{
			vRet = vIvi;
			break;
		}
		vIvi = static_cast<ZImageViewItem*>(vIvi->nextItem());
	}
	return vRet;
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								FindByID()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Attempts to locate the item based on the supplied
 *				unique identifier.
 *
 *	@author		Josh Williams
 *	@date		07-Apr-2005
 *
 *	@param		pID
 *					Unique identifier to search for
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::drawContents(QPainter *pPainter, int pClipX, int pClipY, int pClipW, int pClipH)
{
	static QPixmap	vBuffer;
	static QRect	vRect;
	static QPainter	vPainter;
	
	if (count() > 0)
	{
		/*
		 * Default implementation.
		 */
		QIconView::drawContents(pPainter, pClipX, pClipY, pClipW, pClipH);
	}
	else
	{
		/*
		 * Display a pretty background.  Meh.
		 */
		vRect = this->rect();	
		
		vBuffer.resize(vRect.size());	
		vBuffer.fill(Qt::white);
		vPainter.begin(&vBuffer);
	
		vPainter.drawPixmap(QRect((vRect.width() - mCenterSize.width()) / 2,
					(vRect.height() - mCenterSize.height()) / 2,
					mCenterSize.width(), mCenterSize.height()), *mCenter);
		vPainter.end();
		pPainter->drawPixmap(QRect(0, 0, vRect.width(), vRect.height()), vBuffer);
	}
}


/*------------------------------------------------------------------*
 *							resizeEvent()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Overridden to force redrawing of hint text on window
 *				resize so the text is centered.
 *
 *	@author		Josh Williams
 *	@date		26-Apr-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::resizeEvent(QResizeEvent *pEvt)
{
	QIconView::resizeEvent(pEvt);
	if (count() <= 0)
		viewport()->update();
}

/*------------------------------------------------------------------*
 *								dropEvent()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Called when the user drags a file and drops it onto
 *				the view.
 *
 *	@author		Josh Williams
 *	@date		02-Apr-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::dropEvent(QDropEvent *pEvt, const QValueList<QIconDragItem>& pList)
{
    QStringList vFileNames;
	QStringList::iterator vIt;
	Q_UNUSED(pList);
	QStringList	vInvalid;
	QStringList vValid;

	/*
	 * Process the list of files dropped on the image view.
	 */
	WAIT_CURSOR_ON();
	if (QUriDrag::decodeLocalFiles(pEvt, vFileNames))
	{
		for (vIt = vFileNames.begin(); vIt != vFileNames.end(); vIt++)
		{
			qDebug("%s::Dropped file %s", __FILE__, (*vIt).latin1());
			if (ZULU_GUI_APP()->AddFile((*vIt)) != true)
				vInvalid.append(*vIt);
		}
	}
	WAIT_CURSOR_OFF();

	/*
	 * Inform the user of any files that could not be processed.
	 */
	if (vInvalid.count() > 0)
	{
		QString vMsg = tr("The following files were not valid:\n");
		for (ZUINT i = 0; i < vInvalid.count(); i++)
		{
			vMsg += vInvalid[i];
			vMsg += "\n";
		}
		QMessageBox::warning(ZULU_GUI_APP()->mainWidget(), ZULU_GUI_APP()->GetAppName(), vMsg);
	}
}

/*------------------------------------------------------------------*
 *							keyPressEvent()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Overridden to intercept delete key presses for removing
 *				images from the view.
 *
 *	@author		Josh Williams
 *	@date		26-Apr-2005
 *
 *	@param		pEvt
 *					The actual event.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::keyPressEvent(QKeyEvent *pEvt)
{
	if (pEvt->key() == Qt::Key_Delete)
	{
		DeleteSelectedItems();
	}
	else
		pEvt->ignore();
}

/*------------------------------------------------------------------*
 *						contentsMouseReleaseEvent()					*
 *------------------------------------------------------------------*/
/**
 *	@brief		Overridden so right-mouse button clicks do not alter
 *				image selection.
 *
 *	@author		Josh Williams
 *	@date		26-Apr-2005
 *
 *	@param		pEvt
 *					The actual event.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::contentsMouseReleaseEvent(QMouseEvent *pEvt)
{
	if (pEvt->button() == LeftButton)
		QIconView::contentsMouseReleaseEvent(pEvt);
}

/*------------------------------------------------------------------*
 *							drawPopupMenu()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Signaled when the user right-clicks on an image.
 *
 *	@author		Josh Williams
 *	@date		02-Apr-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::drawPopupMenu(QIconViewItem *pItem, const QPoint& pPos)
{
	ZImageViewItem *vIvi;
	if (pItem != NULL)
	{		
		if ((vIvi = static_cast<ZImageViewItem *>(pItem)) != NULL)
		{
			QPopupMenu vPopup(this);
			vPopup.insertItem(tr("Remove"), this, SLOT(DeleteSelectedItems()) );
			vPopup.exec(pPos);
		}
	}
}

/*------------------------------------------------------------------*
 *							customEvent()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Handles Zoto defined window events.
 *
 *	@author		Josh Williams
 *	@date		02-Apr-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::customEvent(QCustomEvent *pEvt)
{
	qDebug("Received customEvent");
	if (pEvt->type() == ZIMAGELOAD)
	{
		qDebug("Received image load event");
		/*
		 * This is a notification from the image thread
		 */
		ZImageThreadEvent *pImgEvt = static_cast<ZImageThreadEvent *>(pEvt);
		ZULONG vKey = pImgEvt->Key();
		QPixmap *vPix = pImgEvt->Pixmap();

		/*
		 * Try and find this item in the view
		 */
		ZImageViewItem *vIvi = FindByKey(vKey);
		if (vIvi != NULL)
		{
			qDebug("%s::Received pix update for icon %ld", __FILE__, vKey);
			if (vPix == NULL)
				qDebug("%s::pixmap is null!", __FILE__);
			vIvi->setPixmap(*vPix);
			repaintItem(vIvi);
			ZULU_GUI_APP()->processEvents();
		}
	}
}

void ZImageView::ClearAll()
{
	this->clear();
	emit CountChanged(this->count());
}

/*------------------------------------------------------------------*
 *						DeleteSelectedItems()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Removes all selected items from the view.
 *
 *	@author		Josh Williams
 *	@date		02-Apr-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::DeleteSelectedItems()
{
	ZImageViewItem *vIvi;
	ZImageViewItem *vDel;

	vIvi = static_cast<ZImageViewItem *>(this->firstItem());

	while (vIvi)
	{
		if (vIvi->isSelected())
		{
			vDel = vIvi;
			vIvi = static_cast<ZImageViewItem *>(vIvi->nextItem());
			ZULU_GUI_APP()->RemoveFile(vDel->GetKey());
		}
		else
			vIvi = static_cast<ZImageViewItem *>(vIvi->nextItem());
	}
	emit CountChanged(this->count());
}

/*------------------------------------------------------------------*
 *						RotateSelectedItems()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Rotates the selected photos 90'.
 *
 *	@author		Josh Williams
 *	@date		22-Dec-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZImageView::RotateSelectedItems()
{
	ZImageViewItem *vIvi;

	vIvi = static_cast<ZImageViewItem *>(this->firstItem());

	while (vIvi)
	{
		if (vIvi->isSelected())
			ZULU_GUI_APP()->RotateFile(vIvi->GetKey());

		vIvi = static_cast<ZImageViewItem *>(vIvi->nextItem());
	}
}

/* 29-Mar-2006 */
void ZImageView::UpdateSelection()
{
	int pCount = 0;
	ZImageViewItem *vIvi;

	vIvi = static_cast<ZImageViewItem *>(this->firstItem());

	while (vIvi)
	{
		if (vIvi->isSelected())
			pCount++;
		vIvi = static_cast<ZImageViewItem *>(vIvi->nextItem());
	}
	emit SelectionCount(pCount);
}


/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
