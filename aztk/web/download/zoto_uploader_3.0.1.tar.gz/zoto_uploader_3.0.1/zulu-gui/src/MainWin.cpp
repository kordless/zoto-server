/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "MainWin.h"

/* System Headers */
#include <cmath>
#include <qmenubar.h>
#include <qlayout.h>
#include <qhbox.h>
#include <qvbox.h>
#include <qtoolbar.h>
#include <qtoolbutton.h>
#include <qstatusbar.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qfiledialog.h>
#include <qmessagebox.h>
#include <qdockwindow.h>
#include <qwizard.h>
#include <qfontdialog.h>

/* Local Headers */
#include "GuiApp.h"
//#include "StatusArea.h"
#include "ImageView.h"
#include "URLLabel.h"
#include "Utils.h"
#include "LoginDlg.h"
#include "UploadManager.h"
#include "WizardDlg.h"
#include "OptionsDlg.h"
#include "DialogTester.h"

/* Macros */
#if ZULU_PLATFORM == PLATFORM_WINDOWS
inline
int round(double d)
{
	return floor(d + 0.5);
}
#endif //ZULU_PLATFORM

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZMainWin::ZMainWin(QWidget *pParent /*=0*/, const char *pName /*0*/, WFlags pFlags /*=WType_TopLevel*/)
	: QMainWindow(pParent, pName, pFlags)
{
	setCaption(tr(ZULU_GUI_APP()->GetWindowCaption()));

	/* Setup Toolbar */
	CreateToolbar();

	qDebug(QString("Main window font: %1 - %2").arg(font().family()).arg(font().pointSize()));
	/* Setup Layout */
	QHBox *vOuterBox = new QHBox(this);
	vOuterBox->setFrameStyle(QFrame::Panel | QFrame::Sunken);
	setCentralWidget(vOuterBox);

	dynamic_cast<QHBoxLayout *>(vOuterBox->layout())->addStrut(440);
	QVBox *vMainBox = new QVBox(vOuterBox, "MainBox");
	static_cast<QVBoxLayout*>(vMainBox->layout())->addStrut(440);

	/* Setup Status Bar */
	//mStatusArea = new ZStatusArea(this, "StatusArea");
	//statusBar()->addWidget(mStatusArea, 1, true);

	/* Setup Menus */
	QPopupMenu *vFileMenu = new QPopupMenu(this, "File Menu");
	menuBar()->insertItem("&File", vFileMenu);
	vFileMenu->insertItem("&Change User", ZULU_GUI_APP(), SLOT(Reset()));
	vFileMenu->insertSeparator();
	vFileMenu->insertItem("E&xit", ZULU_GUI_APP(), SLOT(quit()), CTRL+Key_Q);

#if defined(ZOTO_TAGGING) || defined(ZOTO_GALLERIES)
	QPopupMenu *vEditMenu = new QPopupMenu(this, "Edit Menu");
	menuBar()->insertItem("&Edit", vEditMenu);
	vEditMenu->insertItem("&Preferences", this, SLOT(ShowPrefs()), CTRL+Key_P);
#endif

	QPopupMenu *vHelpMenu = new QPopupMenu(this, "Help Menu");
	menuBar()->insertItem("&Help", vHelpMenu);
	vHelpMenu->insertItem(QString(tr("Visit ")) + ZOTO_DOMAIN, this, SLOT(GoToZotoCom()), CTRL+Key_Q);

	/*
	QPopupMenu *vDialogMenu = new QPopupMenu(this, "Dialog Menu");
	menuBar()->insertItem("&Dialogs", vDialogMenu);
	vDialogMenu->insertItem("Test Options", this, SLOT(TestOptions()));
#ifdef ZOTO_TAGGING
	vDialogMenu->insertItem("Test Tags", this, SLOT(TestTags()));
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	vDialogMenu->insertItem("Test Gallery", this, SLOT(TestGallery()));
	vDialogMenu->insertItem("Test NewGallery", this, SLOT(TestNewGallery()));
	vDialogMenu->insertItem("Test Templates", this, SLOT(TestTemplates()));
#endif // ZOTO_GALLERIES
	vDialogMenu->insertItem("Fonts", this, SLOT(ShowFonts()));
	*/

	/* Image View */
	QHBox *vCenterBox = new QHBox(vMainBox);
	mImageView = new ZImageView(vCenterBox);

	/* Upload Frame */
	QFrame *vSep = new QFrame(vCenterBox, "MAIN_SEPARATOR");
	vSep->setFrameStyle(QFrame::VLine | QFrame::Raised);

	QScrollView *vScroller = new QScrollView(vCenterBox);
	vScroller->setFrameStyle(QFrame::NoFrame);
	vScroller->setMaximumWidth(230);
	vScroller->viewport()->setPaletteBackgroundColor(Qt::white);
	mUploadMgr = new ZUploadManager(vScroller->viewport());
	vScroller->addChild(mUploadMgr);
	mUploadMgr->setMinimumWidth(225);
	//mUploadMgr->setMaximumWidth(220);
	vScroller->hide();
	vSep->hide();


	QFrame *vFrame = new QFrame(vMainBox);
	vFrame->setFrameStyle(QFrame::HLine | QFrame::Sunken);

	/* Button Frame */
	CreateButtonFrame(vMainBox);

	/* Signals and slots */
	connect(mUploadBtn, SIGNAL(clicked()), ZULU_GUI_APP(), SLOT(CreateBatch()));
	connect(mImageView, SIGNAL(CountChanged(int)), this, SLOT(UpdateButtons(int)));
	connect(mImageView, SIGNAL(SelectionCount(int)), this, SLOT(UpdateSelection(int)));

	UpdateButtons(0);
	UpdateSelection(0);
	resize(710, 700);
}

ZMainWin::~ZMainWin()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							SwitchUser()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Changes the currently logged in user.
 *
 *	@author		Josh Williams
 *	@date		03-Jan-2006
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZMainWin::SwitchUser()
{
	ZUserInfo	*vInfo;

	if (ZULU_GUI_APP()->GetCurrentUser(&vInfo) == false)
	{
		mLblBox->hide();
	}
	else
	{
		UpdateStatus(vInfo);
		mLblBox->show();
	}
}

void ZMainWin::UpdateStatus(const ZUserInfo *vInfo)
{
	mURLLabel->setText(ZULU_GUI_APP()->MakeURL(ZOTO_USER_HOME_URL, vInfo->mUserName));
	mURLLabel->SetURL(ZULU_GUI_APP()->MakeURL(ZOTO_USER_HOME_URL, vInfo->mUserName));
	setCaption(tr(ZULU_GUI_APP()->GetWindowCaption()));
	if (vInfo->mImgCount <= 0)
		mUsage->setText(tr("You have not uploaded any photos."));
	else
		mUsage->setText(QString(tr("You have uploaded %1 photos").arg(vInfo->mImgCount)));
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								AddImages()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Called when the user hits the add (+) button.
 *
 *	@author		Josh Williams
 *	@date		07-Apr-2004
 *
 *	@remarks	Opens a file dialog to allow for selecting additional
 *				files.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZMainWin::AddImages()
{
	QStringList::iterator vIt;
	QString vStrDir = ZULU_GUI_APP()->GetLastBrowse();
	QStringList	vInvalid;
	QString vSelectedFilter;

	if ((ZULU_GUI_APP()->GetLastFormat().lower().compare("jpg") == 0) ||
		(ZULU_GUI_APP()->GetLastFormat().lower().compare("jpeg") == 0))
		vSelectedFilter = "JPEG (*.jpg *.jpeg *.JPG *.JPEG)";
	else if (ZULU_GUI_APP()->GetLastFormat().lower().compare("gif") == 0)
		vSelectedFilter = "GIF (*.gif *.GIF)";
	else if (ZULU_GUI_APP()->GetLastFormat().lower().compare("bmp") == 0)
		vSelectedFilter = "Bitmap (*.bmp *.BMP)";
	else if (ZULU_GUI_APP()->GetLastFormat().lower().compare("png") == 0)
		vSelectedFilter = "PNG (*.png *.PNG)";
	else
		vSelectedFilter = "";

	QStringList vFiles = QFileDialog::getOpenFileNames("JPEG (*.jpg *.jpeg *.JPG *.JPEG);;GIF (*.gif *.GIF);;Bitmap (*.bmp *.BMP);;PNG (*.png *.PNG)",
			vStrDir,
			this,
			"open files dialog",
			tr("Select one or more images to upload"),
			&vSelectedFilter);
	WAIT_CURSOR_ON();
	if (vFiles.size() > 0)
	{
		QFileInfo vInfo(vFiles[0]);
		ZULU_GUI_APP()->SetLastBrowse(vInfo.dirPath(true));
		ZULU_GUI_APP()->SetLastFormat(vInfo.extension(false));
		for (vIt = vFiles.begin(); vIt != vFiles.end(); vIt++)
		{
			if (ZULU_GUI_APP()->AddFile((*vIt)) != true)
				vInvalid.append(*vIt);
		}
	}
	WAIT_CURSOR_OFF();

	/*
	 * Inform the user of any files that could not be processed.
	 */
	if (vInvalid.count() > 0)
	{
		QString vMsg = tr("The following files were not valid:\n");
		for (ZUINT i = 0; i < vInvalid.count(); i++)
		{
			vMsg += vInvalid[i];
			vMsg += "\n";
		}
		QMessageBox::warning(this, ZULU_GUI_APP()->GetAppName(), vMsg);
	}
}

/*------------------------------------------------------------------*
 *							 DeleteImages()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Called when the user hits the delete (-) button.
 *
 *	@author		Josh Williams
 *	@date		07-Apr-2004
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZMainWin::DeleteImages()
{
	if (mImageView)
		mImageView->DeleteSelectedItems();
}

/*------------------------------------------------------------------*
 *							 RotateImages()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Called when the user hits the rotate button.
 *
 *	@author		Josh Williams
 *	@date		22-Dec-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZMainWin::RotateImages()
{
	if (mImageView)
		mImageView->RotateSelectedItems();
}

void ZMainWin::ShowFonts()
{
	QFontDialog::getFont(0, this->font());
}

void ZMainWin::ShowPrefs()
{
	ZUserInfo *vInfo = NULL;
	ZULU_GUI_APP()->GetCurrentUser(&vInfo);
	ZOptionsDlg *vDlg = new ZOptionsDlg(vInfo, this);

	if (vDlg->exec() == QDialog::Accepted)
	{
#ifdef ZOTO_TAGGING
		vInfo->mTagging = vDlg->GetTags();
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
		vInfo->mGalleries = vDlg->GetGalleries();
#endif // ZOTO_GALLERIES
		vInfo->mRemember = vDlg->GetRemember();
		ZULU_GUI_APP()->SaveUser(vInfo);
	}
}

void ZMainWin::UpdateButtons(int pCount)
{
	if (pCount > 0)
		mUploadBtn->setEnabled(true);
	else
		mUploadBtn->setEnabled(false);
}

void ZMainWin::UpdateSelection(int pCount)
{
	if (pCount > 0)
	{
		mImgRem->setEnabled(true);
		mImgRot->setEnabled(true);
	}
	else
	{
		mImgRem->setEnabled(false);
		mImgRot->setEnabled(false);
	}
}	

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

void ZMainWin::GoToZotoCom()
{
	ZUtils::OpenURL(this, ZULU_GUI_APP()->MakeURL(ZOTO_MAIN_URL));
}

/*------------------------------------------------------------------*
 *							 CreateToolbar()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates the toolbar with icons for image manipulation.
 *
 *	@author		Josh Williams
 *	@date		20-Dec-2005
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZMainWin::CreateToolbar()
{
	QToolBar *vToolBar = new QToolBar(this, "Image Actions");
	vToolBar->setLabel("FOOBAR!!!!!");
	vToolBar->setMovingEnabled(false);

	QIconSet vAddSet(QPixmap::fromMimeSource("add.png"));
	vAddSet.setPixmap(QPixmap::fromMimeSource("add_d.png"), QIconSet::Large, QIconSet::Disabled);

	QIconSet vRemSet(QPixmap::fromMimeSource("remove.png"));
	vRemSet.setPixmap(QPixmap::fromMimeSource("remove_d.png"), QIconSet::Large, QIconSet::Disabled);
	
	QIconSet vRotSet(QPixmap::fromMimeSource("rotate.png"));
	vRotSet.setPixmap(QPixmap::fromMimeSource("rotate_d.png"), QIconSet::Large, QIconSet::Disabled);

	mImgAdd = new QToolButton(vAddSet, "Add", QString::null, this, SLOT(AddImages()), vToolBar, "image add");
	mImgRem = new QToolButton(vRemSet, "Remove", QString::null, this, SLOT(DeleteImages()), vToolBar, "image remove");
	mImgRot = new QToolButton(vRotSet, "Rotate", QString::null, this, SLOT(RotateImages()), vToolBar, "image rotate");

	mImgAdd->setUsesTextLabel(true);
	mImgAdd->setUsesBigPixmap(true);
	mImgRem->setUsesTextLabel(true);
	mImgRem->setUsesBigPixmap(true);
	mImgRot->setUsesTextLabel(true);
	mImgRot->setUsesBigPixmap(true);
	mImgRem->adjustSize();
	mImgAdd->setFixedWidth(mImgRem->width());
	mImgRot->setFixedWidth(mImgRem->width());

	QWidget *vFiller = new QWidget(vToolBar);
	vToolBar->setStretchableWidget(vFiller);

	QVBox *vLogoBox = new QVBox(vToolBar);
	QLabel *vLogo = new QLabel(vLogoBox);
	vLogo->setPixmap(QPixmap::fromMimeSource("zotologo.png"));
	QLabel *vVersion = new QLabel(vLogoBox);
	vVersion->setAlignment(Qt::AlignRight);
	QFont vFont(font());
	vFont.setBold(true);
	//vFont.setPointSize(vFont.pointSize() + 3);
	vVersion->setFont(vFont);
	vVersion->setPaletteForegroundColor(QColor(172, 172, 172));
	QString vVersString;
	vVersString.sprintf(tr("UPLOADER %d.%d "), ZULU_GUI_APP()->GetVersMaj(), ZULU_GUI_APP()->GetVersMin());
	vVersion->setText(vVersString);

	QWidget *vFiller2 = new QWidget(vToolBar);
	vFiller2->setMinimumWidth(10);

	return true;
}

/*------------------------------------------------------------------*
 *							CreateButtonFrame()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates the frame at the bottom of the main window,
 *				along with all of its children.
 *
 *	@author		Josh Williams
 *	@date		21-Dec-2005
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZMainWin::CreateButtonFrame(QVBox *pParent)
{
	QFont vURLFont(font());
	vURLFont.setItalic(true);
	vURLFont.setUnderline(true);

	QFrame *vBottomFrame = new QFrame(pParent);
	vBottomFrame->setSizePolicy(QSizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Maximum));

	/* Put all child widgets in one big HBox */
	QHBoxLayout *vParentBox = new QHBoxLayout(vBottomFrame);
	vParentBox->setMargin(15);

	/*
	 * Box that holds all the left-hand labels.
	 */
	mLblBox = new QVBox(vBottomFrame, "Label Box");

	/* Link to your homepage */
	QHBox *vLinkBox = new QHBox(mLblBox, "Link Box");
	new QLabel(tr("Your home page is "), vLinkBox);
	mURLLabel = new ZURLLabel(QColor(63, 30, 232), Qt::blue, vLinkBox, "Link URL");
	mURLLabel->setFont(vURLFont);
	vLinkBox->setStretchFactor(mURLLabel, 100);

	/* Number of photos */
	mUsage = new QLabel(mLblBox);

	vParentBox->addWidget(mLblBox, 0, Qt::AlignLeft);

	mUploadBtn = new QPushButton(tr("UPLOAD"), vBottomFrame);
	vParentBox->addWidget(mUploadBtn, 0, Qt::AlignRight);

	pParent->setStretchFactor(vBottomFrame, 100);

	mLblBox->hide();
	return true;
}

void ZMainWin::ShowTestDialog(const QString &pType)
{
	ZUserInfo *vInfo = NULL;
	ZULU_GUI_APP()->GetCurrentUser(&vInfo);
	ZDialogTester *vDlg = new ZDialogTester(pType, this);
	vDlg->Init(vInfo);
	vDlg->exec();
}

} // End Namespace

/* vi: set ts=4: */
