/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "UploadBatch.h"

/* System Headers */
#include <qpushbutton.h>
#include <qlayout.h>
#include <qhbox.h>
#include <qvbox.h>
#include <qimage.h>
#include <qfileinfo.h>
#include <qwmatrix.h>
#include <time.h>

/* Local Headers */
#include "GuiApp.h"
#include "Events.h"
#include "Client.h"
#include "URLLabel.h"
#include "Utils.h"
#include "ZSPThread.h"
#include "ZAPIThread.h"
#include "UploadManager.h"
#include "MainWin.h"

/* Macros */
enum eStackPages
{
	PAGE_ACTIVE = 1,
	PAGE_FINISHED
};

namespace ZOTO
{

void CallbackFunc(ZXferInfo *pInfo)
{
	ZSPEvent *vEvt = new ZSPEvent();
	vEvt->mBatch		= pInfo->mBatch;
	vEvt->mFile			= pInfo->mFile;
	vEvt->mName			= pInfo->mName;
	vEvt->mTemp			= pInfo->mTemp;
	vEvt->mSize			= pInfo->mSize;
	vEvt->mID			= pInfo->mID;
	memcpy(vEvt->mMD5, pInfo->mMD5, sizeof(vEvt->mMD5));
	vEvt->mMD5[32]		= '\0';
	vEvt->mStatus		= pInfo->mStatus;
	vEvt->mProgress		= pInfo->mProgress;
	vEvt->mBytes		= pInfo->mBytes;
	vEvt->mErrcode		= pInfo->mErrcode;
	vEvt->mSpeed		= pInfo->mSpeed;
	QThread::postEvent(ZUploadManager::GetCurrentBatch(), vEvt);
}

/* Static Variables */
QString ZUploadBatch::mDoneMessages[] = {
	tr("Your upload is done!"),
	tr("Mmmm.  Photos."),
	tr("Zoto loves you."),
	tr("Wheee!  All done!"),
	tr("So, yeah.  I'm done."),
	tr("Photos are in orbit."),
	tr("Go share some of 'em!"),
	tr("Ya'll, I'm done!"),
	tr("Bandwidth good."),
	tr("Photos, photos, photos.")
};

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZUploadBatch::ZUploadBatch(const ZFileList &pFiles, ZULONG pTotalBytes, 
			QWidget *pParent /*=0*/, const char *pName /*=0*/, WFlags pFlags /*=0*/)
	: QWidgetStack(pParent, pName, pFlags), mID(0L),
		mTotalBytes(pTotalBytes), mUploadBytes(0L), mCurrentBytes(0L), mCurrentFile(0),
		mStatus(BATCH_PENDING)
{
	ZRESULT vRetval;

	ZFileList::const_iterator vIt;
	for (vIt = pFiles.begin(); vIt != pFiles.end(); vIt++)
		mFiles[(*vIt).mIndex] = *vIt;

	/* Set up the ID */
	mID = time(NULL);

	mTotalFiles = mFiles.count();
	mThumbSize.setWidth(90);
	mThumbSize.setHeight(65);
	setFixedSize(QSize(200, 140));
	setFrameStyle(QFrame::Raised | QFrame::Panel);

	/* Create the ZSP client */
	mClient = new ZClient(ZULU_GUI_APP()->GetZspHost(), ZULU_GUI_APP()->GetZspPort());
	if ((vRetval = mClient->Initialize()) != ZERR_SUCCESS)
		throw ZClientError(vRetval);

	QFont vTextFont(ZULU_GUI_APP()->mainWidget()->font());
	vTextFont.setPixelSize(10);
	QFont vButtonFont(vTextFont);
	vButtonFont.setUnderline(true);

	/*
	 * Create the stack pages.
	 */
	CreateActivePage(vTextFont, vButtonFont, 200);
	CreateFinishedPage(vTextFont, vButtonFont, 200);
	raiseWidget(PAGE_ACTIVE);
	widget(PAGE_ACTIVE)->layout()->activate();
	widget(PAGE_ACTIVE)->adjustSize();
	setFixedHeight(widget(PAGE_ACTIVE)->minimumSizeHint().height());

	SwitchFile(mFiles.begin().data(), 0);

	/* Signals and slots */

	mZSPThread = new ZZSPThread(this, mClient);
	mZAPIThread = new ZZAPIThread(this);
	qDebug("ZUploadBatch constructor exiting");
}

ZUploadBatch::~ZUploadBatch()
{
	qDebug("ZUploadBatch destructor called");

	if (mZSPThread)
		delete mZSPThread;

	if (mZAPIThread)
		delete mZAPIThread;

	if (mClient)
		delete mClient;
}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							SetActive()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Cranks up the upload process for this batch.  Enables
 *				all hidden progress widgets.
 *
 *	@author		Josh Williams
 *	@date		13-Jan-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZUploadBatch::SetActive()
{
	ZFileList::iterator vIt = mFiles.begin();
	qDebug(QString("%1::Starting upload of %2 files").arg(__FILE__).arg(mFiles.count()));
	for (vIt = mFiles.begin(); vIt != mFiles.end(); vIt++)
		qDebug((*vIt).mName);
	
	mStatus = BATCH_ACTIVE;
	mPauseResume->show();
	mPCsep->show();
	
	mCurrFile->show();
	mSpeed->show();
	mProgress->show();
	visibleWidget()->layout()->activate();
	setFixedSize(minimumSizeHint());
	StartNextUpload();
}
	
/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							  customEvent()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Processes updates from the auth and ZAPI threads.
 *
 *	@author		Josh Williams
 *	@date		22-Mar-2006
 *
 *	@param		pEvt
 *					Event to be processed.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZUploadBatch::customEvent(QCustomEvent *pEvt)
{
	if (pEvt->type() == ZSP)
	{
		ZSPEvent *vEvt = dynamic_cast<ZSPEvent *>(pEvt);
		StatusUpdate(vEvt);
	}
	else if (pEvt->type() == ZSTATUS)
	{
		ZStatusEvent *vEvt = dynamic_cast<ZStatusEvent *>(pEvt);
		qDebug(QString("%1::Received ZSTATUS event with type %2").arg(__FILE__).arg(vEvt->mType));
		if (vEvt->mType == ZStatusEvent::AUTH || vEvt->mType == ZStatusEvent::VERSION)
		{
			if (vEvt->mErrcode == ZERR_SUCCESS)
			{
				StartNextUpload();
			}
			else
			{
				ZSPEvent vFailEvt;
				vFailEvt.mBatch		= mID;
				vFailEvt.mErrcode	= ZERR_COMM;
				vFailEvt.mStatus	= XFER_FAILED;
				StatusUpdate(&vFailEvt);
			}
		}
		else if (vEvt->mType == ZStatusEvent::IMAGE_ROTATE)
		{
			qDebug(QString("%1::Received rotate event").arg(__FILE__));
			if (vEvt->mErrcode == ZERR_SUCCESS)
			{
				qDebug(QString("%1::Rotate successful").arg(__FILE__));
				QString vImageId = *(static_cast<QString *>(vEvt->data()));
				qDebug(QString("%1::Received image id %2 from rotation.").arg(__FILE__).arg(vImageId));
#ifdef ZOTO_TAGGING
				Tag(vImageId);
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
				mGalleryImgs.append(vImageId);
				if (mFiles.count() == 0)
					Galleryize();
#endif // ZOTO_GALLERIES
			}

			if (mFiles.count() == 0)
				SetComplete();
			else
				StartNextUpload();
		}
#ifdef ZOTO_TAGGING
		else if (vEvt->mType == ZStatusEvent::TAG_PHOTO)
		{
			qDebug(QString("%1::Photos tagged successfully").arg(__FILE__));
			mTagStatus = vEvt->mErrcode;
		}
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
		else if (vEvt->mType == ZStatusEvent::ADD_TO_GALLERY)
		{
			qDebug(QString("%1::Photos added to gallery successfully").arg(__FILE__));
			mGalleryStatus = vEvt->mErrcode;
		}
#endif // ZOTO_GALLERIES
	}
}

/*------------------------------------------------------------------*
 *							 StatusUpdate()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Receives updates from the client library during the
 *				upload process.
 *
 *	@author		Josh Williams
 *	@date		13-Jan-2006
 *
 *	@param		pInfo
 *					Information about the progress of the upload.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZUploadBatch::StatusUpdate(ZSPEvent *pInfo)
{
	static ZUSHORT	vRetries = 0;

	ZULONG		vKey;
	QString		vTemp;
	float		vRem;
	ZUserInfo	*vInfo;
	QString vGalleryImg;

	if (mStatus == BATCH_CANCELLED)
		return;

	if (pInfo->mBatch != mID)
	{
		qDebug(QString("%1::ID's don't match.  Current => %2, event => %3").arg(__FILE__).arg(mID).arg(pInfo->mBatch));
		return;
	}

	/*
	 * Get the key for the file currently being uploaded.
	 */
	vKey = mFiles.begin().key();

	switch (pInfo->mStatus)
	{
	/*======================================*
	 * Client is about to upload			*
	 *======================================*/
	case XFER_STARTING:
		qDebug(QString("%1::Upload about to start").arg(__FILE__));
		if (pInfo->mTemp)
		{
			/*
			 * File was converted into an alternate format.  Need to adjust overall
			 * byte count.
			 */
			mTotalBytes -= mFiles[vKey].mSize;
			mTotalBytes += pInfo->mSize;
		}

		UpdateDisplay(0.0f, 0.0f);
		return;
	/*======================================*
	 * Client is notifying us of progress	*
	 *======================================*/
	case XFER_ACTIVE:
		/*
		 * Normal progress update.
		 */
		mUploadBytes += pInfo->mBytes;
		mCurrentBytes += pInfo->mBytes;

		/*
		 * Update the current file progress
		 */
		vRem = (float)pInfo->mSize * (1.0f - pInfo->mProgress);
		UpdateDisplay(pInfo->mProgress, pInfo->mSpeed);
		return;
	/*======================================*
	 * Client has completed uploading		*
	 *======================================*/
	case XFER_COMPLETE:
		qDebug(QString("%1::Upload completed").arg(__FILE__));
		mUploadBytes += pInfo->mBytes;
		FinalizeUpload(pInfo, vKey);
		vRetries = 0;
		break;
	/*======================================*
	 * Client failed to upload file			*
	 *======================================*/
	case XFER_FAILED:
		qDebug(QString("%1::customEvent() called with XFER_FAILED, errcode %2").arg(__FILE__).arg(ZObject::RetString(pInfo->mErrcode)));
		if (pInfo->mErrcode == ZERR_DUPLICATE_FILE)
		{
			qDebug(QString("%1::Uh-oh.  Duplicate file").arg(__FILE__));
			mUploadBytes += pInfo->mSize;
			FinalizeUpload(pInfo, vKey);
			break;
		}
		else if (pInfo->mErrcode == ZERR_TIMEOUT || pInfo->mErrcode == ZERR_COMM)
		{
			mClient->Disconnect();
			if (++vRetries > 3)
			{
				emit StatusChanged(mID, BATCH_FAILED);
				return;
			}
			else
			{
				/*
				 * Roll back the progress info
				 */
				mCurrentFile--;
				mUploadBytes -= mCurrentBytes;
				UpdateDisplay(0.0f, pInfo->mSpeed);
				
				/*
				 * Connect and authenticate
				 */
				if (ZULU_GUI_APP()->GetCurrentUser(&vInfo) == false)
				{
					emit StatusChanged(mID, BATCH_FAILED);
					return;
				}
				mZSPThread->ProcessUser(vInfo->mUserName, vInfo->mPswdHash, false);
				mZSPThread->start();
				return;
			}
		}
		else
		{
			/*
			 * Do something really erroneous
			 */
			emit StatusChanged(mID, BATCH_FAILED);
			return;
		}
		break;
	default:
		qDebug(QString("%1::Got unknown code %2 from client in customEvent()").arg(__FILE__).arg(pInfo->mStatus));
	}

    return;
}

/*------------------------------------------------------------------*
 *							  CancelBatch()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Cancels the batch transfer, or closes the batch window
 *				if the batch has completed.
 *
 *	@author		Josh Williams
 *	@date		17-Jan-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZUploadBatch::CancelBatch()
{
	if (mStatus == BATCH_PENDING)
	{
		emit StatusChanged(mID, BATCH_CANCELLED);
	}
	else if (mStatus == BATCH_ACTIVE || mStatus == BATCH_PAUSED)
	{
		mStatus = BATCH_CANCELLED;
		mClient->CancelTransfer();
		emit StatusChanged(mID, BATCH_CANCELLED);
	}
	else if (mStatus == BATCH_COMPLETE)
	{
		mStatus = BATCH_CLOSED;
		emit StatusChanged(mID, BATCH_CLOSED);
	}
}

/*------------------------------------------------------------------*
 *						PauseResumeBatch()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Pauses or resumes the upload process, depending on
 *				the current state.
 *
 *	@author		Josh Williams
 *	@date		17-Jan-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZUploadBatch::PauseResumeBatch()
{
	if (mStatus == BATCH_ACTIVE)
	{
		mStatus = BATCH_PAUSED;
		mPauseResume->setText(tr("Resume"));
		mClient->PauseTransfer();
	}
	else
	{
		mStatus = BATCH_ACTIVE;
		mPauseResume->setText(tr("Pause"));
		mClient->ResumeTransfer();
	}
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							CreateActivePage()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates the widget stack page to be displayed when
 *				the batch is pending/active.
 *
 *	@author		Josh Williams
 *	@date		12-Apr-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZUploadBatch::CreateActivePage(const QFont &pTextFont, const QFont &pButtonFont,
						const ZUSHORT pWidth)
{
	QWidget *vPanel = new QWidget(this, "Active Panel");
	vPanel->setFixedWidth(pWidth);
	vPanel->setSizePolicy(QSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum));
	QVBoxLayout *vActiveLayout = new QVBoxLayout(vPanel, 5, 5);

	/*
	 * Main widget layout is a horizontal box, with the thumbnail
	 * on the left, and the info on the right.
	 */
	QHBoxLayout *vMainLayout = new QHBoxLayout(vActiveLayout, 3, "Main Layout");

	/* Create the thumbnail */
	mCurrThumb = new QLabel(vPanel, "Thumbnail");
	mCurrThumb->setFixedSize(mThumbSize);
	mCurrThumb->setAlignment(Qt::AlignHCenter | Qt::AlignTop);
	mCurrThumb->setFrameStyle(QFrame::Raised | QFrame::Panel);
	vMainLayout->addWidget(mCurrThumb);

	/* Right hand info */
	QVBoxLayout *vRightLayout = new QVBoxLayout(vMainLayout, 0, "Right Layout");

	/* batch image count */
	mCount = new QLabel(tr("<b>Photo:</b> 0 of 0"), vPanel, "Count Label");
	mCount->setFont(pTextFont);
	mCount->setTextFormat(Qt::RichText);
	vRightLayout->addWidget(mCount);

	/* current file name */
	mCurrFile = new QLabel("", vPanel, "Curr File Label");
	mCurrFile->setFont(pTextFont);
	vRightLayout->addWidget(mCurrFile);

	/* Percent complete on current file */
	mCurrPercent = new QLabel(tr("<b>0%</b> uploaded"), vPanel, "CurrPerc Label");
	mCurrPercent->setFont(pTextFont);
	vRightLayout->addWidget(mCurrPercent);

	/* Current upload rate */
	mSpeed = new QLabel(tr("0 KB/sec"), vPanel, "Speed Label");
	mSpeed->setFont(pTextFont);
	vRightLayout->addWidget(mSpeed);
	vRightLayout->addStretch(100);

	/* Overall progress bar */
	mProgress = new QProgressBar(vPanel, "Progress");
	mProgress->setMaximumHeight(15);
	mProgress->setTotalSteps(100);
	vActiveLayout->addWidget(mProgress);

	QHBoxLayout *vBottomLayout = new QHBoxLayout(vActiveLayout, 3);
	vBottomLayout->addStretch(100);
	
	/* Top Pause/resume button */
	mPauseResume = new ZURLLabel(QColor(63, 30, 232), Qt::blue, vPanel, "Pause");
	mPauseResume->setText(tr("Pause"));
	mPauseResume->setFont(pButtonFont);
	mPauseResume->hide();
	vBottomLayout->addWidget(mPauseResume);

	mPCsep = new QLabel("|", vPanel, "Seperator Label");
	mPCsep->hide();
	vBottomLayout->addWidget(mPCsep);

	mCancel = new ZURLLabel(QColor(63, 30, 232), Qt::blue, vPanel, "Cancel");
	mCancel->setText(tr("Cancel"));
	mCancel->setFont(pButtonFont);
	vBottomLayout->addWidget(mCancel, 0, Qt::AlignRight);

	QFrame *vLine = new QFrame(vPanel);
	vLine->setFrameStyle(QFrame::HLine | QFrame::Plain);
	vLine->setPaletteForegroundColor(Qt::lightGray);
	vActiveLayout->addWidget(vLine, 100);

	/* Hide the progress widgets until the upload begins */
	mCurrFile->hide();
	mSpeed->hide();
	mProgress->hide();
	addWidget(vPanel, PAGE_ACTIVE);
	vActiveLayout->activate();

	connect(mCancel, SIGNAL(Clicked()), this, SLOT(CancelBatch()));
	connect(mPauseResume, SIGNAL(Clicked()), this, SLOT(PauseResumeBatch()));
}

/* 12-Apr-2006 */
void ZUploadBatch::CreateFinishedPage(const QFont &pTextFont, const QFont &pButtonFont,
					ZUSHORT pWidth)
{
	QWidget *vPanel = new QWidget(this, "Finished Panel");
	vPanel->setSizePolicy(QSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored));
	vPanel->setFixedWidth(pWidth);

	QVBoxLayout *vFinishedLayout = new QVBoxLayout(vPanel, 5, 0, "Finished Layout");

	QHBoxLayout *vContentsLayout = new QHBoxLayout(vFinishedLayout, 0, "Finished Layout");

	/* Create the thumbnail */
	QLabel *vFinishedThumb = new QLabel(vPanel, "Thumbnail");
	vFinishedThumb->setPixmap(QPixmap::fromMimeSource("complete.png"));
	vContentsLayout->addWidget(vFinishedThumb, 0, Qt::AlignTop | Qt::AlignLeft);

	/*
	 * Right hand side.
	 */
	QVBoxLayout *vRightLayout = new QVBoxLayout(vContentsLayout, 0);
	QLabel *vHeader = new QLabel(mDoneMessages[rand() % 8], vPanel);
	vRightLayout->addWidget(vHeader);
	vRightLayout->addSpacing(5);

	mView = new ZURLLabel(QColor(63, 30, 232), Qt::blue, vPanel, "View");
	mView->setText(tr("Click here to view!"));

	mView->setFont(pTextFont);
	vRightLayout->addWidget(mView);
	vRightLayout->addSpacing(10);

	ZURLLabel *vClose = new ZURLLabel(QColor(63, 30, 232), Qt::blue, vPanel, "Close");
	vClose->setText(tr("Close"));
	vClose->setFont(pButtonFont);
	vRightLayout->addWidget(vClose, 0, Qt::AlignRight);

	vFinishedLayout->addSpacing(4);

	QFrame *vLine = new QFrame(vPanel);
	vLine->setFrameStyle(QFrame::HLine | QFrame::Plain);
	vLine->setPaletteForegroundColor(Qt::lightGray);
	vFinishedLayout->addWidget(vLine, 100);

	addWidget(vPanel, PAGE_FINISHED);

	connect(vClose, SIGNAL(Clicked()), this, SLOT(CancelBatch()));
}

/*------------------------------------------------------------------*
 *							SwitchFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Causes the thumbnail for the new file to be displayed,
 *				as well as properly setting all info/progress values.
 *
 *	@author		Josh Williams
 *	@date		13-Jan-2006
 *
 *	@param		pFile
 * 					Info about the file currently being uploaded.
 *	@param		pIdx
 * 					Index of the current file (x of 10)
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZUploadBatch::SwitchFile(const ZFileInfo &pFile, ZUINT pIdx)
{
	QFileInfo	vFileInfo(pFile.mName);
	QString		vFileName;
	
	/*
	 * Create the thumbnail
	 */
	QImage vColor = QImage(pFile.mName).scale(mThumbSize.width(), mThumbSize.height(),
			QImage::ScaleMax);

	if (mStatus != BATCH_ACTIVE)
	{
		if (mTotalBytes > (1024 * 1024))
			SetCurrPercent(QString("%1 MB").arg(static_cast<double>(mTotalBytes) / static_cast<double>(1024 * 1024), 3, 'f', 2));
		else if (mTotalBytes > 1024)
			SetCurrPercent(QString("%1 KB").arg(static_cast<double>(mTotalBytes) / static_cast<double>(1024), 3, 'f', 2));
		else
			SetCurrPercent(QString("%1").arg(mTotalBytes)); 
		SetCount(QString(tr("%1 Photos")).arg(mTotalFiles));

		int vPixels = 0;
		unsigned int *vData = NULL;
		if (vColor.depth() > 8)
		{
			vPixels = vColor.width() * vColor.height();
			vData = reinterpret_cast<unsigned int *>(vColor.bits());
		}
		else
		{
			qDebug("depth() < 8");
			vPixels = vColor.numColors();
			vData = reinterpret_cast<unsigned int *>(vColor.colorTable());
		}
		
		int vVal;
		for (int i = 0; i < vPixels; i++)
		{
			vVal = qGray(vData[i]);
			vData[i] = qRgba(vVal, vVal, vVal, qAlpha(vData[i]));
		}
	}
	else
	{
		if (vFileInfo.fileName().length() > 17)
			SetCurrFile(QString("%1...").arg(vFileInfo.fileName().left(14)));
		else
			SetCurrFile(vFileInfo.fileName());
		SetCount(QString(tr("<b>Photo:</b> %1 of %2")).arg(pIdx).arg(mTotalFiles));
	}
	QPixmap vPix;

	if (pFile.mRotate)
	{
		QWMatrix m;
		m.rotate(90.0f * static_cast<float>(pFile.mRotate));
		vPix.convertFromImage(vColor.xForm(m));
	}
	else
	{
		vPix.convertFromImage(vColor);
	}

	qDebug(QString("%1::Setting current thumb").arg(__FILE__));
	SetCurrThumb(&vPix);
}

/*------------------------------------------------------------------*
 *							FinalizeUpload()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Performs the steps required when an upload is
 *				completed.
 *
 *	@author		Josh Williams
 *	@date		11-Apr-2006
 *
 *	@param		pInfo
 * 					ZSP info about the completed file.
 *	@param		pKey
 * 					Index of this file in the global file list.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZUploadBatch::FinalizeUpload(ZSPEvent *pInfo, ZULONG pKey)
{
	ZUserInfo				*vInfo;
	UpdateDisplay(1.0f, 1.0f);
	ZUSHORT vRotate = mFiles[pKey].mRotate;
	if (ZULU_GUI_APP()->GetCurrentUser(&vInfo) == true)
	{
		vInfo->mImgCount++;
		vInfo->mUsage += mFiles[pKey].mSize;
		dynamic_cast<ZMainWin*>(ZULU_GUI_APP()->mainWidget())->UpdateStatus(vInfo);
	}
	/*
	 * Remove this file from the list.
	 */
	mFiles.remove(pKey);
	Rotate(pInfo->mMD5, vRotate);
}

/*------------------------------------------------------------------*
 *							SetComplete()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Updates the display to reflect a completed status.
 *				Also informs the manager so the next upload can be
 *				started, if one is queued.
 *	@TODO:		Add SetFailed() function.
 *
 *	@author		Josh Williams
 *	@date		18-Jan-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZUploadBatch::SetComplete()
{
	ZUserInfo *vUser = NULL;
	ZULU_GUI_APP()->GetCurrentUser(&vUser);
#ifdef ZOTO_GALLERIES
	if (mGalleries.count() > 0)
		mView->SetURL(ZULU_GUI_APP()->MakeURL(ZOTO_GALLERY_URL, vUser->mUserName, mGalleries[0]));
	else
#endif // ZOTO_GALLERIES
		mView->SetURL(ZULU_GUI_APP()->MakeURL(ZOTO_USER_HOME_URL, vUser->mUserName));

	mStatus = BATCH_COMPLETE;
	raiseWidget(PAGE_FINISHED);
	/*
	qDebug("this->size: %d x %d", size().width(), size().height());
	qDebug("sizeHint(): %d x %d", visibleWidget()->sizeHint().width(), visibleWidget()->sizeHint().height());
	*/
	widget(PAGE_ACTIVE)->setSizePolicy(QSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored));
	visibleWidget()->setSizePolicy(QSizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred));
	setFixedSize(minimumSizeHint());
	emit StatusChanged(mID, BATCH_COMPLETE);
}

/*------------------------------------------------------------------*
 *							StartNextUpload()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Starts the transfer of the next file to be uploaded.
 *
 *	@author		Josh Williams
 *	@date		14-Aug-2005
 *
 *	@remarks	Update messages from the ZClient will be routed through
 *				customEvent() to StatusUpdate().  If, for whatever
 *				reason, we have to authenticate with ZAPI, customEvent()
 *				will process the result.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZUploadBatch::StartNextUpload()
{
	static int vCurFile = 0;
	ZXferInfo	vXInfo;
	ZFileList::iterator vIt;
	ZUserInfo	*vInfo;
	static bool	vJustConnected = false;

	if (mFiles.isEmpty() != true)
    {
		/*
		 * Reconnect after every 20 files, just to get around some of the
		 * network problems that can occur.
		 */
		if (((mCurrentFile+1) % 20) == 0 || mCurrentFile == 0)
		{
			if (vJustConnected)
				vJustConnected = false;
			else
			{
				mClient->Disconnect();
				if (ZULU_GUI_APP()->GetCurrentUser(&vInfo) == false)
					return;
				mZSPThread->ProcessUser(vInfo->mUserName, vInfo->mPswdHash, false);
				mZSPThread->start();
				vJustConnected = true;
				return;
			}
		}
		QString vStrText;
		mCurrentFile++;
		vCurFile++;
		mCurrentBytes = 0L;

		vIt = mFiles.begin();
		SwitchFile((*vIt), mCurrentFile);

		/*
		 * Start the upload
		 */
		QFileInfo vInfo((*vIt).mName);
		vXInfo.mFile = vInfo.absFilePath();
		vXInfo.mName = vInfo.fileName();
		vXInfo.mBatch = mID;
		mClient->SendFile(vXInfo, CallbackFunc, true);
	}
}

/*------------------------------------------------------------------*
 *							  UpdateDisplay()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Updates all the display fields with new data.
 *
 *	@author		Josh Williams
 *	@date		17-Jan-2006
 *
 *	@param		pCurrPerc
 *					Percentage of the current file that has been
 *					uploaded.
 *	@param		pSpeed
 *					Current upload speed.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZUploadBatch::UpdateDisplay(float pCurrPerc, float pSpeed)
{
	ZULONG	vProgress;
	SetCurrPercent(QString("<b>%1%</b> uploaded").arg(static_cast<long>(pCurrPerc * 100), 3));
	qDebug(QString("%1::Speed reported: %2").arg(__FILE__).arg(pSpeed, 3, 'f', 1));
	if (pSpeed > (1024.0f * 1024.0f))
		SetSpeed(QString("%1 Mb/sec").arg(pSpeed / (1024.0f*1024.0f), 3, 'f', 1));
	else if (pSpeed > 1024.0f)
		SetSpeed(QString("%1 Kb/sec").arg(pSpeed / 1024.0f, 3, 'f', 1));
	else
		SetSpeed(QString("%1 b/sec").arg(pSpeed, 3, 'f', 1));

	vProgress = (ZUINT)((float)mUploadBytes / (float)mTotalBytes * 100.0f);
	SetProgress(vProgress);
}

/*------------------------------------------------------------------*
 *								Rotate()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Rotates the photo on the server.
 *
 *	@author		Josh Williams
 *	@date		11-Apr-2006
 *
 *	@param		pMD5
 *					File to be rotated.
 *	@param 		pCount
 *					Number of times to rotate the photo.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZUploadBatch::Rotate(const QString &pMD5, int pCount)
{
	ZUserInfo	*vInfo = NULL;
	static QString vImageId;

	if (ZULU_GUI_APP()->GetCurrentUser(&vInfo) == false)
		return;

	qDebug(QString("%1::Rotating image %2 times").arg(__FILE__).arg(pCount));

	if ((0 < pCount) && (pCount < 4))
	{
		mZAPIThread->RotateImage(vInfo, pMD5, pCount);
	}
	else
	{
		vImageId = pMD5;
		ZStatusEvent *vEvt = new ZStatusEvent(ZStatusEvent::IMAGE_ROTATE);
		vEvt->mErrcode = ZERR_SUCCESS;
		vEvt->setData(static_cast<void *>(&vImageId));
		QApplication::postEvent(this, vEvt);
	}
}

#ifdef ZOTO_TAGGING
/*------------------------------------------------------------------*
 *								  Tag()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Adds the supplied images to the specified tag.
 *
 *	@author		Josh Williams
 *	@date		17-Jan-2006
 *
 *	@param		pMD5
 *					File to be tagged.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZUploadBatch::Tag(const QString &pMD5)
{
	QStringList::Iterator	vIt;
	ZUserInfo				*vInfo;

	if (ZULU_GUI_APP()->GetCurrentUser(&vInfo) == false)
		return;

	qDebug(QString("%1::%2 tags in the list").arg(__FILE__).arg(static_cast<int>(mTags.size())));

	for (vIt = mTags.begin(); vIt != mTags.end(); vIt++)
	{
		qDebug(QString("%1::Tagging %2 with tag %3").arg(__FILE__).arg(pMD5.latin1()).arg((*vIt).latin1()));
		mZAPIThread->Tag(vInfo, pMD5, *vIt);
	}
}
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
/*------------------------------------------------------------------*
 *							  Galleryize()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Adds the specified image to the tags defined for
 *				this batch.
 *
 *	@author		Josh Williams
 *	@date		30-Mar-2006
 *
 *	@param		pMD5
 *					File to be tagged.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZUploadBatch::Galleryize()
{
	ZUserInfo				*vInfo;
	QStringList::const_iterator vIt;

	qDebug(QString("%1::Gallery count => %2").arg(__FILE__).arg(static_cast<int>(mGalleries.count())));
	qDebug(QString("%1::Image count   => %2").arg(__FILE__).arg(static_cast<int>(mGalleryImgs.count())));

	qDebug(QString("%1::Images==============").arg(__FILE__));
	for (vIt = mGalleryImgs.begin(); vIt != mGalleryImgs.end(); vIt++)
		qDebug(QString("%1::%2").arg(__FILE__).arg(*vIt));

	if (mGalleries.count() <= 0 || mGalleryImgs.count() <= 0)
		return;

	if (ZULU_GUI_APP()->GetCurrentUser(&vInfo) == false)
		return;

	for (vIt = mGalleries.begin(); vIt != mGalleries.end(); vIt++)
	{
		qDebug(QString("%1::Adding to gallery %2").arg(__FILE__).arg(vIt));
		mZAPIThread->AddToGallery(vInfo, mGalleryImgs, *vIt);
		qDebug(QString("%1::Called").arg(__FILE__));
	}
}
#endif

} // End Namespace

/* vi: set ts=4: */
