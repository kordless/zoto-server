/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "GalleryChecker.h"

/* System Headers */
#include <qmessagebox.h>
#include <qtimer.h>

/* Local Headers */
#include "ZAPIThread.h"
#include "Events.h"
#include "Types.h"
#include "GuiApp.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZGalleryChecker::ZGalleryChecker(const QString &pGallery, QWidget *pParent /*=0*/, const char *pName /*=0*/)
	: QProgressDialog(pParent, pName, 0), mGallery(pGallery)
{
	setCaption(ZULU_GUI_APP()->GetAppName());

	setLabelText("Checking to see if requested name is available...");
	mZAPIThread = new ZZAPIThread(this);
	mTimer = new QTimer(this);

	setTotalSteps(5);
	setProgress(0);

	/* Signals and Slots */
	connect(this, SIGNAL(canceled()), this, SLOT(OnCancel()));
	connect(mTimer, SIGNAL(timeout()), this, SLOT(UpdateProgress()));
}

ZGalleryChecker::~ZGalleryChecker()
{
	if (mZAPIThread)
		delete mZAPIThread;
}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 31-Mar-2006 */
void ZGalleryChecker::show()
{
	mTimer->start(250);
	ZUserInfo *vInfo = NULL;
	ZULU_GUI_APP()->GetCurrentUser(&vInfo);
	mZAPIThread->CheckGallery(vInfo, mGallery);
	QDialog::show();
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/* 31-Mar-2006 */
void ZGalleryChecker::customEvent(QCustomEvent *pEvt)
{
	int vZResult;

	if (this->wasCanceled())
		return;

	if (pEvt->type() == ZSTATUS)
	{
		ZStatusEvent *vEvt = dynamic_cast<ZStatusEvent *>(pEvt);
		if (vEvt->mType == ZStatusEvent::CHECK_GALLERY)
		{
			mTimer->stop();
			if (vEvt->mErrcode == ZERR_SUCCESS)
			{
				vZResult = *(static_cast<int *>(vEvt->data()));
				if (vZResult == 0)
				{
					accept();
					return;
				}
				else
				{
					QMessageBox::warning(this, ZULU_GUI_APP()->GetAppName() + tr(" - Gallery"),
								tr("The specified gallery url is already in use.\n"
								"Please choose a different URL and try again."));
					reject();
					return;
				}
			}
			else
			{
				ZGuiApp::ShowCommError("Gallery");
			}
		}
	}
}

/* 31-Mar-2006 */
void ZGalleryChecker::OnCancel()
{
	mTimer->stop();
	mZAPIThread->Cancel();
	QProgressDialog::cancel();
}

/* 31-Mar-2006 */
void ZGalleryChecker::UpdateProgress()
{
	if (progress() >= 10)
		setProgress(0);
	else
		setProgress(progress() + 1);
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
