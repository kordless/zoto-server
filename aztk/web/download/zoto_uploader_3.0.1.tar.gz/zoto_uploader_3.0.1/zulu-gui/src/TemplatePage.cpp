/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "TemplatePage.h"

/* System Headers */
#include <qlistbox.h>
#include <qlabel.h>
#include <qlayout.h>

/* Local Headers */
#include "GuiApp.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZTemplatePage::ZTemplatePage(QWidget *pParent /*=0*/, const char *pName /*=0*/, WFlags pFlags /*=0*/)
	: ZWizardPage(pParent, pName, pFlags)
{
	QHBoxLayout *vOuterLayout = new QHBoxLayout(this, 0, 15, "OuterLayout");

	QFont vItalic(ZULU_GUI_APP()->mainWidget()->font());
	QFont vBold(vItalic);
	vItalic.setItalic(true);
	vBold.setBold(true);

	mTemplates = new QListBox(this);
	mTemplates->setMinimumHeight(300);
	mTemplates->setMinimumWidth(300);
	vOuterLayout->addWidget(mTemplates);

	QVBoxLayout *vRightLayout = new QVBoxLayout(vOuterLayout, 0, "Right Layout");

	mTemplLbl = new QLabel(tr("Currently Selected Template:"), this);
	mTemplLbl->setPaletteForegroundColor(Qt::gray);
	vRightLayout->addWidget(mTemplLbl);

	mTemplName = new QLabel(tr(""), this);
	mTemplName->setPaletteForegroundColor(Qt::gray);
	mTemplName->setFont(vItalic);
	vRightLayout->addWidget(mTemplName);

	vRightLayout->addSpacing(5);

	mThumb = new QLabel(this);
	vRightLayout->addWidget(mThumb);

	vRightLayout->addSpacing(20);

	QLabel *vHeaderLbl = new QLabel(tr("Select A Header Bar Color"), this);
	vHeaderLbl->setFont(vBold);
	vRightLayout->addWidget(vHeaderLbl);

	vRightLayout->addSpacing(10);

	mWrappers = new QComboBox(this);
	mWrappers->setMaximumWidth(100);
	vRightLayout->addWidget(mWrappers);

	vRightLayout->addStretch(100);

	/* Signals and Slots */
	connect(mTemplates, SIGNAL(selectionChanged(QListBoxItem *)),
			this, SLOT(UpdateThumb(QListBoxItem *)));

}

ZTemplatePage::~ZTemplatePage()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/* 03-Apr-2006 */
int ZTemplatePage::GetSelectedTemplate() const
{
	ZTemplateItem *vItem = dynamic_cast<ZTemplateItem *>(mTemplates->selectedItem());
	if (vItem)
		return vItem->GetInfo()->mId;
	else
		return -1;
}

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								Init()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Initializes this page with the user info provided.
 *
 *	@author		Josh Williams
 *	@date		31-Mar-2006
 *
 *	@param		pInfo
 *					User information used to initialize.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZTemplatePage::Init(ZUserInfo *pInfo)
{
	QIntDictIterator<ZTemplateInfo> vIt(pInfo->mTemplateMap);
	QStringList::const_iterator vIt2;
	ZTemplateItem *vItem;

	for ( ; vIt.current(); ++vIt)
		new ZTemplateItem(mTemplates, vIt.current());

	
	for (vIt2 = pInfo->mWrappers.begin(); vIt2 != pInfo->mWrappers.end(); vIt2++)
	{
		mWrappers->insertItem(*vIt2);
	}

	vItem = dynamic_cast<ZTemplateItem *>(mTemplates->firstItem());
	mTemplates->setCurrentItem(vItem);
}

/*------------------------------------------------------------------*
 *							  SetActive()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Notifies this page that it is now the active page.
 *
 *	@author		Josh Williams
 *	@date		31-Mar-2006
 *
 *	@param		pActive
 *					Whether we are now active or inactive.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZTemplatePage::SetActive(bool pActive)
{
	if (pActive)
		emit Ready();
}

/*------------------------------------------------------------------*
 *							  StoreData()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Instructs this page to store any relevant data for
 *				processing.
 *
 *	@author		Josh Williams
 *	@date		31-Mar-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZTemplatePage::StoreData()
{
	return;
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							UpdateThumb()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Updates the thumbnail for the currently selected 
 *				template.
 *
 *	@author		Josh Williams
 *	@date		31-Mar-2006
 *
 *	@param		pItem
 *					Newly selected item.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZTemplatePage::UpdateThumb(QListBoxItem *pItem)
{
	ZTemplateItem	*vItem;

	vItem = dynamic_cast<ZTemplateItem *>(pItem);

	mTemplName->setText(vItem->GetInfo()->mName);

	mThumb->setPixmap(vItem->GetInfo()->mThumb);
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

class TemplatePageMaker : public PageMaker
{
public:
	TemplatePageMaker() : PageMaker("ZTemplatePage") {}
private:
	ZWizardPage* MakePage(QWidget *pParent, const char *pName, ZUINT pFlags)
	{
		return new ZTemplatePage(pParent, pName, pFlags);
	}
	static const TemplatePageMaker mRegister;
};
const TemplatePageMaker TemplatePageMaker::mRegister;

} // End Namespace

/* vi: set ts=4: */
