/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "GalleryPage.h"

/* System Headers */
#include <qlayout.h>
#include <qhbox.h>
#include <qlabel.h>
#include <qpushbutton.h>

/* Local Headers */
#include "GuiApp.h"
#include "HeaderBar.h"
#include "URLLabel.h"
#include "WizardDlg.h"
#include "NewGalleryPage.h"
#include "TemplatePage.h"
#include "GalleryCreator.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZGalleryPage::ZGalleryPage(QWidget *pParent /*=0*/, const char *pName /*=0*/,
				WFlags pFlags /*=0*/)
	: ZWizardPage(pParent, pName, pFlags)
{
	QVBoxLayout *vOuterLayout = new QVBoxLayout(this, 0, 20, "OuterLayout");

	QFont	vBold(font());
	vBold.setBold(true);

	mCreate = new QPushButton(tr("Create"), this);
	mCreate->setMaximumWidth(75);
	vOuterLayout->addWidget(mCreate, 0, Qt::AlignLeft);

	QFrame *vSep = new QFrame(this);
	vSep->setFrameStyle(QFrame::Sunken | QFrame::HLine);
	vOuterLayout->addWidget(vSep);

	mAddLbl = new QLabel(tr("I want to add my photos to an existing Gallery"), this);
	mAddLbl->setFont(vBold);
	vOuterLayout->addWidget(mAddLbl, 0, Qt::AlignLeft);

	QHBox *vMainBox = new QHBox(this);
	vMainBox->setSpacing(10);

	mGalleryList = new QListBox(vMainBox);
	mGalleryList->setMinimumSize(QSize(250, 150));

	mGalleryInfo = new QFrame(vMainBox);
	mGalleryInfo->setMinimumSize(QSize(200, 150));

	QVBoxLayout *vInfoLayout = new QVBoxLayout(mGalleryInfo, 0, 10);

	mGalleryURLLbl = new QLabel(tr("Gallery URL:"), mGalleryInfo);
	vInfoLayout->addWidget(mGalleryURLLbl);

	mGalleryURL = new ZURLLabel(QColor(63, 30, 232), Qt::blue, mGalleryInfo, "Gallery URL");
	mGalleryURL->setText("");
	mGalleryURL->SetURL("");
	vInfoLayout->addWidget(mGalleryURL);

	mGalleryThumb = new QLabel(tr("PREVIEW"), mGalleryInfo);
	mGalleryThumb->setAlignment(Qt::AlignCenter);
	mGalleryThumb->setPaletteForegroundColor(Qt::gray);
	mGalleryThumb->setFrameStyle(QFrame::Panel | QFrame::Plain);
	vInfoLayout->addWidget(mGalleryThumb, 100, Qt::AlignTop | Qt::AlignLeft);

	vOuterLayout->addWidget(vMainBox);

	/* Signals and slots */
	connect(mGalleryList, SIGNAL(selectionChanged(QListBoxItem *)),
				this, SLOT(UpdateInfo(QListBoxItem *)));
	connect(mCreate, SIGNAL(clicked()), this, SLOT(NewGallery()));
}

ZGalleryPage::~ZGalleryPage()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/* 30-Mar-2006 */
int ZGalleryPage::GetSelectedGalleries(QStringList &pGalleries) const
{
	QListBoxItem *vItem = mGalleryList->firstItem();

	while (vItem)
	{
		if (vItem->isSelected())
			pGalleries.append(dynamic_cast<ZGalleryItem *>(vItem)->GetInfo()->mName);
		vItem = vItem->next();
	}

	qDebug("ZGalleryPage::GetSelectedGalleries() count => %d", static_cast<int>(pGalleries.count()));
	return pGalleries.count();
}

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 28-Mar-2006 */
void ZGalleryPage::Init(ZUserInfo *pInfo)
{
	QDictIterator<ZGalleryInfo> vIt(pInfo->mGalleryMap);

	for ( ; vIt.current(); ++vIt)
		new ZGalleryItem(mGalleryList, vIt.current());

	ZGalleryItem *vItem = dynamic_cast<ZGalleryItem *>(mGalleryList->firstItem());
	mGalleryThumb->setMinimumSize(pInfo->mTemplateMap[vItem->GetInfo()->mTemplate]->mThumb.size());

	mUserInfo = pInfo;
}

/* 28-Mar-2006 */
void ZGalleryPage::SetActive(bool pActive)
{
	if (pActive)
	{
		mCreateNew = false;
		emit Ready();
	}
}

/* 29-Mar-2006 */
void ZGalleryPage::StoreData()
{
	return;
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/* 29-Mar-2006 */
void ZGalleryPage::NewGallery()
{
	/*
	 * Start the prompting.
	 */
	ZUserInfo *vInfo = NULL;
	ZULU_GUI_APP()->GetCurrentUser(&vInfo);

	ZWizardDlg vDlg(this, "New Gallery", true);

	ZNewGalleryPage *vNewGallery = new ZNewGalleryPage(&vDlg);
	vNewGallery->Init(vInfo);
	vDlg.AddPage(vNewGallery);

	ZTemplatePage *vTemplates = new ZTemplatePage(&vDlg);
	vTemplates->Init(vInfo);
	vDlg.AddPage(vTemplates);

	if (vDlg.exec() == QDialog::Accepted)
	{
		/*
		 * Create the gallery.
		 */
		ZGalleryInfo *vGallery = new ZGalleryInfo();
		vGallery->mName			= vNewGallery->GetName();
		vGallery->mTitle		= vNewGallery->GetTitle();
		vGallery->mDesc			= vNewGallery->GetDesc();
		vGallery->mPwProtect	= vNewGallery->GetPwProtect();
		vGallery->mPassword		= vNewGallery->GetPassword();
		vGallery->mTemplate		= vTemplates->GetSelectedTemplate();
		vGallery->mWrapper		= vTemplates->GetSelectedWrapper();


		ZGalleryCreator vDlg(vGallery, this, "Gallery Creator");

		if (vDlg.exec() == QDialog::Accepted)
		{
			mUserInfo->mGalleryMap.insert(vGallery->mName, vGallery);
			ZGalleryItem *vItem = new ZGalleryItem(mGalleryList, vGallery);
			mGalleryList->setSelected(vItem, true);
		}
	}
}

/* 29-Mar-2006 */
void ZGalleryPage::UpdateInfo(QListBoxItem *pItem)
{
	ZGalleryItem	*vItem = NULL;
	ZUserInfo		*vInfo = NULL;
	int				vTemplateId = 0;

	vItem = dynamic_cast<ZGalleryItem *>(pItem);
	ZULU_GUI_APP()->GetCurrentUser(&vInfo);

	vTemplateId = vItem->GetInfo()->mTemplate;
	QString vURL = ZULU_GUI_APP()->MakeURL(ZOTO_GALLERY_URL, vInfo->mUserName, vItem->GetInfo()->mName);
	mGalleryThumb->setPixmap((vInfo->mTemplateMap[vTemplateId]->mThumb));
	mGalleryURL->setText(vURL);
	mGalleryURL->SetURL(vURL);
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/


class GalleryPageMaker : public PageMaker
{
public:
	GalleryPageMaker() : PageMaker("ZGalleryPage") {}
private:
	ZWizardPage* MakePage(QWidget *pParent, const char *pName, ZUINT pFlags)
	{
		return new ZGalleryPage(pParent, pName, pFlags);
	}
	static const GalleryPageMaker mRegister;
};
const GalleryPageMaker GalleryPageMaker::mRegister;

} // End Namespace

/* vi: set ts=4: */
