/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "NewGalleryPage.h"

/* System Headers */
#include <qlayout.h>
#include <qlabel.h>
#include <qbuttongroup.h>
#include <qpushbutton.h>
#include <qmessagebox.h>

/* Local Headers */
#include "GuiApp.h"
#include "GalleryChecker.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZNewGalleryPage::ZNewGalleryPage(QWidget *pParent /*=0*/, const char *pName /*=0*/,
				WFlags pFlags /*=0*/)
	: ZWizardPage(pParent, pName, pFlags)
{
	QVBoxLayout *vOuterLayout = new QVBoxLayout(this, 0, 10, "OuterLayout");

	QFont vBold(ZULU_GUI_APP()->mainWidget()->font());
	vBold.setBold(true);

	QWidget *vMainWidget = new QWidget(this);
	QVBoxLayout *vMainLayout = new QVBoxLayout(vMainWidget, 0, 0);

	/* TITLE SECTION */
	QLabel *vTitleLbl = new QLabel(tr("Title:"), vMainWidget);
	vMainLayout->addWidget(vTitleLbl, 0);

	QHBoxLayout *vTitleLayout = new QHBoxLayout(vMainLayout, 5);
	mTitle = new QLineEdit(vMainWidget);
	mTitle->setFixedWidth(150);
	vTitleLayout->addWidget(mTitle);

	QLabel *vTitleReq = new QLabel(tr("(<font color=red>*</font> <i>required</i>)"), vMainWidget);
	vTitleLayout->addWidget(vTitleReq);
	vTitleLayout->addStretch(100);
	vMainLayout->addSpacing(5);

	/* URL SECTION */
	QHBoxLayout *vURLLblLayout = new QHBoxLayout(vMainLayout, 0, 0);
	vURLLblLayout->setResizeMode(QLayout::Fixed);
	QLabel *vURLLbl1 = new QLabel(tr("Gallery URL: "), vMainWidget);
	vURLLblLayout->addWidget(vURLLbl1);
	mURLLbl2 = new QLabel("", vMainWidget);
	vURLLblLayout->addWidget(mURLLbl2);
	vURLLblLayout->addStretch(100);

	QHBoxLayout *vURLLayout = new QHBoxLayout(vMainLayout, 5);
	mURL = new QLineEdit(vMainWidget);
	mURL->setFixedWidth(150);
	vURLLayout->addWidget(mURL);

	QLabel *vURLReq = new QLabel(tr("(<font color=red>*</font> <i>required</i>)"), vMainWidget);
	vURLLayout->addWidget(vURLReq);
	vURLLayout->addStretch(100);
	vMainLayout->addSpacing(5);

	/* DESCRIPTION SECTION */
	QLabel *vDescLbl = new QLabel(tr("Description:"), vMainWidget);
	vMainLayout->addWidget(vDescLbl);

	mDesc = new QTextEdit(vMainWidget);
	mDesc->setTextFormat(PlainText);
	mDesc->setMinimumWidth(300);
	mDesc->setMaximumWidth(300);
	vMainLayout->addWidget(mDesc);
	vMainLayout->addSpacing(5);

	QButtonGroup *vRadios = new QButtonGroup(2, Qt::Horizontal, vMainWidget);
	vRadios->setSizePolicy(QSizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum));
	vRadios->setInsideSpacing(5);
	vRadios->setFrameStyle(QFrame::NoFrame);
	mPublic = new QRadioButton(tr("Public"), vRadios);
	mPublic->setChecked(true);

	mPrivate = new QRadioButton(tr("Private"), vRadios);
	vMainLayout->addWidget(vRadios);
	vMainLayout->addSpacing(5);

	QLabel *vPswdLbl = new QLabel(tr("Password:"), vMainWidget);
	vMainLayout->addWidget(vPswdLbl);

	mPswd = new QLineEdit(vMainWidget);
	mPswd->setEchoMode(QLineEdit::Password);
	mPswd->setMaximumWidth(150);
	mPswd->setEnabled(false);
	vMainLayout->addWidget(mPswd);
	vMainLayout->addSpacing(10);

	vOuterLayout->addWidget(vMainWidget, 0, Qt::AlignLeft);

	/* Signals and Slots */
	connect(mURL, SIGNAL(lostFocus()), this, SLOT(ValidateURL()));
	connect(mURL, SIGNAL(textChanged(const QString &)), this, SLOT(TextChanged(const QString &)));
	connect(mTitle, SIGNAL(textChanged(const QString &)), this, SLOT(TextChanged(const QString &)));
	connect(mPswd, SIGNAL(textChanged(const QString &)), this, SLOT(TextChanged(const QString &)));
	connect(mPublic, SIGNAL(toggled(bool)), this, SLOT(PasswordChecked(bool)));
	connect(mPrivate, SIGNAL(toggled(bool)), this, SLOT(PasswordChecked(bool)));
}

ZNewGalleryPage::~ZNewGalleryPage()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 28-Mar-2006 */
void ZNewGalleryPage::Init(ZUserInfo *pInfo)
{
	mUserInfo = pInfo;
	mURLLbl2->setText(ZULU_GUI_APP()->MakeURL(ZOTO_GALLERY_URL, mUserInfo->mUserName));
}

/* 28-Mar-2006 */
void ZNewGalleryPage::SetActive(bool pActive)
{
	Q_UNUSED(pActive);
}

/* 29-Mar-2006 */
void ZNewGalleryPage::StoreData()
{

}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/
/* 31-Mar-2006 */
void ZNewGalleryPage::PasswordChecked(bool pOn)
{
	if (sender() == mPrivate)
		mPswd->setEnabled(pOn);

	CheckIfReady();
}

/* 31-Mar-2006 */
void ZNewGalleryPage::ValidateURL()
{
	QWidget *vFocus = focusWidget();

	if (vFocus == mURL || vFocus == NULL)
		return;
	else
	{
		ZGalleryChecker vDlg(mURL->text(), this, "Gallery Checker");
	
		if (vDlg.exec() == QDialog::Rejected)
			mURL->setFocus();
		else
		{
			vFocus->setFocus();
			CheckIfReady();
		}
	}
}

/* 03-Apr-2006 */
void ZNewGalleryPage::TextChanged(const QString &pText)
{
	if (sender() == mURL)
		mURLLbl2->setText(ZULU_GUI_APP()->MakeURL(ZOTO_GALLERY_URL, mUserInfo->mUserName, pText));
	CheckIfReady();
}

/* 03-Apr-2006 */
void ZNewGalleryPage::CheckIfReady()
{
	if (mTitle->text().length() < 4 ||
		mURL->text().length() < 4 ||
		(mPrivate->isChecked() && mPswd->text().length() < 4))
		emit NotReady();
	else
		emit Ready();
}

	

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

class NewGalleryPageMaker : public PageMaker
{
public:
	NewGalleryPageMaker() : PageMaker("ZNewGalleryPage") {}
private:
	ZWizardPage* MakePage(QWidget *pParent, const char *pName, ZUINT pFlags)
	{
		return new ZNewGalleryPage(pParent, pName, pFlags);
	}
	static const NewGalleryPageMaker mRegister;
};
const NewGalleryPageMaker NewGalleryPageMaker::mRegister;

} // End Namespace

/* vi: set ts=4: */
