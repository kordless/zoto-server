/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "TagPage.h"

/* System Headers */
#include <qlayout.h>
#include <qcombobox.h>
#include <qpushbutton.h>
#include <qlistbox.h>
#include <qlabel.h>
#include <qhbox.h>
#include <qframe.h>

/* Local Headers */
#include "GuiApp.h"
#include "TagItem.h"
#include "Utils.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZTagPage::ZTagPage(QWidget *pParent /*=0*/, const char *pName /*=0*/,
				WFlags pFlags /*=0*/)
	: ZWizardPage(pParent, pName, pFlags)
{
	QVBoxLayout *vOuterLayout = new QVBoxLayout(this, 0, 15);

	QFont vFont(ZULU_GUI_APP()->mainWidget()->font());
	QFont vBold(vFont);
	vBold.setBold(true);

	QHBox *vAddBox = new QHBox(this);
	vAddBox->setSpacing(15);

	mTagEdit = new QComboBox(true, vAddBox, "Tag Edit");
	mTagEdit->setMinimumWidth(250);
	mTagEdit->setMaximumWidth(250);
	mTagEdit->setAutoCompletion(true);

	mAddButton = new QPushButton(tr("Add Tag"), vAddBox, "Add Button");
	mAddButton->setMaximumWidth(100);

	vOuterLayout->addWidget(vAddBox, 0, Qt::AlignLeft);

	QLabel *vMiddle = new QLabel(tr("The following tag or tags have been assigned "
				"to this batch of photos.\nSelect tags from the list below to remove them."), this);
	vMiddle->setFont(vBold);
	vOuterLayout->addWidget(vMiddle);

	QFrame *vBottomFrame = new QFrame(this);
	QVBoxLayout *vBottomBox = new QVBoxLayout(vBottomFrame, 0, 15);
	vBottomBox->addStrut(250);

	mAddedTags = new QListBox(vBottomFrame, "ListView");
	mAddedTags->setFont(vFont);
	mAddedTags->setMinimumWidth(250);
	mAddedTags->setMaximumWidth(250);
	vBottomBox->addWidget(mAddedTags, 0, Qt::AlignLeft);

	mRemButton = new QPushButton(tr("Remove Tag"), vBottomFrame, "Remove Button");
	mRemButton->setEnabled(false);
	vBottomBox->addWidget(mRemButton, 0, Qt::AlignRight);

	vOuterLayout->addWidget(vBottomFrame, 0, Qt::AlignLeft);

	/* Signals and slots */
	connect(mAddButton, SIGNAL(clicked()),
				this, SLOT(AddNewTag()));
	connect(mTagEdit, SIGNAL(textChanged(const QString &)),
				this, SLOT(ValidateText(const QString &)));
	connect(mAddedTags, SIGNAL(selectionChanged(QListBoxItem *)),
				this, SLOT(EnableRemove(QListBoxItem *)));
	connect(mRemButton, SIGNAL(clicked()),
				this, SLOT(RemoveSelected()));
}

ZTagPage::~ZTagPage()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							GetSelectedTags()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Gets the list of tag id's currently selected by
 *				the user.
 *	@author		Josh Williams
 *	@date		14-Aug-2005
 *
 *	@param		pTags
 *					List to be populated.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZTagPage::GetSelectedTags(QStringList& pTags)
{
	for (ZUINT i = 0; i < mAddedTags->count(); i++)
	{
		pTags.append(mAddedTags->text(i));
	}
}

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								LoadTags()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Loads the list of tags received from the ZAPI server
 *				into the view.
 *	@author		Josh Williams
 *	@date		23-Apr-2005
 *
 *	@param		pTags
 *					List of tags received.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZTagPage::LoadTags(const QStringList &pTags)
{
	mAddedTags->clear();
	qDebug("%s::Loading tags.  Top level tags: %d", __FILE__, (int)pTags.size());
	for (QStringList::ConstIterator vIt = pTags.begin(); vIt != pTags.end(); ++vIt)
	{
		mTagEdit->insertItem(*vIt);
	}

	mTagEdit->setCurrentText("");
}

/*------------------------------------------------------------------*
 *								AddTag()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Actually adds an individual tag to the correct
 *				location in the view.
 *	@author		Josh Williams
 *	@date		23-Apr-2005
 *
 *	@param		pParent
 *					View/item that is to be the parent of this tag.
 *	@param		pTag
 *					Tag to be added.
 *	@param		pTopLevel
 *					Whether this is one of the main tags (who, what, etc).
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZTagPage::AddTag(const QString &pTag)
{
	Q_UNUSED(pTag);
}

/* 28-Mar-2006 */
void ZTagPage::Init(ZUserInfo *pInfo)
{
	LoadTags(pInfo->mTags);
	mUserInfo = pInfo;
}

/* 28-Mar-2006 */
void ZTagPage::SetActive(bool pActive)
{
	if (pActive)
	{
		if (mUserInfo->mTagging)
			emit Ready();
		else
			emit GoNext();
	}
}

/* 29-Mar-2006 */
void ZTagPage::StoreData()
{
	return;
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								EditTags()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Launches the user's browser when the "Edit Tags" button
 *				is pressed.
 *	@author		Josh Williams
 *	@date		23-Apr-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZTagPage::AddNewTag()
{
	if (mAddedTags->findItem(mTagEdit->currentText()) == NULL)
	{
		mAddedTags->insertItem(mTagEdit->currentText());
		mTagEdit->setCurrentText("");
	}
}

/* 05-Apr-2006 */
void ZTagPage::ValidateText(const QString &pString)
{
	if (pString.length() > 0)
		mAddButton->setDefault(true);
	else
	{
		mAddButton->setDefault(false);
		emit Ready();
	}
}

/* 05-Apr-2006 */
void ZTagPage::EnableRemove(QListBoxItem *pItem)
{
	qDebug("EnableRemove called: %p", pItem);
	if (pItem != NULL)
	{
		qDebug("Item is not null");
		mRemButton->setEnabled(true);
	}
	else
	{
		qDebug("Item is null");
		mRemButton->setEnabled(false);
	}
}

/* 05-Apr-2006 */
void ZTagPage::RemoveSelected()
{
	mAddedTags->removeItem(mAddedTags->currentItem());
	mAddedTags->clearSelection();
	mRemButton->setEnabled(false);
	mTagEdit->setFocus();
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/


class TagPageMaker : public PageMaker
{
public:
	TagPageMaker() : PageMaker("ZTagPage") {}
private:
	ZWizardPage* MakePage(QWidget *pParent, const char *pName, ZUINT pFlags)
	{
		return new ZTagPage(pParent, pName, pFlags);
	}
	static const TagPageMaker mRegister;
};
const TagPageMaker TagPageMaker::mRegister;
} // End Namespace

/* vi: set ts=4: */
