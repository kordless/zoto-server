/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "OptionsPage.h"

/* System Headers */
#include <qlayout.h>
#include <qframe.h>
#include <qlabel.h>
#include <qpixmap.h>
#include <qbuttongroup.h>

/* Local Headers */
#include "HeaderBar.h"
#include "GuiApp.h"
#include "Types.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZOptionsPage::ZOptionsPage(QWidget *pParent /*=0*/, const char *pName /*=0*/,
				WFlags pFlags /*=0*/)
	: ZWizardPage(pParent, pName, pFlags)
{
	QVBoxLayout *vOuterLayout = new QVBoxLayout(this, 10, 0);

	/* Top - Header */
	QHBox *vTopFrame = new QHBox(this, "TopFrame");
	vTopFrame->setMargin(10);
	vTopFrame->setSpacing(20);
	vTopFrame->setSizePolicy(QSizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding, 100, 100));
	vTopFrame->setPaletteBackgroundColor(Qt::white);
	vTopFrame->setFrameStyle(QFrame::Sunken | QFrame::Box);

	QLabel *vImgLbl = new QLabel(vTopFrame);	
	vImgLbl->setPixmap(QPixmap::fromMimeSource("wizard.png"));

	QLabel *vTopText = new QLabel(tr("Would you like to manage your photos\n"
				"before you upload them to the web?"), vTopFrame);
	QFont vFont("Sans Serif", ZULU_GUI_APP()->mainWidget()->font().pointSize() + 2);
	vTopText->setFont(vFont);
	vTopFrame->setStretchFactor(vTopText, 100);

	vOuterLayout->addWidget(vTopFrame);
	vOuterLayout->addSpacing(10);

	/* Yes - Checkboxes */
	QHBox *vYesBox = new QHBox(this, "YesBox");
	vYesBox->setSpacing(10);
	mYes = new QRadioButton(vYesBox, "Yes");
	QLabel *vYesLbl = new QLabel(tr("<b>Yes, I would</b> like to manage these photos "
								"before uploading them."), vYesBox);
	vYesBox->setStretchFactor(vYesLbl, 100);

	vOuterLayout->addWidget(vYesBox, 100);

	QVBox *vCheckBox = new QVBox(this, "CheckBox");
	vCheckBox->setMargin(20);

#ifdef ZOTO_TAGGING
	mTags = new QCheckBox(tr("Add Smart Tag Keywords"), vCheckBox);
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	mGalleries = new QCheckBox(tr("Add Photos to Galleries"), vCheckBox);
#endif // ZOTO_TAGGING

	vOuterLayout->addWidget(vCheckBox);

	/* No */
	QHBox *vNoBox = new QHBox(this, "NoBox");
	vNoBox->setSpacing(10);
	mNo = new QRadioButton(vNoBox, "No");
	QLabel *vNoLbl = new QLabel(tr("<b>No, Thanks.</b>  I will go online to manage them later.  "
								"Please<br />upload these photos to my Zoto.com immediately!  I have "
								"a life and I want to get back to it."), vNoBox);
	vNoBox->setStretchFactor(vNoLbl, 90);

	vOuterLayout->addWidget(vNoBox, 100);
	vOuterLayout->addSpacing(20);
	/*

	QFrame *vSep = new QFrame(this);
	vSep->setFrameStyle(QFrame::HLine | QFrame::Sunken);
	vOuterLayout->addWidget(vSep);
	vOuterLayout->addSpacing(20);

	QHBox *vRemBox = new QHBox(this);
	vRemBox->setSpacing(10);
	mRemember = new QCheckBox(vRemBox);
	QLabel *vRemLbl = new QLabel(tr("<b>I want to keep these preferences</b> each time I launch "
							"this<br />application.  Do not show me this box again."), vRemBox);
	vRemBox->setStretchFactor(vRemLbl, 100);
	vOuterLayout->addWidget(vRemBox);
	*/

	QButtonGroup *vExcl = new QButtonGroup(this);
	vExcl->hide();
	vExcl->insert(mYes);
	vExcl->insert(mNo);

	/* Signals and Slots */
	connect(mYes, SIGNAL(toggled(bool)), this, SLOT(Checks(bool)));
	connect(mNo, SIGNAL(toggled(bool)), this, SLOT(Checks(bool)));
#ifdef ZOTO_TAGGING
	connect(mTags, SIGNAL(toggled(bool)), this, SLOT(Checks(bool)));
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	connect(mGalleries, SIGNAL(toggled(bool)), this, SLOT(Checks(bool)));
#endif // ZOTO_GALLERIES
}

ZOptionsPage::~ZOptionsPage()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

void ZOptionsPage::Init(ZUserInfo *pInfo)
{
	qDebug("ZOptionsPage::Init()");
#ifdef ZOTO_TAGGING
	if (pInfo->mTagging)
	{
		mYes->setChecked(true);
		mTags->setChecked(pInfo->mTagging);
	}
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
	if (pInfo->mGalleries)
	{
		mYes->setChecked(true);
		mGalleries->setChecked(pInfo->mGalleries);
	}
#endif // ZOTO_GALLERIES

	if (!mYes->isChecked())
		mNo->setChecked(true);

	/*
	if (pInfo->mRemember)
		mRemember->setChecked(true);
	*/

	mUserInfo = pInfo;
}

void ZOptionsPage::SetActive(bool pActive)
{
	qDebug("ZOptionsPage::SetActive(%s)", pActive ? "true" : "false");
	if (pActive)
	{
		emit Ready();
	}
}

void ZOptionsPage::StoreData()
{
	qDebug("ZOptionsPage::StoreData()");
#ifdef ZOTO_TAGGING
	mUserInfo->mTagging = GetTags();
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
	mUserInfo->mGalleries = GetGalleries();
#endif // ZOTO_GALLERIES
	mUserInfo->mRemember = GetRemember();
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/* 28-Mar-2006 */
void ZOptionsPage::Checks(bool on)
{
	if (sender() != mYes && sender() != mNo)
	{
		bool vYesChecked = false;
#ifdef ZOTO_TAGGING
		if (mTags->isChecked())
			vYesChecked = true;
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
		if (mGalleries->isChecked())
			vYesChecked = true;
#endif // ZOTO_GALLERIES

		if (!vYesChecked)
			mNo->setChecked(true);
	}
	else if (sender() == mYes && on)
	{
#ifdef ZOTO_TAGGING
		mTags->setEnabled(true);
		mTags->setChecked(true);
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
		mGalleries->setEnabled(true);
		mGalleries->setChecked(true);
#endif // ZOTO_GALLERIES
	}
	else if (sender() == mNo && on)
	{
#ifdef ZOTO_TAGGING
		mTags->setEnabled(false);
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
		mGalleries->setEnabled(false);
#endif // ZOTO_GALLERIES
	}
	emit Ready();
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

class OptionsPageMaker : public PageMaker
{
public:
	OptionsPageMaker() : PageMaker("ZOptionsPage") {}
private:
	ZWizardPage* MakePage(QWidget *pParent, const char *pName, ZUINT pFlags)
	{
		return new ZOptionsPage(pParent, pName, pFlags);
	}
	static const OptionsPageMaker mRegister;
};
const OptionsPageMaker OptionsPageMaker::mRegister;

} // End Namespace

/* vi: set ts=4: */
