/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "OptionsDlg.h"

/* System Headers */
#include <qlayout.h>
#include <qframe.h>
#include <qpushbutton.h>
#include <qhbox.h>

/* Local Headers */
#include "GuiApp.h"
#include "Types.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZOptionsDlg::ZOptionsDlg(ZUserInfo *pInfo, QWidget *pParent /*=0*/, const char *pName /*=0*/,
				WFlags pFlags /*=0*/)
	: QDialog(pParent, pName, pFlags)
{
	QVBoxLayout *vOuterLayout = new QVBoxLayout(this, 10, 10);
	vOuterLayout->addStrut(400);

	mOptions = new ZOptionsPage(this);
	mOptions->Init(pInfo);

	vOuterLayout->addWidget(mOptions, Qt::AlignCenter);

	setCaption(ZULU_GUI_APP()->GetAppName() + " - " + mOptions->GetMainText());

	QFrame *vSep = new QFrame(this);
	vSep->setFrameStyle(QFrame::HLine | QFrame::Sunken);

	vOuterLayout->addWidget(vSep);

	QHBox *vButtonBox = new QHBox(this);
	vButtonBox->setSpacing(10);
	static_cast<QHBoxLayout *>(vButtonBox->layout())->addStretch(100);
	mOk = new QPushButton(tr("&Ok"), vButtonBox);
	mCancel = new QPushButton(tr("Cancel"), vButtonBox);

	vOuterLayout->addWidget(vButtonBox);

	/* Signals and Slots */
	connect(mOk, SIGNAL(clicked()), this, SLOT(accept()));
	connect(mCancel, SIGNAL(clicked()), this, SLOT(reject()));
}

ZOptionsDlg::~ZOptionsDlg()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
