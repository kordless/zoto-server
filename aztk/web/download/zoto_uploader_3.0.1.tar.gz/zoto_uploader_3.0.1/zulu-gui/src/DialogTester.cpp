/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "DialogTester.h"

/* System Headers */
#include <qlayout.h>
#include <qvbox.h>
#include <qpushbutton.h>

/* Local Headers */
#include "WizardPage.h"
#include "GuiApp.h"
#include "HeaderBar.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZDialogTester::ZDialogTester(const QString &pPageType, QWidget *pParent /*=0*/,
								const char *pName /*=0*/, bool pModal /*=false*/,
								WFlags pFlags /*=0*/)
	: QDialog(pParent, pName, pModal, pFlags)
{
	QVBoxLayout *vOuterLayout = new QVBoxLayout(this, 15, 15);

	QFont vBold(font());
	vBold.setBold(true);

	QLabel *vHeader = new QLabel(this, "Header Label");
	vHeader->setFont(vBold);
	vOuterLayout->addWidget(vHeader);

	QVBox *vMainBox = new QVBox(this, "MainBox");
	vMainBox->setMargin(10);	
	vMainBox->setSpacing(10);

	mPage = PageMaker::CreatePage(pPageType, vMainBox, "Options", 0);
	setCaption(ZULU_GUI_APP()->GetAppName() + " - " + mPage->GetMainText());
	vHeader->setText(mPage->GetDescText());

	QFrame *vSep = new QFrame(vMainBox);
	vSep->setFrameStyle(QFrame::HLine | QFrame::Sunken);

	QHBox *vButtonBox = new QHBox(vMainBox);
	vButtonBox->setSpacing(10);
	static_cast<QHBoxLayout *>(vButtonBox->layout())->addStretch(100);
	mOk = new QPushButton(tr("&Ok"), vButtonBox);
	mCancel = new QPushButton(tr("Cancel"), vButtonBox);

	vOuterLayout->addWidget(vMainBox);

	/* Signals and Slots */
	connect(mOk, SIGNAL(clicked()), this, SLOT(accept()));
	connect(mCancel, SIGNAL(clicked()), this, SLOT(reject()));
}

ZDialogTester::~ZDialogTester()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/
void ZDialogTester::Init(ZUserInfo *pInfo)
{
	mPage->Init(pInfo);
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
