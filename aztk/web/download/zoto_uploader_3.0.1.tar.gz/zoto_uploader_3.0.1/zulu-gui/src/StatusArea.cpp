/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "StatusArea.h"

/* System Headers */
#include <qlayout.h>

/* Local Headers */
#include "URLLabel.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZStatusArea::ZStatusArea(QWidget *pParent /*=0*/, const char *pName /*=0*/, WFlags pFlags /*=0*/)
	: QWidget(pParent, pName, pFlags), mUsage(0L), mQuota(0L), mPhotos(0L), mType("")
{
	QHBoxLayout *vLayout = new QHBoxLayout(this);
	mStatus = new QLabel("", this, "Status");
	vLayout->addWidget(mStatus);
	vLayout->addStretch(100);
}

ZStatusArea::~ZStatusArea()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								Clear()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Clears the status area and all internal variables.
 *
 *	@author		Josh Williams
 *	@date		04-Jan-2005
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZStatusArea::Clear()
{
	mUsage = 0L;
	mQuota = 0L;
	mPhotos = 0L;
	mType = "";

	mStatus->setText("");
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							 RedrawStatus()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Regenerates the text to be displayed in the status
 *				area based on internal variables.
 *
 *	@author		Josh Williams
 *	@date		20-Dec-2004
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZStatusArea::RedrawStatus()
{
	QString vText;
	double vPercentUsed = 0.0f;

	if (mUsage > 0L && mQuota > 0L)
		vPercentUsed = (double)mUsage / (double)mQuota;

	vText.sprintf(tr("%2.2f%% of %d GB Space Used | %d Photos | Status: %s"),
			vPercentUsed, mQuota / (1024 * 1000), mPhotos, mType.latin1());
	mStatus->setText(vText);
}

} // End Namespace

/* vi: set ts=4: */
