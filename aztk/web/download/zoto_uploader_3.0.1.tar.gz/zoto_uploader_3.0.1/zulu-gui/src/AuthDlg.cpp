/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "AuthDlg.h"

/* System Headers */
#include <qmessagebox.h>

/* Local Headers */
#include "GuiApp.h"
#include "Types.h"
#include "Events.h"
#include "Utils.h"
#include "Globals.h"
#include "ZSPThread.h"
#include "ZAPIThread.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZAuthDlg::ZAuthDlg(QWidget *pCreator /*=0*/, const char *pName /*=0*/,
			bool pModal /*=false*/,	WFlags pFlags /*=0*/)
	: QProgressDialog(pCreator, pName, pModal, pFlags)
{
	ZRESULT vRetval;
	setCaption(ZULU_GUI_APP()->GetAppName() + tr(" - Connecting"));
	qDebug("Creating client object: %s:%d", ZULU_GUI_APP()->GetZspHost().latin1(), ZULU_GUI_APP()->GetZspPort());
	mClient = new ZClient(ZULU_GUI_APP()->GetZspHost(), ZULU_GUI_APP()->GetZspPort());
	qDebug("Initializing client object");
	if ((vRetval = mClient->Initialize()) != ZERR_SUCCESS)
		throw ZClientError(vRetval);

	mZSPThread = new ZZSPThread(this, mClient);
	mZAPIThread = new ZZAPIThread(this);
	connect(this, SIGNAL(canceled()), this, SLOT(StopThread()));
}

ZAuthDlg::~ZAuthDlg()
{
	if (mZSPThread)
	{
		qDebug("Waiting on thread");
		mZSPThread->wait();
		delete mZSPThread;
	}

	if (mZAPIThread)
		delete mZAPIThread;

	if (mClient)
		delete mClient;
}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							   AuthUser()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Authenticates the specified user, as well as retrieves
 *				their user/gallery information.
 *
 *	@author		Josh Williams
 *	@date		21-Mar-2006
 *
 *	@param		pUserInfo
 *					User info object used for authenticating.
 *	@param		pVersion
 *					Whether or not we should check the uploader version.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZAuthDlg::AuthUser(ZUserInfo *pUserInfo, bool pVersion)
{
	ZUSHORT vSteps = 2;
#ifdef ZOTO_TAGGING
	vSteps += 1;
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	vSteps += 3;
	ZUSHORT vSteps = 3;
#endif // ZOTO_TAGGING

	mUserInfo = pUserInfo;

	if (pVersion)
		vSteps++;

	setTotalSteps(vSteps);
	setProgress(0);

	if (pVersion)
	{
		setLabelText("Checking version...");
		mZSPThread->ProcessVersion();
		mZSPThread->start();
	}
	else
	{
		mZSPThread->ProcessUser(mUserInfo->mUserName, mUserInfo->mPswdHash);
		setLabelText("Authenticating...");
		mZSPThread->start();
	}
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							  customEvent()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Processes updates from the various threads communicating
 *				with Zoto's server.
 *
 *	@author		Josh Williams
 *	@date		21-Mar-2006
 *
 *	@param		pEvt
 *					Custom event being processed
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZAuthDlg::customEvent(QCustomEvent *pEvt)
{
	int	vZResult = -1;

	ZULU_GUI_APP()->processEvents();

	if (this->wasCanceled())
	{
		qDebug("User cancelled us.  Doh!");
		return;
	}

	if (pEvt->type() == ZSTATUS)
	{
		ZStatusEvent *vEvt = dynamic_cast<ZStatusEvent *>(pEvt);
		switch (vEvt->mType)
		{
		case ZStatusEvent::VERSION:
			qDebug("Got response from the Version thread: %d", vEvt->mErrcode);
			if (vEvt->mErrcode == ZERR_COMM || vEvt->mErrcode == ZERR_CONNECT)
			{
				ZGuiApp::ShowCommError("Auth");
				mResult = vEvt->mErrcode;
				cancel();
				break;
			}
			else if (vEvt->mErrcode != ZERR_SUCCESS)
			{
				QString *vRespText = reinterpret_cast<QString *>(pEvt->data());
				vZResult = ShowUpgradeOptions(vEvt->mErrcode, *vRespText);
				delete vRespText;
				if (vZResult == ZERR_INVALID_VERSION)
				{
					mResult = ZERR_INVALID_VERSION;
					cancel();
					break;
				}
			}

			qDebug("Version check successful.  Checking auth");
			setLabelText("Authenticating...");
			setProgress(progress()+ 1);
			mResult = ZERR_SUCCESS;
			mZSPThread->ProcessUser(mUserInfo->mUserName, mUserInfo->mPswdHash);
			mZSPThread->start();
			break;
		case ZStatusEvent::AUTH:
			if (vEvt->mErrcode == ZERR_SUCCESS)
			{
				setLabelText("Getting user info...");
				setProgress(progress()+ 1);
				mZAPIThread->ProcessUser(mUserInfo);
				return;
			}
			else if (vEvt->mErrcode == ZERR_BAD_AUTH)
			{
				QMessageBox::critical(ZULU_GUI_APP()->mainWidget(),
					ZULU_GUI_APP()->GetAppName(), tr("The username and/or password you entered"
						"is invalid.\nPlease enter the correct information and try again."));
			}
			else
			{
				QMessageBox::critical(ZULU_GUI_APP()->mainWidget(),
						ZULU_GUI_APP()->GetAppName(), tr("Error validating your username/password.\n"
						"Please check your internet connection and try again."));
			}
			reject();
			break;
		case ZStatusEvent::USER:
			qDebug("Got a response from ZAPI for USER");
			if (vEvt->mErrcode != ZERR_SUCCESS)
			{
				/* pEvt->data() should hold a fault */
				qDebug("Unable to get user info");
				mResult = ZERR_COMM;
				cancel();
				break;
			}
			setProgress(progress() + 1);
#ifdef ZOTO_TAGGING
			setLabelText("Getting tag list...");
#else
#	ifdef ZOTO_GALLERIES
			setLabelText("Getting gallery info...");
#	else
			accept();
			mResult = ZERR_SUCCESS;
#   endif // ZOTO_GALLERIES
#endif // ZOTO_TAGGING
			break;
#ifdef ZOTO_TAGGING
		case ZStatusEvent::TAGS:
			qDebug("Got a response from ZAPI for TAGS");
			if (vEvt->mErrcode != ZERR_SUCCESS)
			{
				/* pEvt->data() should hold a fault */
				qDebug("Unable to get tag info");
				mResult = ZERR_COMM;
				cancel();
				break;
			}
			setProgress(progress() + 1);
#ifdef ZOTO_GALLERIES
			setLabelText("Getting gallery info...");
#else
			mResult = ZERR_SUCCESS;
			accept();
#endif // ZOTO_GALLERIES
			break;
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
		case ZStatusEvent::GALLERY:
			qDebug("Got a response from ZAPI for GALLERIES");
			if (vEvt->mErrcode != ZERR_SUCCESS)
			{
				/* pEvt->data() should hold a fault */
				qDebug("Unable to get gallery info");
				mResult = ZERR_COMM;
				cancel();
				break;
			}
			setLabelText("Getting template info...");
			setProgress(progress() + 1);
			break;
		case ZStatusEvent::TEMPLATES:
			qDebug("Got a response from ZAPI for TEMPLATES");
			if (vEvt->mErrcode != ZERR_SUCCESS)
			{
				/* pEvt->data() should hold a fault */
				qDebug("Unable to get template info");
				mResult = ZERR_COMM;
				cancel();
				break;
			}
			setLabelText(tr("Getting wrappers..."));
			setProgress(progress() + 1);
			break;
		case ZStatusEvent::WRAPPERS:
			qDebug("Got a reaponse from ZAPI for WRAPPERS");
			if (vEvt->mErrcode != ZERR_SUCCESS)
			{
				/* pEvt->data() should hold a fault */
				qDebug("Unable to get template info");
				mResult = ZERR_COMM;
				cancel();
				break;
			}
			setProgress(progress() + 1);
			mResult = ZERR_SUCCESS;
			accept();
			break;
#endif // ZOTO_GALLERIES
		default:
			break;
		}
	}
}

/*------------------------------------------------------------------*
 *							  StopThread()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Stops the ZAPI/ZSP threads and cancels the dialog.
 *
 *	@author		Josh Williams
 *	@date		21-Mar-2006
 *
 *	@param		pEvt
 *					Custom event being processed
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZAuthDlg::StopThread()
{
	qDebug("StopThread() called");
	mZAPIThread->Cancel();
	mZSPThread->Cancel();
	cancel();
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							ShowUpgradeOptions()					*
 *------------------------------------------------------------------*/
/**
 *	@brief		Called when a new Zoto version is avaliable.
 *
 *	@author		Josh Williams
 *	@date		21-Mar-2006
 *
 *	@param		pRetval
 *					Result of version check.
 *	@param		pLatestVersion
 *					Version returned by the server.
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZAuthDlg::ShowUpgradeOptions(ZRESULT pRetval, const QString &pLatestVersion)
{
	QString vMessage;
	WAIT_CURSOR_OFF();
	if (pRetval == ZERR_FUBAR_VERSION || pRetval == ZERR_INVALID_VERSION)
	{
		/*
		 * Server isn't sure how to respond to this version.  Have to upgrade or bail.
		 */
		vMessage.sprintf(tr("You must upgrade to version %s to continue.", pLatestVersion.latin1()));

		if (QMessageBox::question(ZULU_GUI_APP()->mainWidget(),
					ZULU_GUI_APP()->GetAppName() + tr(" Update"), vMessage,
					QMessageBox::Yes, QMessageBox::No) == QMessageBox::Yes)
		{
			DoUpgrade();
		}
		else
		{
			QMessageBox::critical(ZULU_GUI_APP()->mainWidget(),
					ZULU_GUI_APP()->GetAppName(),
					tr("The Zoto Uploader cannot continue.  It will now close."));
		}
		return ZERR_INVALID_VERSION;
	}
	else if (pRetval == ZERR_NEW_VERSION)
	{
		/*
		 * Newer version is available, but upgrade is not mandatory
		 */
		vMessage.sprintf(tr("A newer version is available.\n\nUpgrade to %s?"), pLatestVersion.latin1());
		if (QMessageBox::question(ZULU_GUI_APP()->mainWidget(),
					ZULU_GUI_APP()->GetAppName() + tr(" Update"),
					vMessage, QMessageBox::Yes, QMessageBox::No) == QMessageBox::Yes)
		{
			if (!DoUpgrade())
				QMessageBox::critical(ZULU_GUI_APP()->mainWidget(),
						ZULU_GUI_APP()->GetAppName() + tr(" Update"),
							tr("Unable to download new client version. Please visit ") +
							ZULU_GUI_APP()->MakeURL(ZOTO_MAIN_URL) + tr(" to download."));
			else
				return ZERR_INVALID_VERSION; // so the application exits, making way for the new version
		}
	}

	return ZERR_SUCCESS; // Catchall
}

/*------------------------------------------------------------------*
 *								DoUpgrade()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Performs an "upgrade" if available (windows), or
 *				points the user's browser to the download page.
 *
 *	@author		Josh Williams
 *	@date		22-Mar-2006
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZAuthDlg::DoUpgrade()
{
	QString vUpdateFile;

	ZULU_GUI_APP()->mainWidget()->hide();
//#if ZULU_PLATFORM == PLATFORM_WINDOWS
#if 1 == 2
	ZUpdater vUpdater(ZULU_GUI_APP()->mainWidget());
	vUpdater.show();
	if (vUpdater.Download(ZULU_GUI_APP()->GetZspHost(), vUpdateFile))
	{
		_spawnl( _P_DETACH, vUpdateFile, vUpdateFile, "/SILENT", NULL);
		return true;
	}
	else
	{
		QMessageBox::critical(ZULU_GUI_APP()->mainWidget(),
				ZULU_GUI_APP()->GetAppName() + tr(" Update"),
						tr("Unable to download new client version. Please visit ") +
						ZULU_GUI_APP()->MakeURL(ZOTO_MAIN_URL) + tr(" to download."));
		return false;
	}
//#elif ZULU_PLATFORM == PLATFORM_MAC || ZULU_PLATFORM == PLATFORM_LINUX
#else
	ZUtils::OpenURL(ZULU_GUI_APP()->mainWidget(), ZULU_GUI_APP()->MakeURL(ZOTO_DOWNLOAD_URL));
	return true;
//#else
//#error Unsupported platform
#endif
}


} // End Namespace

/* vi: set ts=4: */
