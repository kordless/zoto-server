/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/

/* System Headers */
#include <qapplication.h>

/* Local Headers */
#include "GuiApp.h"
#include "MainWin.h"
#include "LoginDlg.h"

/* Macros */

int main(int argc, char *argv[])
{
	ZOTO::ZGuiApp	vApp(argc, argv);

	/*
	 * Check for a currently running instance
	 */
	if (vApp.PreviousInstance(argc, argv))
		return 0;


	ZOTO::ZMainWin	vMainWin(NULL, "MainWin");

	vApp.setMainWidget(&vMainWin);
	vMainWin.show();
	vApp.StartThread();

	/*
	 * Create an invisible window.  This allows new copies of the uploader
	 * to determine if an existing copy is already running.
	 */
	QWidget invis_window(NULL, INVIS_NAME);
	invis_window.setCaption(INVIS_NAME);

	vApp.processEvents();
	if (!vApp.Initialize())
		return 1;
	else
	{
		/*
		 * Load any files passed in on the command line.
		 */
		if (argc > 1)
		{
			for (int i = 1; i < argc; i++)
			{
				qDebug("%s::Adding autoload from command line: %s", __FILE__, argv[i]);
				vApp.AddFile(argv[i]);
			}
		}
		return vApp.exec();
	}
}

/* vi: set ts=4: */

