/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "WizardDlg.h"

/* System Headers */
#include <qwidgetstack.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvbox.h>
#include <qhbox.h>

/* Local Headers */
#include "Types.h"
#include "HeaderBar.h"
#include "WizardPage.h"
#include "GuiApp.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZWizardDlg::ZWizardDlg(QWidget *pParent /*=0*/, const char *pName /*=0*/,
							bool pModal /*=false*/, WFlags pFlags /*=0*/)
	: QDialog(pParent, pName, pModal, pFlags), mPageCount(0), mCurPage(NULL)
{
	setCaption(ZULU_GUI_APP()->GetAppName());
	QVBoxLayout *vOuterLayout = new QVBoxLayout(this, 15, 15);

/*
	mHeader = new ZHeaderBar(this, "Wizard Header");
	vOuterLayout->addWidget(mHeader);
*/
	QFont	vBold(font());
	vBold.setBold(true);

	mHeader = new QLabel(this, "Header Label");
	mHeader->setFont(vBold);
	vOuterLayout->addWidget(mHeader);

	QVBox *vMainBox = new QVBox(this, "MainBox");
	//vMainBox->setMargin(10);
	vMainBox->setSpacing(20);

	mStack = new QWidgetStack(vMainBox, "Widget Stack");

	vMainBox->setStretchFactor(mStack, 100);

	QFrame *vSep = new QFrame(vMainBox);
	vSep->setFrameStyle(QFrame::HLine | QFrame::Sunken);

	QHBox *vButtonBox = new QHBox(vMainBox);
	vButtonBox->setSpacing(10);
	static_cast<QHBoxLayout *>(vButtonBox->layout())->addStretch(100);
	mBack = new QPushButton(tr("&Back"), vButtonBox);
	mNext = new QPushButton(tr("&Next"), vButtonBox);
	mCancel = new QPushButton(tr("Cancel"), vButtonBox);

	vOuterLayout->addWidget(vMainBox, 100);

	mPages.setAutoDelete(true);

	/* Signals and Slots */
	connect(mNext, SIGNAL(clicked()), this, SLOT(OnNext()));
	connect(mBack, SIGNAL(clicked()), this, SLOT(OnBack()));
	connect(mCancel, SIGNAL(clicked()), this, SLOT(reject()));
}

ZWizardDlg::~ZWizardDlg()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 29-Mar-2006 */
void ZWizardDlg::show()
{
	if (mCurPage == NULL)
	{
		Page *vPage;
		for (vPage = mPages.first(); vPage; vPage = mPages.next())
		{
			if (vPage->mAppropriate)
			{
				ShowPage(vPage->mWidget);
				QDialog::show();
				return;
			}
		}
		/*
		 * No acceptable pages.
		 */
		return;
	}
	else
	{
		ShowPage(mCurPage->mWidget);
		QDialog::show();
	}
}

/* 29-Mar-2006 */
int ZWizardDlg::Execute()
{
	Page *vPage;

	for (vPage = mPages.first(); vPage; vPage = mPages.next())
	{
		if (vPage->mAppropriate)
			return QDialog::exec();
	}
	return QDialog::Accepted;
}

/* 28-Mar-2006 */
int ZWizardDlg::AddPage(ZWizardPage *pPage)
{
	int vId = mStack->addWidget(pPage, mPageCount++);
	connect(pPage, SIGNAL(Ready()), this, SLOT(OnReady()));
	connect(pPage, SIGNAL(NotReady()), this, SLOT(OnNotReady()));
	Page *vPage = new Page(pPage, vId, true);
	mPages.append(vPage);
	return vId;
}

/* 28-Mar-2006 */
void ZWizardDlg::ShowPage(ZWizardPage *pPage)
{
	ZWizardPage *vCur;
	Page		*vPage;
	bool		vFound = false;

	vCur = dynamic_cast<ZWizardPage *>(mStack->visibleWidget());
	if (vCur)
		vCur->SetActive(false);

	mCurPage = FindPage(pPage);

	if (!mCurPage)
	{
		qDebug("Unable to find current page");
		return;
	}

	/*
	 * See if we have any previous pages.
	 */
	vFound = false;
	mPages.find(mCurPage);
	vPage = mPages.prev();
	while (vPage)
	{
		if (vPage->mAppropriate)
		{
			vFound = true;
			break;
		}
		else
			vPage = mPages.prev();
	}

	if (vFound)
		mBack->setEnabled(true);
	else
		mBack->setEnabled(false);

	/*
	 * See if we have any next pages.
	 */
	vFound = false;
	mPages.find(mCurPage);
	vPage = mPages.next();
	while (vPage)
	{
		if (vPage->mAppropriate)
		{
			vFound = true;
			break;
		}
		else
			vPage = mPages.next();
	}

	if (vFound)
		mNext->setText(tr("Next"));
	else
		mNext->setText(tr("Finish"));

	mNext->setEnabled(false);

	//mHeader->SetMainText(pPage->GetMainText());
	//mHeader->SetDescText(pPage->GetDescText());
	setCaption(ZULU_GUI_APP()->GetAppName() + " - " + pPage->GetMainText());
	mHeader->setText(pPage->GetDescText());
	mStack->raiseWidget(pPage);

	mCurPage->mWidget->SetActive(true);
	pPage->SetActive(true);
}

/* 29-Mar-2006 */
void ZWizardDlg::SetAppropriate(ZWizardPage *pPage, bool pAppropriate)
{
	Page *vPage;

	for (vPage = mPages.first(); vPage; vPage = mPages.next())
	{
		if (vPage->mWidget == pPage)
		{
			vPage->mAppropriate = pAppropriate;
			return;
		}
	}
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/* 29-Mar-2006 */
void ZWizardDlg::OnNext()
{
	mPages.find(mCurPage);
	Page *vPage = mPages.next();

	while (vPage)
	{
		if (vPage->mAppropriate)
		{
			qDebug("ZWizardDlg::OnNext() found acceptable page");
			ShowPage(vPage->mWidget);
			return;
		}
		else
			vPage = mPages.next();
	}

	/*
	 * If we're here, we're out of pages.  Go ahead and accept.
	 */
	qDebug("ZWizardDlg::OnNext() no acceptable next page");
	for (vPage = mPages.first(); vPage; vPage = mPages.next())
	{
		vPage->mWidget->StoreData();
	}
	
	accept();
}

/* 29-Mar-2006 */
void ZWizardDlg::OnBack()
{
	mPages.find(mCurPage);
	Page *vPage = mPages.prev();

	while (vPage)
	{
		if (vPage->mAppropriate)
		{
			ShowPage(vPage->mWidget);
			return;
		}
		else
			vPage = mPages.prev();
	}

	/*
	 * If we're here, no previous pages are available.  Re-display the current one.
	 */
	ShowPage(mCurPage->mWidget);
}

/* 28-Mar-2006 */
void ZWizardDlg::OnReady()
{
	mNext->setEnabled(true);
	mNext->setDefault(true);
}

/* 28-Mar-2006 */
void ZWizardDlg::OnNotReady()
{
	mNext->setEnabled(false);
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/* 29-Mar-2006 */
ZWizardDlg::Page* ZWizardDlg::FindPage(ZWizardPage *pPage)
{
	Page *vPage;

	for (vPage = mPages.first(); vPage; vPage = mPages.next())
	{
		if (vPage->mWidget == pPage)
			return vPage;
	}

	return NULL;
}

} // End Namespace

/* vi: set ts=4: */
