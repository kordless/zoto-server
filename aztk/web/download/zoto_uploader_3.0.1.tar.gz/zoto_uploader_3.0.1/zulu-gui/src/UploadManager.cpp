/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "UploadManager.h"

/* System Headers */
#include <qlayout.h>
#include <qmessagebox.h>

/* Local Headers */
#include "GuiApp.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */
ZUploadBatch* ZUploadManager::smCurrentBatch = NULL;

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZUploadManager::ZUploadManager(QWidget *pParent /*=0*/, const char *pName /*=0*/,
		WFlags pFlags /*=0*/)
	: QFrame(pParent, pName, pFlags)
{
	QVBoxLayout *vOuterLayout = new QVBoxLayout(this);
	vOuterLayout->setMargin(5);
	setPaletteBackgroundColor(Qt::white);

	mWidgetFrame = new QFrame(this);
	vOuterLayout->addWidget(mWidgetFrame);
	mWidgetLayout = new QVBoxLayout(mWidgetFrame);
	mWidgetLayout->setSpacing(5);

	vOuterLayout->addStretch(100);
}

ZUploadManager::~ZUploadManager()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							   AddBatch()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Adds the specified batch to the queue, and starts
 *				it if there are none currently active.
 *
 *	@author		Josh Williams
 *	@date		12-Jan-2006
 *
 *	@param		pFiles
 *					List of files to be uploaded.
 *	@param 		pTotalBytes
 *					Total size of the upload batch.
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZUploadManager::AddBatch(const ZFileList &pFiles, ZULONG pTotalBytes,
						QStringList &pTagList, QStringList &pGalleries)
{
	Q_UNUSED(pGalleries);
	parentWidget()->parentWidget()->show();
	//qDebug("MAIN_SEPARATOR: %p", ZULU_GUI_APP());
	dynamic_cast<QWidget *>(ZULU_GUI_APP()->mainWidget()->child("MAIN_SEPARATOR"))->show();
	ZUploadBatch *vBatch = new ZUploadBatch(pFiles, pTotalBytes, mWidgetFrame);
	connect(vBatch, SIGNAL(StatusChanged(ZULONG, ZBatchStatus)),
				this, SLOT(BatchUpdate(ZULONG, ZBatchStatus)));
#ifdef ZOTO_TAGGING
	vBatch->SetTags(pTagList);
#else
	Q_UNUSED(pTagList)
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
	vBatch->SetGalleries(pGalleries);
#else
	Q_UNUSED(pGalleries);
#endif // ZOTO_GALLERIES

	mWidgetLayout->addWidget(vBatch);
	vBatch->show();
	qApp->processEvents();

	if (smCurrentBatch != NULL)
		mPendingBatches[vBatch->GetId()] = vBatch;
	else
	{
		ZUserInfo *vInfo;
		if (ZULU_GUI_APP()->GetCurrentUser(&vInfo))
		{
			QStringList::const_iterator vIt;
			QStringList::const_iterator vIt2;
			for (vIt = pTagList.begin(); vIt != pTagList.end(); vIt++)
			{
				vIt2 = vInfo->mTags.find(*vIt);
				if (vIt2 == vInfo->mTags.end())
					vInfo->mTags.append(*vIt);
			}
			vInfo->mTags.sort();
			qDebug("Updating current batch");
			smCurrentBatch = vBatch;
			vBatch->SetActive();
		}
	}
}

/*------------------------------------------------------------------*
 *							 BatchUpdate()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Called by a batch to report completed, cancelled,
				or failed status.
 *
 *	@author		Josh Williams
 *	@date		12-Jan-2006
 *
 *	@param		pID
 *					Internal ID of the batch sending us an update.
 *	@param 		pStatus
 *					Type of update being sent.
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZUploadManager::BatchUpdate(ZULONG pID, ZBatchStatus pStatus)
{
	qDebug("%s::BatchUpdate(%ld, %d)", __FILE__, pID, pStatus);
	ZFileList::iterator vIt;
	ZUploadBatch		*vBatch;
	ZFileList vList;

	switch (pStatus)
	{
	case BATCH_COMPLETE:
		mCompletedBatches[pID] = smCurrentBatch;
		smCurrentBatch = NULL;
		break;
	case BATCH_CLOSED:
		mCompletedBatches[pID]->hide();
		vBatch = mCompletedBatches[pID];
		mCompletedBatches.erase(pID);
		delete vBatch;
		break;
	case BATCH_FAILED:
		qDebug("%s::Batch %ld failed", __FILE__, pID);
		smCurrentBatch->hide();

		vList = smCurrentBatch->GetFiles();
		for (vIt = vList.begin(); vIt != vList.end(); vIt++)
		{
			ZULU_GUI_APP()->AddFile(vIt.data().mName);
		}
		delete smCurrentBatch;
		smCurrentBatch = NULL;
		QMessageBox::warning(this, ZULU_GUI_APP()->GetAppName(), tr("Unable to upload."));
		break;
	case BATCH_CANCELLED:
		if (pID == smCurrentBatch->GetId())
		{
			qDebug("Batch %ld cancelled while active", pID);
			smCurrentBatch->hide();
			ZFileList vList = smCurrentBatch->GetFiles();
			for (vIt = vList.begin(); vIt != vList.end(); vIt++)
			{
				ZULU_GUI_APP()->AddFile(vIt.data().mName);
			}
			delete smCurrentBatch;
			smCurrentBatch = NULL;
		}
		else
		{
			mPendingBatches[pID]->hide();
			mPendingBatches.erase(pID);
			return;
		}
		break;
	default:
		return;
	}

	if (smCurrentBatch == NULL)
	{
		if (mPendingBatches.size() > 0)
		{
			qDebug("%s::Starting next batch", __FILE__);
			vBatch = mPendingBatches.begin()->second;
			mPendingBatches.erase(mPendingBatches.begin());
			StartBatch(vBatch);
		}
		else if (mCompletedBatches.size() == 0)
		{
			parentWidget()->parentWidget()->hide();
			dynamic_cast<QWidget *>(ZULU_GUI_APP()->mainWidget()->child("MAIN_SEPARATOR"))->hide();
		}
	}
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/* 17-Jan-2006 */
void ZUploadManager::StartBatch(ZUploadBatch *pBatch)
{
	smCurrentBatch = pBatch;

	pBatch->SetActive();
}
	

} // End Namespace

/* vi: set ts=4: */
