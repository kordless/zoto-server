/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "UploadWizard.h"

/* System Headers */

/* Local Headers */
#include "OptionsPage.h"
#include "Types.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZUploadWizard::ZUploadWizard(QWidget *pParent /*=0*/, const char *pName /*=0*/,
								bool pModal /*=false*/, WFlags pFlags /*=9*/)
	: ZWizardDlg(pParent, pName, pModal, pFlags)
{
	//setMaximumSize(QSize(490, 470));
}

ZUploadWizard::~ZUploadWizard()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 29-Mar-2006 */
void ZUploadWizard::Init(ZUserInfo *pInfo)
{
	mOptions = new ZOptionsPage(this);
	mOptions->Init(pInfo);
	AddPage(mOptions);
	if (pInfo->mRemember)
		SetAppropriate(mOptions, false);

#ifdef ZOTO_TAGGING
	mTags = new ZTagPage(this);
	mTags->Init(pInfo);
	AddPage(mTags);
	if (!pInfo->mTagging)
		SetAppropriate(mTags, false);
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
	mGalleries = new ZGalleryPage(this);
	mGalleries->Init(pInfo);
	AddPage(mGalleries);
	if (!pInfo->mTagging)
		SetAppropriate(mGalleries, false);
#endif // ZOTO_GALLERIES
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/* 29-Mar-2006 */
void ZUploadWizard::OnNext()
{
	ZWizardDlg::OnNext();
}

/* 29-Mar-2006 */
void ZUploadWizard::OnReady()
{
	qDebug("ZUploadWizard::OnReady");
	if (GetCurrentPage() == mOptions)
	{
		qDebug("Options page!");
		int vAppropriate = 0;
#ifdef ZOTO_TAGGING
		if (mOptions->GetTags())
		{
			vAppropriate++;
			SetAppropriate(mTags, true);
		}
		else
			SetAppropriate(mTags, false);
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
		if (mOptions->GetGalleries())
		{
			vAppropriate++;
			SetAppropriate(mGalleries, true);
		}
		else
			SetAppropriate(mGalleries, false);

#endif // ZOTO_GALLERIES
		if (vAppropriate)
			SetNextText(tr("Next"));
		else
			SetNextText(tr("Finish"));
	}

#ifdef ZOTO_GALLERIES
	else if (GetCurrentPage() == mGalleries)
	{
		qDebug("Galleries page!");
		if (mGalleries->WantsNew())
		{
			SetAppropriate(mNewGallery, true);
			SetAppropriate(mTemplates, true);
			SetNextText(tr("Next"));
			OnNext();
		}
		else
		{
			SetAppropriate(mNewGallery, false);
			SetAppropriate(mTemplates, false);
			SetNextText(tr("Finish"));
		}
	}
#endif // ZOTO_GALLERIES

	ZWizardDlg::OnReady();
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
