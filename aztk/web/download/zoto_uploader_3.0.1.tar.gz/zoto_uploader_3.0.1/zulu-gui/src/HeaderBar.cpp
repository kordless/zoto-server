/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "HeaderBar.h"

/* System Headers */
#include <qhbox.h>
#include <qframe.h>
#include <qlayout.h>
#include <qpixmap.h>

/* Local Headers */

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZHeaderBar::ZHeaderBar(QWidget *pParent /*=0*/, const char *pName /*=0*/,
				WFlags pFlags /*=0*/)
	: QVBox(pParent, pName, pFlags)
{
	QHBox	*vMainBox;
	QVBox	*vTextBox;
	QLabel	*vGraphic;
	QFrame	*vSep;
	QWidget	*vFiller;

	static_cast<QVBoxLayout *>(this->layout())->addStrut(400);
	vMainBox = new QHBox(this, "MainBox");
	vMainBox->layout()->setMargin(3);
	vMainBox->setPaletteBackgroundColor(Qt::white);

	vTextBox = new QVBox(vMainBox, "TextBox");
	static_cast<QVBoxLayout *>(vTextBox->layout())->addStretch(100);

	mMainLine = new QLabel(vTextBox, "MainLine");
	mMainLine->setFont(QFont("Verdana", 7, QFont::Bold));
	mMainLine->adjustSize();

	mDescLine = new QLabel(vTextBox, "DescLine");
	mDescLine->setFont(QFont("Verdana", 7));
	mDescLine->adjustSize();
	static_cast<QVBoxLayout *>(vTextBox->layout())->addStretch(100);

	vGraphic = new QLabel(vMainBox, "Graphic");
	vGraphic->setPixmap(QPixmap::fromMimeSource("weed.png"));
	vGraphic->setAlignment(Qt::AlignRight);
	vMainBox->setMaximumHeight(40);
	vMainBox->setMinimumHeight(40);

	vSep = new QFrame(this, "Separator");
	vSep->setFrameStyle(QFrame::HLine | QFrame::Raised);

	vFiller = new QWidget(this, "Filler");
	this->setStretchFactor(vFiller, 10);
}

ZHeaderBar::~ZHeaderBar()
{

}
	

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
