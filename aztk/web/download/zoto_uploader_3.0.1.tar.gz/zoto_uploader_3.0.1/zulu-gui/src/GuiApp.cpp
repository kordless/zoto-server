/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "GuiApp.h"

/* System Headers */
#include <qfileinfo.h>
#include <qmessagebox.h>
#include <qdir.h>
#include <qprogressdialog.h>
#if ZULU_PLATFORM == PLATFORM_WINDOWS
#define _UNICODE
#include <process.h>
#include <tchar.h>
#endif

/* Local Headers */
#include "MainWin.h"
#include "ImageView.h"
#include "ImageViewItem.h"
#include "MD5Hasher.h"
#include "ImageThread.h"
#include "LoginDlg.h"
#include "Utils.h"
#include "UploadManager.h"
#include "AuthDlg.h"
#include "UploadWizard.h"
#if ZULU_PLATFORM == PLATFORM_WINDOWS
#include "Updater.h"
#endif

/* Macros */

namespace ZOTO
{

#if ZULU_PLATFORM == PLATFORM_WINDOWS

HWND gWnd = NULL;

BOOL CALLBACK FindZuluWin(HWND pWnd, LPARAM pParam)
{
	Q_UNUSED(pParam);
	char	vTitle[256];
	int		vLength = 0;

	vLength = GetWindowTextA(pWnd, vTitle, 256);
	if (vLength > 0)
	{
		if (strncmp(vTitle, MAIN_NAME, ZMIN(vLength, (int)strlen(MAIN_NAME))) == 0)
		{
			gWnd = pWnd;
			return FALSE; // Stop search
		}
	}

	return TRUE;
}
#endif
/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZGuiApp::ZGuiApp(int &argc, char **argv)
	: ZApp(argc, argv), mLastBrowse(""), mLastFormat(""), mTotalBytes(0L), mThread(NULL),
		mVersionOk(false), mPhotoCount(0)
{
	QSettings vConfig;
	SetConfigPath(vConfig);

	/*
	 * Grab the config values from the file/registry
	 */
	mLastBrowse = vConfig.readEntry(BuildConfigPath("/LastBrowse"), "");
	mLastFormat = vConfig.readEntry(BuildConfigPath("/LastFormat"), "");
}

ZGuiApp::~ZGuiApp()
{
	qDebug("%s::ZGuiApp destructor", __FILE__);
	if (mThread)
	{
		qDebug("%s::calling mThread->Shutdown()", __FILE__);
		mThread->Shutdown();
		mThread->wait();
	}
	delete mThread;
	Shutdown();
}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							GetWindowCaption()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Returns the title to be used for the main window.
 *
 *	@author		Josh Williams
 *	@date		21-Dec-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
const QString ZGuiApp::GetWindowCaption()
{
	QString		vCaption;
	QString		vVersion;
	ZUserInfo	*vInfo;

	vCaption = GetVersName();

	if (GetCurrentUser(&vInfo))
		vCaption += " - " + vInfo->mUserName;
	return vCaption;
}

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 29-Sep-2006 */
void ZGuiApp::StartThread()
{
	mThread = new ZImageThread(dynamic_cast<ZMainWin *>(mainWidget())->GetImageView());
	mThread->start();
}

/*------------------------------------------------------------------*
 *							  Initialize()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Handles loading application configuration and
 *				initializing the ZSP client code.
 *
 *	@author		Josh Williams
 *	@date		21-Dec-2005
 *
 *	@remarks	Must be called AFTER the main window is created.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZGuiApp::Initialize()
{
	bool vRetval = false;

	//assert(mainWidget() != NULL);

	if (ZApp::Initialize() == false)
	{
		qDebug("%s::Unable to initialize client", __FILE__);
		QString vMessage = tr("Unable to start the ");
		vMessage += GetAppName() + tr(".\nPlease re-install the application and try again.");
		QMessageBox::critical(mainWidget(), GetAppName(), vMessage);
		return vRetval;
	}

	if (Authenticate())
	{
		processEvents();
		vRetval = true;
	}

	return vRetval;
}

/*------------------------------------------------------------------*
 *								Shutdown()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Saves all configuration information and shuts down
 *              the ZSP library if necessary.
 *
 *	@author		Josh Williams
 *	@date		28-Dec-2005
 *
 *	@remarks	Shouldn't need to call this function explicitly.
 *				ZGuiApp destructor calls it automatically.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZGuiApp::Shutdown()
{
	QSettings	vConfig;

	ZApp::Shutdown();

	SetConfigPath(vConfig);

	vConfig.writeEntry(BuildConfigPath("/LastBrowse"), mLastBrowse);
	vConfig.writeEntry(BuildConfigPath("/LastFormat"), mLastFormat);
}

/*------------------------------------------------------------------*
 *							 Authenticate()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Connects to the Zoto server and requests ZSP
 *              authentication.
 *
 *	@author		Josh Williams
 *	@date		22-Mar-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZGuiApp::Authenticate(bool pForcePrompt /*=false*/)
{
	bool		vPrompt = true;
	bool		vAuthd = false;
	QString		vUser, vPswd;
	bool		vAuto = false;
	ZUserInfo	*vInfo;
	ZAuthDlg	*vProgress = NULL;
	ZRESULT		vZResult;
	bool		vReturn;

	/*
	 * Determine whether or not we have a default user.
	 */
	if (GetCurrentUser(&vInfo))
	{
		vUser = vInfo->mUserName;
		vPswd = vInfo->mPswdHash;
		vAuto = vInfo->mAuto;
		if (vInfo->mAuto)
			vPrompt = false;
	}

	if (pForcePrompt)
		vPrompt = true;

	/*
	 * we can't move past this point until either:
	 * A. The user has been authenticated, or
	 * B. The user cancels the login prompt.
	 */
	while (!vAuthd)
	{
		/*
		 * If the user chose to save their login information, the prompt will
		 * not be displayed.  However, if during the course of authenticating
		 * an error is encountered (bad credentials, internal error, etc), the
		 * login prompt will be created and displayed.
		 */
        if (vPrompt)
		{
			ZLoginDlg vLogin(mainWidget(), "LoginDlg", true);

			vReturn = vLogin.exec();
			processEvents(); // So the screen refreshes

			/*
			 * Check the action performed by the user.
			 */
			if (vReturn == QDialog::Accepted)
			{

				vUser = vLogin.GetUser();
				vPswd = vLogin.GetPswd();
				vAuto = vLogin.GetAuto();
			}
			else
			{
				break;
			}
		}


		if (!vProgress)
			vProgress = new ZAuthDlg(mainWidget(), "AuthDlg", true);
		vProgress->show();
		vProgress->setMinimumDuration(1);
		qApp->processEvents();

		ZUserInfo *vUserInfo;
		LoadUser(vUser, &vUserInfo);
		vUserInfo->mPswdHash = vPswd;
		vUserInfo->mAuto	 = vAuto;
		vProgress->AuthUser(vUserInfo, !mVersionOk);
		vReturn = vProgress->exec();
		vProgress->hide();
		vZResult = vProgress->GetResult();
		if (vReturn == QDialog::Accepted)
		{
			qDebug("Dialog accepted");
			/*
			 * All is right with the world.  Version/auth are ok.
			 */
			mVersionOk = true;
			vAuthd = true;
			short vIndex = SaveUser(vUserInfo);
			SetCurrentUser(vIndex);
			static_cast<ZMainWin *>(mainWidget())->SwitchUser();
			break;
		}
		else
		{
			qDebug("Dialog rejected");
			vAuthd = false;
			if (vZResult == ZERR_INVALID_VERSION)
				break;

			vPrompt = true;
			continue;
		}
	}

	return vAuthd;
}

/*------------------------------------------------------------------*
 *								AddFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Adds an image to the image view, as well as to this
 *				class's internal list of uploads.
 *
 *	@author		Josh Williams
 *	@date		21-Dec-2005
 *
 *	@param		pURI
 *					Path to the file to be added.
 *
 * 	@remarks	Checks to be sure the image isn't already in the list,
 * 				as well as the image's format.  If file doesn't exist,
 * 				a request is sent to the image thread to generate
 * 				a thumbnail.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZGuiApp::AddFile(const QString &pURI)
{
	QFileInfo		vFileInfo;
	ZULONG			vKey;
	ZFileInfo		vInfo;
	ZImageView		*vImageView;
	int				vPixW = 0;
	int				vPixH = 0;

	vFileInfo.setFile(pURI);

	if (vFileInfo.isDir())
	{
		qDebug(QString("%1 is a directory").arg(pURI));
		QDir vDir(pURI);
		QStringList vFiles = vDir.entryList();
		qDebug(QString("%1 contains %2 files").arg(pURI).arg(vFiles.count()));
		for (ZUINT i = 0; i < vFiles.count(); i++)
		{
			vFileInfo.setFile(vFiles[i]);
			if (vFileInfo.fileName().startsWith("."))
			{
				qDebug(QString("%1 is a dot file").arg(vFileInfo.fileName()));
				continue;
			}

			qDebug(QString("Adding from directory %1").arg(vFiles[i]));
			AddFile(vDir.absFilePath(vFiles[i]));
		}
		return true;
	}
	else if (vFileInfo.isSymLink())
	{
		return true;
	}
	else if (IsSupportedImage(vFileInfo.absFilePath()))
	{
		/*
		 * This is an image, Create it's key hash.
		 */
		vKey = CreateKey(vFileInfo.absFilePath());

		/*
		 * Make sure this file isn't already in the list.
		 */
		if (mFiles.contains(vKey))
			return true;

		vInfo.mName = vFileInfo.absFilePath();
		vInfo.mSize = vFileInfo.size();
		vInfo.mKey = vKey;
		vInfo.mRotate = 0;
		vInfo.mIndex = mPhotoCount++;
		mFiles[vKey] = vInfo;
		mTotalBytes += vInfo.mSize;
		qDebug(QString("%1::Adding file:").arg(__FILE__));
		qDebug(QString("%1::Name: %2").arg(__FILE__).arg(vInfo.mName));
		qDebug(QString("%1::Size: %2").arg(__FILE__).arg(vInfo.mSize));

		/*
		 * Let the image thread know we need a thumbnail.
		 */
		mThread->LockQueue();
		if (mainWidget())
		{
			vImageView = static_cast<ZMainWin*>(mainWidget())->GetImageView();
			vPixW = vImageView->GetThumbWidth() - (BORDER_WIDTH * 2);
			vPixH = vImageView->GetThumbHeight() - (BORDER_WIDTH * 2);
			mThread->AddRequest(vInfo.mKey, vInfo.mName, vPixW, vPixH, 0);
			vImageView->AddFile(vInfo);
			qDebug(QString("%1::File added:").arg(__FILE__));
		}
		mThread->UnlockQueue();
		mThread->DataAvailable();
		return true;
	}
	else
	{
		qDebug(QString("%1::Not a valid file: %2").arg(__FILE__).arg(vInfo.mName));
		return false;
	}
}

/*------------------------------------------------------------------*
 *							RemoveFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Removes a file from the image view and the internal
 *				upload list.
 *
 *	@author		Josh Williams
 *	@date		13-Aug-2005
 *
 *	@param 		pKey
 *					Interal key identifying the file to be removed.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZGuiApp::RemoveFile(ZULONG pKey)
{
	if (mFiles.contains(pKey))
	{
		mTotalBytes -= mFiles[pKey].mSize;
		mFiles.erase(pKey);
		static_cast<ZMainWin*>(mainWidget())->GetImageView()->RemoveFile(pKey);
	}
}

/*------------------------------------------------------------------*
 *							RotateFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Rotates a file 90'.
 *
 *	@author		Josh Williams
 *	@date		22-Dec-2005
 *
 *	@param 		pKey
 *					Interal key identifying the file to be removed.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZGuiApp::RotateFile(ZULONG pKey)
{
	ZImageView		*vImageView;
	ZImageViewItem	*vItem;

	if (mFiles.contains(pKey))
	{
		ZUSHORT vRotate = ++(mFiles[pKey].mRotate);
		mFiles[pKey].mRotate = vRotate % 4;

		qDebug("Rotated %d times", mFiles[pKey].mRotate);

		/*
		 * Let the image thread know we need a thumbnail.
		 */
		if (mainWidget())
		{
			vImageView = static_cast<ZMainWin*>(mainWidget())->GetImageView();
			vItem = vImageView->FindByKey(pKey);
			if (vItem)
				vItem->RotateThumb();
			else
				qDebug("Unable to find item matching key %ld", pKey);
		}
	}
}

/*------------------------------------------------------------------*
 *							ShowCommError()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Shows the communications error.
 *
 *	@author		Josh Williams
 *	@date		17-Apr-2006
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
int ZGuiApp::ShowCommError(const QString &pCaption /*=""*/)
{
	QString vCaption = ZULU_GUI_APP()->GetAppName();
	if (pCaption.length() > 0)
		vCaption += " - " + pCaption;

	return QMessageBox::critical(ZULU_GUI_APP()->mainWidget(), vCaption,
					tr("Error communicating with the Zoto server.\nPlease check "
						"your internet connection and try again."));
}

#if ZULU_PLATFORM == PLATFORM_WINDOWS
/*------------------------------------------------------------------*
 *							 winEventFilter()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Used to intercept messages from additional instances
 *				when they are started up.
 *
 *	@author		Josh Williams
 *	@date		22-Mar-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZGuiApp::winEventFilter(MSG *msg)
{
	if (msg->message == WM_COPYDATA)
	{
		QStringList	vFiles;
		QString		vFile;
		QString		vData;
		COPYDATASTRUCT *cds = reinterpret_cast<COPYDATASTRUCT *>(msg->lParam);
		vData = QString::fromUcs2(static_cast<ZUSHORT *>(cds->lpData));
		if (vData.isNull())
			qDebug("%s::Message was NULL", __FILE__);
		else
		{
			qDebug("%s::Message", __FILE__);
			qDebug(vData);
		}

		vFiles = QStringList::split(';', vData);
		qDebug("%s::File count: %d", __FILE__, vFiles.count());
		while (vFiles.count() > 0)
		{
			vFile = vFiles.front();
			vFiles.pop_front();
			if (vFile.length() > 0)
			{
				qDebug(QString("%1::Adding autoload from message [%2]").arg(__FILE__).arg(vFile));
				AddFile(vFile);
			}
		}
		
		ZShellDropEvent* evt = new ZShellDropEvent();
		QWidget *mWidget = mainWidget();
		if (mWidget != NULL)
			QApplication::postEvent(mWidget, evt);
		return true;
	}
	else
	{
		return false;
	}
}
#endif

/*------------------------------------------------------------------*
 *							 PreviousInstance()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Checks for an already running copy of the program.
 *
 *	@author		Josh Williams
 *	@date		22-Mar-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZGuiApp::PreviousInstance(int& argc, char **argv)
{
#if ZULU_PLATFORM == PLATFORM_WINDOWS

	HWND				vOther = NULL;
	HWND				vInvisWnd = NULL;
	HANDLE				vMutex;
	ZUSHORT				vCount = 0;

	/*
	 * First, try to open the mutex.  This will tell us if an existing
	 * instance is already running.
	 */
	vMutex = OpenMutex(MUTEX_ALL_ACCESS, 0, _T(MUTEX_NAME));
	if (!vMutex)
	{
		/*
		 * Mutex doesn't exist.  Create it and bail
		 */
		CreateMutex(0, FALSE, _T(MUTEX_NAME));
		return false;
	}
	else
	{
		/*
		 * Mutex exists.  An existing instance is already running.  Try
		 * to find our placeholder window.
		 */
		vInvisWnd = FindWindow(0, _T(INVIS_NAME));
		while (vCount++ < 5 && vInvisWnd == NULL)
			Sleep(50);

		if (vInvisWnd == NULL)
		{
			//QMessageBox::critical(NULL, "Oops", "Unable to find placeholder");
			return true;
		}

		/*
		 * Send the previous instance our stuff
		 */
		if (argc > 1)
		{
			QString strMsg;
			QString strFiles = "";
			for (int i = 1; i < argc; i++)
			{
				strFiles += ";";
				strFiles += argv[i];
			}
			COPYDATASTRUCT cds;
			cds.cbData = strFiles.length()+1;
			char *pcBuffer = new char[strFiles.length()+1];
			memset(pcBuffer, '\0', sizeof(pcBuffer));
			memcpy(pcBuffer, strFiles.utf8().data(), strFiles.utf8().size());
			cds.lpData = pcBuffer;
			SendMessage(vInvisWnd, WM_COPYDATA, 0, (LPARAM)&cds);
		}

		/*
		 * Now that we've notified the existing window of our new data,
		 * try to find one of it's windows and activate it.
		 */
		EnumWindows(FindZuluWin, (LPARAM)&vOther);
		if (gWnd == NULL)
			gWnd = FindWindow(0, _T(LOGIN_NAME));

		if (gWnd != NULL)
			SetForegroundWindow(gWnd);

		return true;
	}
#elif ZULU_PLATFORM == PLATFORM_MAC || ZULU_PLATFORM == PLATFORM_LINUX
	Q_UNUSED(argc);
	Q_UNUSED(argv);
	return false;
#endif
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								Reset()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Resets the application to the state it was in when
 *				first started, usually in response to changing users.
 *
 *	@author		Josh Williams
 *	@date		04-Jan-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZGuiApp::Reset()
{
	//SetCurrentUser(-1);
	//dynamic_cast<ZMainWin *>(mainWidget())->SwitchUser();
	Authenticate(true);
}

/*------------------------------------------------------------------*
 *							CreateBatch()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates a batch to be uploaded, and if no batch is
 *				currently active, starts the upload process.
 *
 *	@author		Josh Williams
 *	@date		12-Jan-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZGuiApp::CreateBatch()
{
	QStringList vTagList;
	QStringList vGalleryList;

	/*
	 * Start the prompting.
	 */
	ZUserInfo *vInfo = NULL;
	ZULU_GUI_APP()->GetCurrentUser(&vInfo);

#if defined(ZOTO_TAGGING) || defined(ZOTO_GALLERIES)
	ZUploadWizard *vDlg = new ZUploadWizard(mainWidget(), "OptionsDlg", true);
	vDlg->Init(vInfo);

	if (vDlg->Execute() == QDialog::Accepted)
	{
		/*
		 * Process the options.
		 */
		SaveUser(vInfo);
#ifdef ZOTO_TAGGING
		vDlg->GetTagList(vTagList);
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
		vDlg->GetGalleryList(vGalleryList);
#endif // ZOTO_GALLERIES
	}
	else
		return;
#endif // ZOTO_TAGGING && ZOTO_GALLERIES

	dynamic_cast<ZMainWin *>(mainWidget())->GetUploadManager()->AddBatch(mFiles, mTotalBytes, vTagList, vGalleryList);
	dynamic_cast<ZMainWin *>(mainWidget())->GetImageView()->ClearAll();
	mFiles.clear();
	mTotalBytes = 0L;
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							  CreateKey()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates a new hash value from the given file name.
 *
 *	@author		Josh Williams
 *	@date		29-Jun-2005
 *
 *	@param		pFileName
 *					File name to be hashed.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
ZULONG ZGuiApp::CreateKey(const QString& pFileName)
{
	ZBYTE	vHash[17];
	ZULONG	vKey = 0;

	memset(vHash, '\0', sizeof(vHash));

	/*
	 * Converts to latin1, which won't always be "readable", but it's ok here.
	 */
	ZMD5Hasher::HashStringRaw(pFileName.latin1(), pFileName.length(), vHash, sizeof(vHash));

    /* XOR every 4 bytes together */
    vKey	= (vHash[0] ^ vHash[4] ^ vHash[8] ^ vHash[12]) +
				256 * (vHash[1] ^ vHash[5] ^ vHash[9] ^ vHash[13]) +
                256 * 256 * (vHash[2] ^ vHash[6] ^ vHash[10] ^ vHash[14]) +
                256 * 256 * 256 * (vHash[3] ^ vHash[7] ^ vHash[11] ^ vHash[15]);

    return vKey;
}

/*------------------------------------------------------------------*
 *							ShowUpgradeMessage()					*
 *------------------------------------------------------------------*/
/**
 *	@brief		Displays message to the user indicating they need
 *				to/can upgrade their client version.
 *
 *	@author		Josh Williams
 *	@date		30-Mar-2006
 *
 *	@param		pRequired
 *					Whether or not the upgrade is required.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
int ZGuiApp::ShowUpgradeMessage(bool pRequired, const QString &pVersion)
{
	QString vMessage;
	int		vRetval = 0;

	if (pRequired)
	{
		vMessage = tr("You must upgrade to version " + pVersion + " to continue.");
		vRetval = QMessageBox::critical(mainWidget(), GetAppName() + tr(" Update"), vMessage,
					QMessageBox::Ok | QMessageBox::Default,	QMessageBox::Cancel | QMessageBox::Escape,
					QMessageBox::NoButton);
	}
	else
	{
		vMessage = tr("A newer version of is available.\nUpgrade to " + pVersion + "?");
		vRetval = QMessageBox::question(mainWidget(), GetAppName() + tr(" Update"), vMessage,
				QMessageBox::Yes, QMessageBox::No);
	}

	if (pRequired)
	{
		if (vRetval == QMessageBox::No || vRetval == QMessageBox::Cancel)
			QMessageBox::critical(mainWidget(), GetAppName(),
					tr("The Zoto Uploader cannot continue.  It will now close."));
	}

	return vRetval;
}

/*------------------------------------------------------------------*
 *								Upgrade()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Attempts to download and install the latest client
 *				version.
 *
 *	@author		Josh Williams
 *	@date		30-Mar-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
void ZGuiApp::Upgrade()
{
#if ZULU_PLATFORM == PLATFORM_WINDOWS
	QString		vUpdateFile;

	mainWidget()->hide();
	ZUpdater vUpdater(mainWidget());
	vUpdater.show();
	if (vUpdater.Download(GetZspHost(), vUpdateFile))
		_spawnl( _P_DETACH, vUpdateFile, vUpdateFile, "/SILENT", NULL);
	else
		QMessageBox::critical(mainWidget(), GetAppName() + tr(" Update"),
			tr("Unable to download new client version.  "
				"Please visit ") + MakeURL(ZOTO_MAIN_URL) + tr(" to download."));
#elif ZULU_PLATFORM == PLATFORM_MAC || ZULU_PLATFORM == PLATFORM_LINUX
	ZUtils::OpenURL(mainWidget(), ZOTO_DOWNLOAD_URL);
#else
#error Unsupported platform
#endif
}

} // End Namespace

/* vi: set ts=4: */

