/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "LoginDlg.h"

/* System Headers */
#include <qhbox.h>
#include <qlayout.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qframe.h>
#include <qvbox.h>
#include <qgrid.h>
#include <qmessagebox.h>

/* Local Headers */
#include "GuiApp.h"
#include "URLLabel.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZLoginDlg::ZLoginDlg(QWidget *pParent/*=0*/, const char *pName/*=0*/, bool pModal/*=false*/,
		WFlags pFlags/*=0*/)
	: QDialog(pParent, pName, pModal, pFlags)
{
	setCaption(ZULU_GUI_APP()->GetAppName() + tr(" - Login"));

	QVBoxLayout *vMainLayout = new QVBoxLayout(this, 20, 5, "MainBox");
	vMainLayout->addStrut(350);


	/* Top - header info */
	QLabel *vTopLabel = new QLabel(tr("Login To Your Zoto Account"), this, "TopLabel");
	QFont vFont(ZULU_GUI_APP()->mainWidget()->font());
	vFont.setWeight(QFont::Bold);
	vTopLabel->setFont(vFont);
	vMainLayout->addWidget(vTopLabel, 0, Qt::AlignLeft);

	vMainLayout->addSpacing(20);

	/* Center stuff */
	QGrid *vFieldBox = new QGrid(2, Qt::Horizontal, this, "Grid");
	vFieldBox->setSizePolicy(QSizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum));
	vFieldBox->setSpacing(10);

	/* User prompt */
	new QLabel(tr("Username:"), vFieldBox, "UserLabel");
	mUserEdit = new QComboBox(true, vFieldBox, "UserEdit");
	mUserEdit->setAutoCompletion(true);

	/* Password prompt */
	new QLabel(tr("Password:"), vFieldBox, "PswdLabel");
	mPswdEdit = new QLineEdit(vFieldBox);
	mPswdEdit->setEchoMode(QLineEdit::Password);
	mPswdEdit->setMaxLength(30);
	vMainLayout->addWidget(vFieldBox, 1, Qt::AlignCenter);

	/* Remember me box */
	new QWidget(vFieldBox); // filler
	mRemember = new QCheckBox(tr("Remember my password"), vFieldBox, "Remember");

	/* Bottom controls */
	QGrid *vBottomBox = new QGrid(2, Qt::Horizontal, this, "LoginBox");
	vBottomBox->setSpacing(10);
	vBottomBox->setSizePolicy(QSizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum));

	QVBox *vLinkBox = new QVBox(vBottomBox, "LinkBox");
	mForgotUserLink = new ZURLLabel(QColor(63, 30, 232), Qt::blue, vLinkBox, "Link URL");
	mForgotUserLink->setText(tr("Forgot your login?"));
	mForgotUserLink->SetURL(ZULU_GUI_APP()->MakeURL(ZOTO_MAIN_URL));
	connect(mForgotUserLink, SIGNAL(Clicked()), this, SLOT(ShowNotImplemented()));
	/*
	mForgotPswdLink = new ZURLLabel(QColor(63, 30, 232), Qt::blue, vLinkBox, "Link URL");
	mForgotPswdLink->setText(tr("Forgot your password?"));
	//mForgotPswdLink->SetURL(ZULU_GUI_APP()->MakeURL(ZOTO_FORGOT_PSWD_URL));
	connect(mForgotPswdLink, SIGNAL(Clicked()), this, SLOT(ShowNotImplemented()));
	*/

	mLoginButton = new QPushButton(tr("Login"), vBottomBox);

	new QLabel(tr("Don't have an account?"), vBottomBox, "NewLabel");

	mNewButton = new QPushButton(tr("Create New"), vBottomBox);
	new QWidget(vBottomBox);

	mCancelButton = new QPushButton(tr("Cancel"), vBottomBox);
	vMainLayout->addWidget(vBottomBox, 0, Qt::AlignCenter);

	/* Load Users */
	ZUserMap vUsers = ZULU_GUI_APP()->GetUserMap();
	QIntDictIterator<ZUserInfo> vIt(vUsers);
	int vCount = 0;
	for (; vIt.current(); ++vIt)
	{
		qDebug("User %ld, %s", vIt.currentKey(), vIt.current()->mUserName.latin1());
		mUserEdit->insertItem(vIt.current()->mUserName, vCount);
		if (vIt.currentKey() == ZULU_GUI_APP()->GetCurrentUserIdx())
		{
			mUserEdit->setCurrentItem(vCount);
			if (vIt.current()->mAuto)
				mRemember->setChecked(true);
		}
		vCount++;
	}

	/* Signals and slots */
	connect(mLoginButton, SIGNAL(clicked()), this, SLOT(UserAccepted()));
	connect(mUserEdit, SIGNAL(textChanged(const QString &)), this, SLOT(UserEdited(const QString &)));
	connect(mUserEdit, SIGNAL(activated(int)), this, SLOT(UserChanged(int)));
	connect(mCancelButton, SIGNAL(clicked()), this, SLOT(reject()));
}

ZLoginDlg::~ZLoginDlg()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/
void ZLoginDlg::UserEdited(const QString &pText)
{
	qDebug("User field edited to: " + pText);
}

void ZLoginDlg::UserChanged(int pIndex)
{
	qDebug("User field changed to: " + mUserEdit->text(pIndex));
}

void ZLoginDlg::UserAccepted()
{
	if (mUserEdit->currentText() == "")
		mUserEdit->setFocus();
	else if (mPswdEdit->text() == "")
		mPswdEdit->setFocus();
	else
	{
		qDebug("User accepted dialog box");
		accept();
	}
}

/* 22-Sep-2006 */
void ZLoginDlg::ShowNotImplemented()
{
	QMessageBox::information(this, ZULU_GUI_APP()->GetAppName() + tr(" - Not Implemented"),
				tr("This feature is not yet implemented.\n\nIf you need to recover your username "
					"or password, you can do so\nby visiting http://www.") + ZULU_GUI_APP()->GetDomain() +
					tr("."));
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
