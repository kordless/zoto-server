#!/bin/bash
VOL_NAME="Zoto Uploader"
APP_NAME=bin/${VOL_NAME}.app
DMG_NAME=bin/${VOL_NAME}\ 3.0.1.dmg
rm -rf "${APP_NAME}"
rm -rf "${DMG_NAME}"
echo "Creating Frameworks directory..."
mkdir bin/zulu.app/Contents/Frameworks
echo "Processing dynamic libraries..."

LIBS=`otool -L bin/zulu.app/Contents/MacOS/zulu | awk '{print $1}' | grep /usr/local`
LIB_LIST=`for i in $LIBS; do eval basename $i; done`
for i in $LIBS;
do
	echo "   Processing $i...";
	cp $i bin/zulu.app/Contents/Frameworks;
	LIB_NAME=`eval basename $i`
	install_name_tool -id @executable_path/../Frameworks/${LIB_NAME} bin/zulu.app/Contents/Frameworks/${LIB_NAME}
	install_name_tool -change ${LIB_NAME} @executable_path/../Frameworks/${LIB_NAME} bin/zulu.app/Contents/MacOS/zulu
done
mv bin/zulu.app "${APP_NAME}"
echo -n "Creating disk image"
hdiutil create -fs HFS+ -volname "${VOL_NAME}" -srcfolder "${APP_NAME}" "${DMG_NAME}"
