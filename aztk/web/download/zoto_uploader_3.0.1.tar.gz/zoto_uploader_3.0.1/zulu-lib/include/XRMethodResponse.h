/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__XRMETHODRESPONSE_H_INCLUDED__)
#define __XRMETHODRESPONSE_H_INCLUDED__

/* System Headers */
#include <qdom.h>
#include <qvariant.h>
#include <qstring.h>

/* Local Headers */

/* Macros */

namespace ZOTO
{

/**
 *  @class      ZXRMethodResponse
 *  @brief      Encapsulates a response to an XMLRPC call.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		19-Jan-2006
 */
class ZXRMethodResponse : public QDomDocument
{
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZXRMethodResponse();
	ZXRMethodResponse(const QVariant &pResponse);
	ZXRMethodResponse(int pFaultCode, const QString &pFaultString);
	virtual ~ZXRMethodResponse();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	bool				GetFault(int &pFaultCode, QString &pFaultString) const;
	const QVariant&		GetResponse() const;

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	bool				ParseXmlRpc();

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	static void			FaultToDomDoc(int pFaultCode, const QString &pFaultString,
									QDomDocument &pDoc);
	static bool			FromDomDoc(const QDomDocument &pDoc, QVariant &pResult, bool &pIsFault);
	static void			ResponseToDomDoc(const QVariant &pResponse, QDomDocument &pDoc);

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	bool				mIsFault;
	int					mFaultCode;
	QString				mFaultString;
	QVariant			mResponse;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

inline
const QVariant& ZXRMethodResponse::GetResponse() const
{
	return mResponse;
}

} // End Namespace

#endif // __XRMETHODRESPONSE_H_INCLUDED__

/* vi: set ts=4: */
