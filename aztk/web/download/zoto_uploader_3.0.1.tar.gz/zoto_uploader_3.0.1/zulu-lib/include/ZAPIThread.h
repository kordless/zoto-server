/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__ZAPITHREAD_H_INCLUDED__)
#define __ZAPITHREAD_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qvariant.h>
#include <qobject.h>
#include <qmap.h>

/* Local Headers */
#include "Events.h"
#include "Client.h"
#include "Object.h"

/* Macros */

namespace ZOTO
{

class ZXRClient;

typedef QMap<int, ZStatusEvent::StatusType> ZRequestMap;

/**
 *  @class      ZZAPIThread
 *  @brief      Handles communication with the ZAPI server for gathering
 *  			user/galler information.
 *  @author     Josh Williams (josh@zoto.com)
 *  @version    0.1.0
 *  @date		22-Mar-2006
 */
class ZZAPIThread : public QObject, public ZObject
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZZAPIThread(QWidget *pParent);
	virtual ~ZZAPIThread();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	void				ProcessUser(ZUserInfo *pUser);
	void				Tag(ZUserInfo *pUser, const char *pId, const QString &pTag);
#ifdef ZOTO_GALLERIES
	void				AddToGallery(ZUserInfo *pUser, const QStringList &pImages,
								const QString &pGallery);
	void				CheckGallery(ZUserInfo *pUser, const QString &pGallery);
	void				CreateGallery(ZUserInfo *pUser, const ZGalleryInfo *pGallery);
#endif // ZOTO_GALLERIES
	void				RotateImage(ZUserInfo *pUser, const QString &pMD5, ZUSHORT pCount);
	void				Cancel();

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/

public slots:
	void				Results(int pHttpResp, const QVariant &pResponse);
	void				Error(int pHttpResp, int pFaultCode, const QString &pFaultText);

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	void				GetUserInfo();
#ifdef ZOTO_TAGGING
	void				GetTags();
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	void				GetGalleries();
	void				GetTemplates();
	void				GetWrappers();
#endif // ZOTO_GALLERIES
	void				LoadUserInfo(const QVariant &pResult);
#ifdef ZOTO_TAGGING
	ZRESULT				LoadTags(const QVariant &pResult, QStringList &pTags) const;
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
	ZRESULT				LoadGalleries(const QVariant &pResult);
	ZRESULT				LoadTemplates(const QVariant &pResult);
	ZRESULT				LoadWrappers(const QVariant &pResult);
#endif // ZOTO_GALLERIES
	void				MakeAuth(QValueList<QVariant> &pParms, const QString &pUser,
											const QString &pPswd);

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QWidget				*mParent;
	ZXRClient			*mXRClient;
	ZRequestMap			mRequests;
	ZUserInfo			*mUserInfo;
	bool				mCancelled;
	ZUSHORT				mRotCount;
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

inline
void ZZAPIThread::Cancel()
{
	mCancelled = true;
}

} // End Namespace

#endif // __ZAPITHREAD_H_INCLUDED__

/* vi: set ts=4: */
