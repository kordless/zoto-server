/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__CLIENT_H_INCLUDED__)
#define __CLIENT_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qstring.h>
#include <qwaitcondition.h>

/* Local Headers */
#include "Object.h"
#include "Types.h"
#include "Socket.h"
#include "Mutex.h"
#include "Packet.h"

/* Macros */


class QString;
class QFile;

namespace ZOTO
{

class ZErrorPacket;

typedef void(*ZSTAT_CALLBACK)(ZXferInfo* info);

/**
 *	@class		ZClientError
 *
 *	@brief		Rudamentary exception class for client errors.
 *	@author		Josh Williams
 *	@version	0.1.0
 *	@date		10-Apr-2006
 */
class ZClientError
{
public:
	ZClientError(ZRESULT pResult) {mResult = pResult;}
private:
	ZRESULT		mResult;
};

/**
 *	@class		ZClient
 *
 *	@brief		Heart of the Zulu library
 *	@author		Josh Williams
 *	@version	0.2.0
 *	@date		24-Dec-2004
 *
 *	@remarks	This is basically the core controller for all functionality
 *				common to all Zulu clients (cli/gui/etc).  It handles all
 *				packet based communication with the server, as well as the
 *				low level file transfers for uploading.
 */
class _ZuluExport ZClient : public ZObject
{
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZClient(const QString &pHost, ZUSHORT pPort);
	virtual ~ZClient();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	bool            	IsConnected() const;

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	ZRESULT     		Initialize();
	ZRESULT				ConnectServer();
	ZRESULT				CheckVersion(QString& pLatestVersion);
	ZRESULT				Authenticate(const QString& pUserName, const QString& pPswdHash);
	ZRESULT         	Disconnect();
	ZRESULT     		SendFile(ZXferInfo& pInfo, ZSTAT_CALLBACK pCallback = NULL,
								bool pBackground = false);
	void                PauseTransfer();
	void                ResumeTransfer();
	void                CancelTransfer();

public:
	/*==================================*
	 *			   OPERATORS			*
	 *==================================*/

protected:
	/*==================================*
	 *             CALLBACKS			*
	 *==================================*/

private:
	/*==================================*
	 *			  INTERNALS				*
	 *==================================*/
	ZRESULT				CreateSocket();
	static THREAD_FUNC	_TransferFile(void *pParam);
	ZRESULT				TransferFile();
	ZRESULT				ServerFlag(QFile& pFile, bool& pNeeded);
	ZRESULT				ServerFile(QFile& pFile);
	ZRESULT				ServerDone();
	ZRESULT         	SendAndReceive(ZPacket& pSend, ZPacket& pReceive,
										ZErrorPacket *pError);
	ZRESULT				ClientUpdate(eZXferStat pStat, double pProgress,
								long pBytes, double pSpeed, ZRESULT pErrcode);
	ZRESULT				ComputeSum(QFile& pFile, char *pChecksum);
	ZRESULT				ThreadCleanup(ZRESULT pResult);
	ZRESULT				GetFileDate(const QFile& pFile, char *pDate);
	ZRESULT				CreateTempFile(QFile& pFile);
	ZRESULT				DeleteTempFile();
	void				PauseWait();

private:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	QString				mHost;			/**< Host we should connect to. */
	ZUSHORT				mPort;			/**< Port to use for connections. */
	bool        		mConnected;		/**< Whether or not a connection has
											 been established with the Zoto
											 server. */
	bool                mPaused;		/**< uploading temporarily suspended */
	bool                mCancel;		/**< upload cancelled */
	ZSocket         	mSocket;		/**< Socket object to be used for
											 communicating with Zoto server */
	ZXferInfo			mCurrentInfo;	/**< Information about the current upload */
	ZSTAT_CALLBACK		mCallback;		/**< Optional function pointer to be
											 executed to provide status updates */
	THREAD_HANDLE		mXferThread;	/**< Upload thread handle. */
	QWaitCondition		mPauseWait;		/**< semaphore to signal resume */
	ZMutex				mThreadLock;	/**< Mutex to be waited on for thread
											 cleanup. */
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Returns whether or not a connection is currently established with
 *	the Zoto server.
 */
inline
bool ZClient::IsConnected() const
{
	return mConnected;
}

/**
 *	Pauses the current file transfer without disconnecting
 */
inline
void ZClient::PauseTransfer()
{
	mPaused = true;
}

/**
 *	Resumes the current file transfer, if one is active.
 */
inline
void ZClient::ResumeTransfer()
{
	mPaused = false;
	mPauseWait.wakeAll();
}

} // End Namespace

#endif // __CLIENT_H_INCLUDED__

/* vi: set ts=4: */
