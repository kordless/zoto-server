/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__APP_H_INCLUDED__)
#define __APP_H_INCLUDED__

#include "Platform.h"

/* System Headers */
#include <qapplication.h>
#include <qsettings.h>
#include <qstring.h>

/* Local Headers */
#include "Object.h"
#include "Client.h"
#include "Globals.h"

/* Macros */
#define ZULU_APP()  static_cast<ZApp *>(qApp)

namespace ZOTO
{

/**
 *	@class		ZApp
 *
 *	@brief		Wrapper class to hold global application settings.
 *	@author		Josh Williams
 *	@version	0.1.0
 *	@date		12-Mar-2005
 *
 *	@remarks	Handles initializing the client library, as well as loading and
 *				saving application-wide settings.  Also processes messages
 *				from other instances of the application, as well as checking
 *				for previous instances at startup.
 */
class ZApp : public QApplication, public ZObject
{
	Q_OBJECT
public:
	/*==================================*
	 *	   CONSTRUCTION/DESTRUCTION		*
	 *==================================*/
	ZApp(int& argc, char **argv);
	virtual ~ZApp();

public:
	/*==================================*
	 *			  ATTRIBUTES			*
	 *==================================*/
	ZUSHORT				GetVersMaj() const;
	ZUSHORT				GetVersMin() const;
	ZUSHORT				GetVersBuild() const;
	const QString&		GetVersString() const;
	const QString&		GetDomain() const;
	const QString&  	GetZspHost() const;
	ZUSHORT				GetZspPort() const;
	const QString&		GetZapiHost() const;
	ZUSHORT				GetZapiPort() const;
	const QString&		GetZapiPath() const;
	bool				GetCurrentUser(ZUserInfo **pInfo);
	short				GetCurrentUserIdx() const;
	virtual QString		GetAppName() const;
	virtual QString		GetVersName() const;
	virtual bool		TraceEnabled() const;
	const ZUserMap&		GetUserMap() const;

public:
	/*==================================*
	 *			  OPERATIONS			*
	 *==================================*/
	virtual bool   		Initialize();
	virtual void   		Shutdown();
	void				SetVersMaj(ZUSHORT pVersMaj);
	void				SetVersMin(ZUSHORT pVersMin);
	void				SetVersBuild(ZUSHORT pVersBuild);
	void				SetVersString(const char *pString);
	void            	SetZspHost(const char *pZspHost);
	void            	SetZspPort(ZUSHORT pZspPort);
	void				SetZapiHost(const char *pZapiHost);
	void				SetZapiPort(ZUSHORT pZapiPort);
	void				SetZapiPath(const char *pZapiPath);
	void				SetCurrentUser(short pIndex);
	bool				LoadUser(const QString &pUserName, ZUserInfo **pUser);
	short				SaveUser(ZUserInfo *pUser);
	virtual void   		SetAppName(const QString &pApp);
	const QString		BuildConfigPath(const QString &pSetting) const;
	virtual void		SetConfigPath(QSettings &pSettings) const;
	static bool			IsSupportedImage(const QString &pPath);
	static QString		MakeURL(const QString &pBase, const QString &pUser = "",
							const QString &pGallery = "");

public:
	/*==================================*
	 *			   CALLBACKS			*
	 *==================================*/
	static void			TraceHandler(QtMsgType pType, const char *pMsg);

private:
	/*==================================*
	 *			   INTERNALS			*
	 *==================================*/
	void				LoadUsers(QSettings &pSettings, const QString &pCurrentUser);

protected:
	/*==================================*
	 *             VARIABLES            *
	 *==================================*/
	ZUSHORT				mVersMaj;		/**< Major version number */
	ZUSHORT				mVersMin;		/**< Minor version number */
	ZUSHORT				mVersBuild;		/**< Build version number */
	QString				mVersString;	/**< Extra version information */
	QString				mDomain;		/**< Domain we're running on (zoto.com,zoto.biz,etc) */
	QString				mZspHost;		/**< Zoto host to connect to. */
	ZUSHORT         	mZspPort;		/**< Port number used for connecting */
	QString				mZapiHost;		/**< ZAPI host to connect to. */
	ZUSHORT				mZapiPort;		/**< Port number used for ZAPI communications */
	QString				mZapiPath;		/**< Path to use for ZAPI communications */
	short				mCurrentUser;	/**< Index of the current user in the user map. */
	QString         	mAppName;		/**< Name to be display for the
										  	 application */
	bool				mTracing;		/**< Output trace information? */
	ZUserMap			mUserMap;		/**< List of users from the registry/ini */
};



/********************************************************************
 *																	*
 *							I N L I N E S							*
 *																	*
 ********************************************************************/

/**
 *	Returns the major version number for this instance of the client.
 */
inline
ZUSHORT ZApp::GetVersMaj() const
{
	return mVersMaj;
}

/**
 *	Returns the minor version number for this instance of the client.
 */
inline
ZUSHORT ZApp::GetVersMin() const
{
	return mVersMin;
}

/**
 *	Returns the build number for this instance of the client.
 */
inline
ZUSHORT ZApp::GetVersBuild() const
{
	return mVersBuild;
}

/**
 *	Returns the extra information associated with this version.
 */
inline
const QString& ZApp::GetVersString() const
{
	return mVersString;
}

/**
 *	Returns the domain currently being accessed.
 */
inline
const QString& ZApp::GetDomain() const
{
	return mDomain;
}

/**
 *	Returns the host (IP address) currently used for ZSP connections.
 */
inline
const QString& ZApp::GetZspHost() const
{
	return mZspHost;
}

/**
 *	Returns the port currently defined for ZSP connections.
 */
inline
ZUSHORT ZApp::GetZspPort() const
{
	return mZspPort;
}

/**
 *	Returns the host (IP address) being used for ZAPI connections.
 */
inline
const QString& ZApp::GetZapiHost() const
{
	return mZapiHost;
}

/**
 *	Returns the port currently defined for ZAPI connections.
 */
inline
ZUSHORT ZApp::GetZapiPort() const
{
	return mZapiPort;
}

/**
 *	Returns the path currently defined for ZAPI connections.
 */
inline
const QString& ZApp::GetZapiPath() const
{
	return mZapiPath;
}

/**
 *	Returns the object representing the currently signed-on user.
 */
inline
bool ZApp::GetCurrentUser(ZUserInfo **pInfo)
{
	if (mCurrentUser != -1)
	{
		*pInfo = mUserMap[mCurrentUser];
		return true;
	}
	else
		return false;
}

/**
 *	Returns the index of the current user in the user map.
 */
inline
short ZApp::GetCurrentUserIdx() const
{
	return mCurrentUser;
}

/**
 *	Returns the name of the application (used for window titles).
 */
inline
QString ZApp::GetAppName() const
{
	return mAppName;
}

/**
 *	Returns the name of the application with the version appended.
 */
inline
QString ZApp::GetVersName() const
{
	QString vVersName;
	QString vVersion;
	if (GetVersBuild() == 0)
		vVersion = QString("%1.%2%3").arg(GetVersMaj()).arg(GetVersMin()).arg(GetVersString());
	else
		vVersion = QString("%1.%2.%3%4").arg(GetVersMaj()).arg(GetVersMin()).arg(GetVersBuild()).arg(GetVersString());

	vVersName = GetAppName() + " " + vVersion;
	return vVersName;
}

/**
 *	Returns whether or not tracing was enabled in the registry.
 */
inline
bool ZApp::TraceEnabled() const
{
	return mTracing;
}

/**
 *	Returns the list of available users.
 */
inline
const ZUserMap& ZApp::GetUserMap() const
{
	return mUserMap;
}

/**
 *	Sets the major version number used by this instance of the client.
 */
inline
void ZApp::SetVersMaj(ZUSHORT pVersMaj)
{
	mVersMaj = pVersMaj;
}

/**
 *	Sets the minor version number used by this instance of the client.
 */
inline
void ZApp::SetVersMin(ZUSHORT pVersMin)
{
	mVersMin = pVersMin;
}

/**
 *	Sets the build number used by this instance of the client.
 */
inline
void ZApp::SetVersBuild(ZUSHORT pVersBuild)
{
	mVersBuild = pVersBuild;
}

/**
 *	Sets the extra version information used by this instance of the client.
 */
inline
void ZApp::SetVersString(const char *pVersString)
{
	mVersString = pVersString;
}

/**
 *	Sets the host used for ZSP connections.
 */
inline
void ZApp::SetZspHost(const char *pZspHost)
{
	mZspHost = pZspHost;
}

/**
 *	Sets the port number of the Zoto server to connect to.
 */
inline
void ZApp::SetZspPort(ZUSHORT pZspPort)
{
	mZspPort = pZspPort;
}

/**
 *	Sets the host used for ZAPI connections.
 */
inline
void ZApp::SetZapiHost(const char *pZapiHost)
{
	mZapiHost = pZapiHost;
}

/**
 *	Sets the port number of the ZAPI server to connect to.
 */
inline
void ZApp::SetZapiPort(ZUSHORT pZapiPort)
{
	mZapiPort = pZapiPort;
}

/**
 *	Sets the path used for ZAPI communications.
 */
inline
void ZApp::SetZapiPath(const char *pZapiPath)
{
	mZapiPath = pZapiPath;
}

/**
 *	Sets the name of the application to be used in window titles.
 */
inline
void ZApp::SetAppName(const QString& pApp)
{
	QSettings vConfig;

	mAppName = pApp;
	SetConfigPath(vConfig);
	vConfig.writeEntry(BuildConfigPath("/AppTitle"), mAppName);
}

/**
 *	Sets the currently logged on user.
 */
inline
void ZApp::SetCurrentUser(short pIndex)
{
	QSettings vConfig;
	SetConfigPath(vConfig);

	if (pIndex == -1)
		vConfig.writeEntry(BuildConfigPath("/CurrentUser"), "");
	else
		vConfig.writeEntry(BuildConfigPath("/CurrentUser"), mUserMap[pIndex]->mUserName);

	mCurrentUser = pIndex;
}

} // End Namespace


#endif // __APP_H_INCLUDED__

/* vi: set ts=4: */
