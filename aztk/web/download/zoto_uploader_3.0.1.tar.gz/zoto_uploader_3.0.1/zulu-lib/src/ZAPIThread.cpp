/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "ZAPIThread.h"

/* System Headers */

/* Local Headers */
#include "XRClient.h"
#include "App.h"
#include "FileDownloader.h"

/* Macros */

namespace ZOTO
{

DECLARE_CLASS( "ZZAPIThread" )

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZZAPIThread::ZZAPIThread(QWidget *pParent)
	: mParent(pParent), mXRClient(NULL), mCancelled(false), mRotCount(0)
{
	mXRClient = new ZXRClient(ZULU_APP()->GetZapiHost(),
				ZULU_APP()->GetZapiPath(),
				ZULU_APP()->GetZapiPort());

	connect(mXRClient, SIGNAL(Fault(int, int, const QString&)),
				this, SLOT(Error(int, int, const QString&)));
	connect(mXRClient, SIGNAL(Response(int, const QVariant &)),
				this, SLOT(Results(int, const QVariant &)));
}

ZZAPIThread::~ZZAPIThread()
{
	if (mXRClient)
		delete mXRClient;
}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							ProcessUser()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Starts the ZAPI processing chain.
 *
 *	@author		Josh Williams
 *	@date		24-Mar-2006
 *
 *	@param		pUser
 *					ZUserInfo structure to hold all information
 *					accumulated from ZAPI.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::ProcessUser(ZUserInfo *pUser)
{
	BEG_FUNC("%p", pUser);

	mUserInfo = pUser;

	GetUserInfo();

	END_FUNCV();
}

#ifdef ZOTO_TAGGING
/*------------------------------------------------------------------*
 *								  Tag()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Requests that the ZAPI server add this image to the
 *				specified tag.
 *
 *	@author		Josh Williams
 *	@date		30-Mar-2006
 *
 *	@param		pId
 *					ID (MD5 hash) of the image being categorized.
 *	@param		pTag
 *					Tag to be assigned.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 * 31-Oct-2005	Added username and password as		Josh Williams	*
 * 				arguments.											*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::Tag(ZUserInfo *pUser, const char *pId, const QString& pTag)
{
	BEG_FUNC("%p, %s, %d", pUser, pId, &pTag);

	QValueList<QVariant>	vParms;
	MakeAuth(vParms, pUser->mUserName, pUser->mPswdHash);
	vParms.push_back(QVariant(pUser->mUserName));
	vParms.push_back(QVariant(QString(pId)));
	vParms.push_back(QVariant(pTag));

	int id = mXRClient->Call("tags.tag_image", vParms);
	mRequests[id] = ZStatusEvent::TAG_PHOTO;
	END_FUNCV();
}
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
/*------------------------------------------------------------------*
 *							AddToGallery()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Requests that the ZAPI server add these images to the
 *				specified gallery.
 *
 *	@author		Josh Williams
 *	@date		30-Mar-2006
 *
 *	@param		pId
 *					ID (MD5 hash) of the image being categorized.
 *	@param		pTag
 *					Numeric identifier of the desired tag.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 * 31-Oct-2005	Added username and password as		Josh Williams	*
 * 				arguments.											*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::AddToGallery(ZUserInfo *pUser, const QStringList &pImages,
									const QString &pGallery)
{
	BEG_FUNC("%p, %p, %p", pUser, &pImages, &pGallery);

	QValueList<QVariant>	vParms;
	MakeAuth(vParms, pUser->mUserName, pUser->mPswdHash);
	vParms.push_back(QVariant(pGallery));

	/*
	 * TODO: Figure out why we have to do such nonsense
	 * This entire block should be as simple as:
	 * vParms.push_back(QVariant(pImages));
	 * but that segfaults o.O */
	QStringList::const_iterator vIt;
	QValueList<QVariant> vImgVar;
	for (vIt = pImages.begin(); vIt != pImages.end(); vIt++)
	{
		vImgVar.append(QVariant(*vIt));
	}
	vParms.push_back(vImgVar);
	/* End nonsense */

	int id = mXRClient->Call("galleries.add_images", vParms);
	mRequests[id] = ZStatusEvent::ADD_TO_GALLERY;
	END_FUNCV();
}

/*------------------------------------------------------------------*
 *							CheckGallery()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Checks to see if a given gallery name is taken.
 *
 *	@author		Josh Williams
 *	@date		31-Mar-2006
 *
 *	@param		pUser
 *					User info to use for auth.
 *	@param		pGallery
 *					Gallery name to be checked.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::CheckGallery(ZUserInfo *pUser, const QString &pGallery)
{
	BEG_FUNC("%p, %p[%s]", pUser, &pGallery, pGallery.latin1());

	QValueList<QVariant>	vParms;
	MakeAuth(vParms, pUser->mUserName, pUser->mPswdHash);
	vParms.push_back(QVariant(pGallery));

	int id = mXRClient->Call("galleries.gallery_exists", vParms);
	mRequests[id] = ZStatusEvent::CHECK_GALLERY;
	END_FUNCV();
}
	
/*------------------------------------------------------------------*
 *							CreateGallery()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates a gallery with the specified attributes.
 *
 *	@author		Josh Williams
 *	@date		03-Apr-2006
 *
 *	@param		pUser
 *					User info to use for auth.
 *	@param		pGallery
 *					Data associated with the gallery.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::CreateGallery(ZUserInfo *pUser, const ZGalleryInfo *pGallery)
{
	BEG_FUNC("%p, %p", pUser, pGallery);

	QValueList<QVariant>	vParms;
	QMap<QString, QVariant>	vGalleryArgs;
	MakeAuth(vParms, pUser->mUserName, pUser->mPswdHash);
	vParms.push_back(QVariant(pGallery->mName));

	vGalleryArgs["title"] = QVariant(pGallery->mTitle);
	vGalleryArgs["description"] = QVariant(pGallery->mDesc);
	vGalleryArgs["template_id"] = QVariant(pGallery->mTemplate);
	vGalleryArgs["password"] = QVariant(pGallery->mPassword);
	vGalleryArgs["wrapper_style"] = QVariant(pGallery->mWrapper);
	vParms.push_back(QVariant(vGalleryArgs));

	int id = mXRClient->Call("galleries.add_edit", vParms);
	mRequests[id] = ZStatusEvent::CREATE_GALLERY;
	END_FUNCV();
}
#endif // ZOTO_GALLERIES

/*------------------------------------------------------------------*
 *							RotateImage()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Rotates an image on the server.
 *
 *	@author		Josh Williams
 *	@date		11-Apr-2006
 *
 *	@param		pUser
 *					User info to use for auth.
 *	@param		pMD5
 *					Image to be rotated.
 *	@param		pCount
 *					Number of times to rotate (clockwise)
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::RotateImage(ZUserInfo *pUser, const QString &pMD5, ZUSHORT pCount)
{
	BEG_FUNC("%p, %p, %d", pUser, &pMD5, pCount);

	QValueList<QVariant>	vParms;
	MakeAuth(vParms, pUser->mUserName, pUser->mPswdHash);
	vParms.push_back(QVariant(pMD5));
	vParms.push_back(QVariant("cw"));
	vParms.push_back(QVariant(pCount));

	int id = mXRClient->Call("images.rotate", vParms);
	mRequests[id] = ZStatusEvent::IMAGE_ROTATE;
	END_FUNCV();
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								Results()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Called in response to a successful ZAPI call.
 *
 *	@author		Josh Williams
 *	@date		23-Mar-2006
 *
 *	@param		pHttpResp
 *					Id of the original request.
 *	@param		pResponse
 *					Response data.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::Results(int pHttpResp, const QVariant &pResponse)
{
	static QString vResult;

	BEG_FUNC("%d, %p", pHttpResp, &pResponse);

	if (mCancelled)
	{
		ZTRACE("User cancelled us!\n");
		END_FUNCV();
	}

	ZStatusEvent *vEvt = new ZStatusEvent();
	vEvt->mErrcode = ZERR_SUCCESS;

	ZTRACE("Got some results for request %d\n", pHttpResp);

	/*
	 * First of all, make sure we're even expecting this response.
	 */
	if (mRequests.find(pHttpResp) != mRequests.end())
	{
		vEvt->mType = mRequests[pHttpResp];
		switch (vEvt->mType)
		{
		case ZStatusEvent::VERSION:
		case ZStatusEvent::AUTH:
			break;
		case ZStatusEvent::USER:
			ZTRACE("Got some user data back\n");
			//sleep(2);
			LoadUserInfo(pResponse);
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
#ifdef ZOTO_TAGGING
			GetTags();
#endif // ZOTO_TAGGING
			break;
#ifdef ZOTO_TAGGING
		case ZStatusEvent::TAGS:
			ZTRACE("Got some tag data back\n");
			//sleep(2);
			ZTRACE("before tag list: %d\n", mUserInfo->mTags.size());
			LoadTags(pResponse, mUserInfo->mTags);
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
#ifdef ZOTO_GALLERIES
			GetGalleries();
#endif
			break;
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
		case ZStatusEvent::GALLERY:
			ZTRACE("Got some gallery data back\n");
			//sleep(2);
			LoadGalleries(pResponse);
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
			GetTemplates();
			break;
		case ZStatusEvent::TEMPLATES:
			ZTRACE("Got some template data back\n");
			//sleep(2);
			LoadTemplates(pResponse);
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
			GetWrappers();
			break;
		case ZStatusEvent::WRAPPERS:
			ZTRACE("Got some wrapper data back\n");
			//sleep(2);
			LoadWrappers(pResponse);
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
			break;
#endif // ZOTO_GALLERIES
#ifdef ZOTO_TAGGING
		case ZStatusEvent::TAG_PHOTO:
			ZTRACE("Tagged a photo\n");
			//sleep(2);
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
			break;
#endif // ZOTO_TAGGING
#ifdef ZOTO_GALLERIES
		case ZStatusEvent::ADD_TO_GALLERY:
			ZTRACE("Added photo to gallery\n");
			//sleep(2);
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
			break;
		case ZStatusEvent::CREATE_GALLERY:
			ZTRACE("Created a gallery\n");
			//sleep(2);
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
			break;
		case ZStatusEvent::CHECK_GALLERY:
			ZTRACE("Gallery check complete\n");
			//sleep(2);
			static int pResult;
			pResult = pResponse.toInt();
			vEvt->setData(static_cast<void *>(&pResult));
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
			break;
#endif // ZOTO_GALLERIES
		case ZStatusEvent::IMAGE_ROTATE:
			ZTRACE("Image rotation complete\n");
			vResult = pResponse.toString();
			vEvt->setData(static_cast<void *>(&vResult));
			QApplication::postEvent(mParent, vEvt);
			ZULU_APP()->processEvents();
			break;
		default:
			break;
		}
	}
	END_FUNCV();
}

/*------------------------------------------------------------------*
 *								Error()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Called in response to an unuccessful ZAPI call.
 *
 *	@author		Josh Williams
 *	@date		23-Mar-2006
 *
 *	@param		pHttpResp
 *					Id of the original request.
 *	@param		pFaultCode
 *					Fault code encountered.
 *	@param		pFaultText
 *					Description of the fault.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::Error(int pHttpResp, int pFaultCode, const QString &pFaultText)
{
	BEG_FUNC("%d, %d, %p", pHttpResp, pFaultCode, &pFaultText);

	Q_UNUSED(pFaultCode);
	Q_UNUSED(pFaultText);
	ZStatusEvent *vEvt = new ZStatusEvent(mRequests[pHttpResp]);

	ZTRACE("Got a fault for request %d\n", pHttpResp);
	ZTRACE("Fault -> %d : %s\n", pFaultCode, pFaultText.latin1());
	vEvt->mErrcode = ZERR_SERVER_ERROR;
	QApplication::postEvent(mParent, vEvt);

	END_FUNCV();
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							GetUserInfo()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Executes the ZAPI call users.get_info().
 *
 *	@author		Josh Williams
 *	@date		23-Mar-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::GetUserInfo()
{
	BEG_FUNC(NULL);

	QValueList<QVariant>	vParms;
	QMap<QVariant, QVariant>	vAuth;
	MakeAuth(vParms, mUserInfo->mUserName, mUserInfo->mPswdHash);
	vParms.push_back(QVariant(mUserInfo->mUserName));
	vParms.push_back(QVariant(mUserInfo->mPswdHash));
	int id = mXRClient->Call("users.get_info", vParms);
	mRequests[id] = ZStatusEvent::USER;

	END_FUNCV();
}

#ifdef ZOTO_TAGGING
/*------------------------------------------------------------------*
 *								GetTags()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Executes the ZAPI call category.get_tree().
 *
 *	@author		Josh Williams
 *	@date		23-Mar-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::GetTags()
{
	BEG_FUNC(NULL);

	QValueList<QVariant>	vParms;
	MakeAuth(vParms, mUserInfo->mUserName, mUserInfo->mPswdHash);
	vParms.push_back(QVariant(mUserInfo->mUserName));
	int id = mXRClient->Call("tags.get_list", vParms);
	mRequests[id] = ZStatusEvent::TAGS;

	END_FUNCV();
}
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
/*------------------------------------------------------------------*
 *							GetGalleries()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Executes the ZAPI call galleries.get_gallery_list().
 *
 *	@author		Josh Williams
 *	@date		23-Mar-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::GetGalleries()
{
	BEG_FUNC(NULL);

	QValueList<QVariant>	vParms;
	MakeAuth(vParms, mUserInfo->mUserName, mUserInfo->mPswdHash);
	vParms.push_back(QVariant(mUserInfo->mUserName));
	vParms.push_back(QVariant(0));
	vParms.push_back(QVariant(0));
	int id = mXRClient->Call("galleries.get_gallery_list", vParms);
	mRequests[id] = ZStatusEvent::GALLERY;

	END_FUNCV();
}

/*------------------------------------------------------------------*
 *							GetTemplates()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Executes the ZAPI call galleries.get_template_list().
 *
 *	@author		Josh Williams
 *	@date		29-Mar-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::GetTemplates()
{
	BEG_FUNC(NULL);

	QValueList<QVariant>	vParms;
	MakeAuth(vParms, mUserInfo->mUserName, mUserInfo->mPswdHash);
	vParms.push_back(QVariant(mUserInfo->mUserName));
	int id = mXRClient->Call("galleries.get_template_list", vParms);
	mRequests[id] = ZStatusEvent::TEMPLATES;

	END_FUNCV();
}

/*------------------------------------------------------------------*
 *							GetWrappers()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Executes the ZAPI call galleries.get_wrapper_list().
 *
 *	@author		Josh Williams
 *	@date		03-Apr-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::GetWrappers()
{
	BEG_FUNC(NULL);

	QValueList<QVariant>	vParms;
	MakeAuth(vParms, mUserInfo->mUserName, mUserInfo->mPswdHash);
	int id = mXRClient->Call("galleries.get_wrapper_list", vParms);
	mRequests[id] = ZStatusEvent::WRAPPERS;

	END_FUNCV();
}
#endif // ZOTO_GALLERIES

/*------------------------------------------------------------------*
 *							LoadUserInfo()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Takes the results of a call to users.get_info() and
 *				extracts the needed data.
 *
 *	@author		Josh Williams
 *	@date		23-Mar-2006
 *
 *	@param		pResult
 *					Data returned by the ZAPI server.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZAPIThread::LoadUserInfo(const QVariant &pResult)
{
	BEG_FUNC("%p", &pResult);

	QMap<QString, QVariant> vMap;
	QMap<QString, QVariant> vAcctInfo;

	vMap = pResult.toMap();
	if (vMap.find("quota_kb") != vMap.end())
		mUserInfo->mQuota = vMap["quota_kb"].toInt();
	if (vMap.find("disk_usage") != vMap.end())
		mUserInfo->mUsage = vMap["disk_usage"].toInt();
	if (vMap.find("total_images") != vMap.end())
		mUserInfo->mImgCount = vMap["total_images"].toInt();
	if (vMap.find("account_type_info") != vMap.end())
	{
		vAcctInfo = vMap["account_type_info"].toMap();
		if (vAcctInfo.find("name") != vAcctInfo.end())
			mUserInfo->mType = vAcctInfo["name"].toString();
	}

	ZTRACE("User info dump\n"
		"\tquota        => %d\n"
		"\tdisk_usage   => %d\n"
		"\tcnt_images   => %d\n"
		"\taccount_type => %s\n",
		mUserInfo->mQuota,
		mUserInfo->mUsage,
		mUserInfo->mImgCount,
		mUserInfo->mType.latin1());

	END_FUNCV();
}

#ifdef ZOTO_TAGGING
/*------------------------------------------------------------------*
 *								LoadTags()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Iterates over the list of tags received from the
 *				ZAPI server and loads them into the list.
 *
 *	@author		Josh Williams
 *	@date		24-Mar-2006
 *
 *	@param		pResult
 *					Value received from the ZAPI server.
 *	@param		pTags
 *					List to hold the tags.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZZAPIThread::LoadTags(const QVariant &pResult, QStringList &pTags) const
{
	QValueList<QVariant>	vTagList;
	QValueList<QVariant>::Iterator vIt;
	QMap<QString, QVariant>	vTagMap;
	QString					vTagName;
	int						vCount = 0;

	BEG_FUNC("%p, %p", &pResult, &pTags);

	/* sanity checking */
	if (!pResult.canCast(QVariant::List))
		return END_FUNC(ZERR_UNKNOWN);

	vTagList = pResult.toList();

	ZTRACE("vTagList.size() => [%d]\n", vTagList.size());
	for (vIt = vTagList.begin(); vIt != vTagList.end(); ++vIt)
	{
		if (!(*vIt).canCast(QVariant::Map))
			return END_FUNC(ZERR_UNKNOWN);

		vTagMap = (*vIt).toMap();

		vTagName = vTagMap["tag_name"].toString();
		vCount = vTagMap["cnt_images"].toInt();
		ZTRACE("Adding tag: %s\n", vTagName.latin1());
		pTags.append(vTagName);
		ZTRACE("Added tag");
	}
	pTags.sort();

	return END_FUNC(ZERR_SUCCESS);
}
#endif // ZOTO_TAGGING

#ifdef ZOTO_GALLERIES
/*------------------------------------------------------------------*
 *							LoadGalleries()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Iterates over the list of galleries received from the
 *				ZAPI server and loads them into the list.
 *
 *	@author		Josh Williams
 *	@date		22-Apr-2005
 *
 *	@param		pResponse
 *					Value received from the ZAPI server.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZZAPIThread::LoadGalleries(const QVariant &pResponse)
{
	BEG_FUNC("%p, %p", &pResponse);

	/* sanity checking */
	if (!pResponse.canCast(QVariant::List))
		return END_FUNC(ZERR_UNKNOWN);

	QValueList<QVariant> vGalleryList;
	QValueList<QVariant>::const_iterator vIt;
	QMap<QString, QVariant> vGallery;

	vGalleryList = pResponse.toList();

	ZTRACE("vGalleryList.count() => [%d]\n", vGalleryList.count());
	
	for (vIt = vGalleryList.begin(); vIt!= vGalleryList.end(); vIt++)
	{
		if (!(*vIt).canCast(QVariant::Map))
			return END_FUNC(ZERR_UNKNOWN);

		vGallery = (*vIt).toMap();

		if (vGallery.find("gallery_name") != vGallery.end() &&
			vGallery.find("title") != vGallery.end() &&
			vGallery.find("description") != vGallery.end() &&
			vGallery.find("cnt_images") != vGallery.end() &&
			vGallery.find("updated") != vGallery.end() &&
			vGallery.find("template_id") != vGallery.end() &&
			vGallery.find("pwprotect") != vGallery.end())
		{
			ZGalleryInfo *vInfo = new ZGalleryInfo();
			vInfo->mName = vGallery["gallery_name"].toString();
			vInfo->mTitle = vGallery["title"].toString();
			vInfo->mDesc = vGallery["description"].toString();
			vInfo->mImgCount = vGallery["cnt_images"].toInt();
			vInfo->mUpdated = vGallery["updated"].toString();
			vInfo->mPwProtect = vGallery["pwprotect"].toBool();
			vInfo->mTemplate = vGallery["template_id"].toInt();
			ZTRACE("Adding gallery [%s:%s]\n", vInfo->mName.latin1(), vInfo->mTitle.latin1());
			mUserInfo->mGalleryMap.insert(vInfo->mName, vInfo);
		}
	}

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							LoadTemplates()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Iterates over the list of templates received from the
 *				ZAPI server and loads them into the list.
 *
 *	@author		Josh Williams
 *	@date		22-Apr-2005
 *
 *	@param		pResponse
 *					Value received from the ZAPI server.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZZAPIThread::LoadTemplates(const QVariant &pResponse)
{
	QValueList<QVariant>	vTemplateList;
	QValueList<QVariant>::const_iterator vIt;
	QMap<QString, QVariant> vTemplate;
	ZFileDownloader			vDownloader(this, ZULU_APP()->GetZapiHost());

	BEG_FUNC("%p, %p", &pResponse);

	/* sanity checking */
	if (!pResponse.canCast(QVariant::List))
		return END_FUNC(ZERR_UNKNOWN);

	vTemplateList = pResponse.toList();

	ZTRACE("vTemplateList.count() => [%d]\n", vTemplateList.count());
	
	for (vIt = vTemplateList.begin(); vIt!= vTemplateList.end(); vIt++)
	{
		if (!(*vIt).canCast(QVariant::Map))
			return END_FUNC(ZERR_UNKNOWN);

		vTemplate = (*vIt).toMap();

		if (vTemplate.find("template_id") != vTemplate.end() &&
			vTemplate.find("name") != vTemplate.end() &&
			vTemplate.find("sample_image_url") != vTemplate.end())
		{
			ZTemplateInfo *vInfo = new ZTemplateInfo();
			vInfo->mId = vTemplate["template_id"].toInt();
			vInfo->mName = vTemplate["name"].toString();
			vInfo->mSampleUrl = vTemplate["sample_image_url"].toString();
			ZTRACE("Adding template [%d:%s]\n", vInfo->mId, vInfo->mName.latin1());
			mUserInfo->mTemplateMap.insert(vInfo->mId, vInfo);
			QBuffer vBuffer;
			if (vDownloader.GetFile(vInfo->mSampleUrl, vBuffer, false) != ZERR_SUCCESS)
				return END_FUNC(ZERR_UNKNOWN);
			else
			{
				vInfo->mThumb.loadFromData(vBuffer.buffer());
			}
		}
	}

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							LoadWrappers()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		TODO: FIXME
 *
 *	@author		Josh Williams
 *	@date		03-Apr-2006
 *
 *	@param		pResponse
 *					Value received from the ZAPI server.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZZAPIThread::LoadWrappers(const QVariant &pResponse)
{
	QValueList<QVariant>	vWrapperList;
	QValueList<QVariant>::const_iterator vIt;
	QMap<QString, QVariant> vWrapper;
	ZFileDownloader			vDownloader(this, ZULU_APP()->GetZapiHost());

	BEG_FUNC("%p, %p", &pResponse);


	/* sanity checking */
	if (!pResponse.canCast(QVariant::List))
		return END_FUNC(ZERR_UNKNOWN);

	vWrapperList = pResponse.toList();

	ZTRACE("vWrapperList.count() => [%d]\n", vWrapperList.count());
	
	for (vIt = vWrapperList.begin(); vIt!= vWrapperList.end(); vIt++)
	{
		if (!(*vIt).canCast(QVariant::Map))
			return END_FUNC(ZERR_UNKNOWN);

		vWrapper = (*vIt).toMap();

		if (vWrapper.find("name") != vWrapper.end())
		{
			mUserInfo->mWrappers.append(vWrapper["name"].toString());
		}
	}

	return END_FUNC(ZERR_SUCCESS);
}
#endif // ZOTO_GALLERIES

void ZZAPIThread::MakeAuth(QValueList<QVariant> &pParms, const QString &pUser,
											const QString &pPswd)
{
	QMap<QString, QVariant>	vAuth;

	pParms.push_back(QVariant(ZAPI_KEY));

	vAuth["username"] = QVariant(pUser);
	vAuth["pswd_hash"] = QVariant(pPswd);
	pParms.push_back(vAuth);
}

} // End Namespace

/* vi: set ts=4: */
