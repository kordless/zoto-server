/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "FileDownloader.h"

/* System Headers */

/* Local Headers */
#include "App.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

DECLARE_CLASS( "ZFileDownloader" )

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZFileDownloader::ZFileDownloader(QObject *pParent, const QString &pHost)
	: QObject(pParent), mHost(pHost)
{

}

ZFileDownloader::~ZFileDownloader()
{
	mSock.Close();
}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *						  	   GetFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Downloads the specified file, writing the data into
 *				the supplied buffer.
 *
 *	@author		Josh Williams
 *	@date		29-Mar-2006
 *
 *	@param		pFile
 *					Absolute path of the file to be downloaded.
 *				pBuffer
 *					Buffer to hold the downloaded data.
 *				pProgress
 *					Whether or not to notify our parent object
 *					of progress while downloading.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZFileDownloader::GetFile(const QString &pFile, QBuffer &pBuffer, bool pProgress)
{
	ZRESULT		vRetval = ZERR_SUCCESS;
	QString		vCommand;
	long		vContentLength = 0L;
	long		vBytes;

	BEG_FUNC("%p, %p, %s", &pFile, &pBuffer, pProgress ? "true" : "false");

	vCommand = "GET " + pFile + " HTTP/1.0\r\n";
	vCommand += "User-Agent: Zoto Uploader\r\n\r\n";

	ZTRACE("Executing command: %s\n", vCommand.latin1());

	/*
	 * Connect to the server.
	 */
	if ((vRetval = Init()) != ZERR_SUCCESS)
	{
		ZTRACE("Unable to connect.\n");
		mSock.Close();
		return END_FUNC(vRetval);
	}

	ZULU_APP()->processEvents();

	/*
	 * Send our GET command.
	 */
	if ((vRetval = mSock.Send(vCommand.latin1(), strlen(vCommand.latin1()))) != ZERR_SUCCESS)
	{
		ZTRACE("Unable to send stuff.\n");
		mSock.Close();
		return END_FUNC(vRetval);
	}

	ZULU_APP()->processEvents();

	/*
	 * Try and process the header recieved from the server.
	 */
	if ((vRetval - ProcessHeader(vContentLength, pBuffer, vBytes)) != ZERR_SUCCESS)
	{
		ZTRACE("Unable to receive header.\n");
		mSock.Close();
		return END_FUNC(vRetval);
	}

	ZULU_APP()->processEvents();

	/*
	 * Header OK!  Receive the file data.
	 */
	if ((vRetval = ReceiveFile(vContentLength, vBytes, pBuffer, pProgress)) != ZERR_SUCCESS)
	{
		ZTRACE("Unable to receive file.\n");
		mSock.Close();
		return END_FUNC(vRetval);
	}

	ZULU_APP()->processEvents();

	mSock.Close();
	return END_FUNC(ZERR_SUCCESS);
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *						   InitializeAndConnect()					*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates the socket object and attempts to connect to
 *				the Zoto web site.
 *
 *	@author		Josh Williams
 *	@date		27-Jun-2005
 *
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 * 29-Mar-2006	Stole from Updater and made more	Josh Williams	*
 * 				modular.											*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZFileDownloader::Init()
{
	ZRESULT		vRetval;

	BEG_FUNC(NULL);

	if ((vRetval = mSock.Create(0, SOCK_STREAM)) != ZERR_SUCCESS)
	{
		ZTRACE("Unable to create socket\n");
		return END_FUNC(vRetval);
	}

	if ((vRetval = mSock.Connect(mHost.latin1(), 80, 10)) != ZERR_SUCCESS)
	{
		ZTRACE("Unable to connect to host.\n");
		return END_FUNC(vRetval);
	}

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 ProcessHeader()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Attempts to receive the HTTP header from the Zoto web
 *				server.
 *
 *	@author		Josh Williams
 *	@date		27-Jun-2005
 *
 *	@param		pLength
 *					reference to hold the content length received
 *					in the header.
 *	@param		pBuffer
 *					Buffer to hold any file data received at the
 *					end of the header.
 *	@param		pBytes
 *					Number of file data bytes written to pBuffer.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 * 29-Mar-2006	Completely redone.  See Init().		Josh Williams	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZFileDownloader::ProcessHeader(long &pLength, QBuffer &pBuffer, long &pBytes)
{
	char		vDataBuf[1025];
	char		vHeader[1024];
	bool		vReceivingHeader = true;
	int			vSize = 1024;
	int			vHeaderLength;
	char		vField[256];
	int			vCode = 0;
	ZRESULT		vResult;

	BEG_FUNC("%p[%d], %p", &pLength, pLength, &pBuffer);

	memset(vHeader, '\0', sizeof(vHeader));

	while (vReceivingHeader)
	{

		ZULU_APP()->processEvents();

		memset(vDataBuf, '\0', sizeof(vDataBuf));
		if ((vResult = mSock.Receive(vDataBuf, vSize, 10)) != ZERR_SUCCESS)
		{
			ZTRACE("Unable to receive header.\n");
			mSock.Close();
			return END_FUNC(vResult);
		}
		vDataBuf[vSize] = 0;

		if (IsCompleteHeader(vDataBuf, vHeaderLength))
		{
			memset(vField, '\0', sizeof(vField));
			strncat(vHeader, vDataBuf, vHeaderLength);
			ZTRACE("--- HEADER ---\n");
			ZTRACE("%s\n", vHeader);
			ZTRACE("--------------\n");
			if (GetResponseCode(vHeader, vCode) == true)
			{
				ZTRACE("Response code => [%d]\n", vCode);
				if (vCode != 200)
				{
					ZTRACE("Received invalid response from server\n");
					return END_FUNC(ZERR_COMM);
				}
			}
			else
			{
				ZTRACE("Unable to find response code in HTTP header\n");
				return END_FUNC(ZERR_COMM);
			}

			if (GetHeaderField(vHeader, "Content-Length", vField) != -1)
			{
				ZTRACE("Conent-Length => [%s]\n", vField);
				pLength = atol(vField);
			}
			else
			{
				ZTRACE("Unable to find Content-Length in header.");
				return END_FUNC(ZERR_COMM);
			}

			ZTRACE("--- HEADER ---\n");
			ZTRACE("%s\n", vHeader);
			ZTRACE("--------------\n");

			/*
			 * Write any remaining bytes received into the file buffer.
			 */
			pBytes = vSize - vHeaderLength;
			if (pBytes)
			{
				if (!pBuffer.isWritable())
				{
					if (!pBuffer.open(IO_WriteOnly))
					{
						ZTRACE("Unable to open the buffer for writing!\n");
						return END_FUNC(ZERR_OPEN_FILE);
					}
				}
				pBuffer.writeBlock(vDataBuf+vHeaderLength, pBytes);
			}
			vReceivingHeader = false;
		}
	}
	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 ReceiveFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Receives the raw file data from the Zoto web server.
 *
 *	@author		Josh Williams
 *	@date		27-Jun-2005
 *
 *	@param		pLength
 *					Total size of the file.
 *	@param		pBytes
 *					Number of file bytes already written to the buffer in
 *					ProcessHeader().
 *	@param		pBuffer
 *					Buffer that contains the first few bytes received
 *					with the HTTP header.
 *	@param		pProgress
 *					Whether we should notify our parent of download progress.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZFileDownloader::ReceiveFile(long pLength, long &pBytes, QBuffer &pBuffer, bool pProgress)
{
	ZRESULT		vRetval;
	char		vBuffer[1024];
	int			vSize = 0;

	BEG_FUNC("%d, %d, %p, %s", pLength, pBytes, &pBuffer, pProgress ? "true" : "false");

	if (!pBuffer.isWritable())
	{
		if (!pBuffer.open(IO_WriteOnly))
		{
			ZTRACE("Unable to open the buffer for writing!\n");
			return END_FUNC(ZERR_OPEN_FILE);
		}
	}

	while (pBytes < pLength)
	{

		ZULU_APP()->processEvents();

		vSize = sizeof(vBuffer);
		memset(vBuffer, '\0', vSize);

		if ((vRetval = mSock.Receive(vBuffer, vSize, 10)) != ZERR_SUCCESS)
		{
			ZTRACE("Unable to receive data\n");
			mSock.Close();
			return END_FUNC(vRetval);
		}
		vBuffer[vSize] = 0;
		ZTRACE("Writing %d bytes to buffer\n", vSize);

		pBuffer.writeBlock(vBuffer, vSize);
		pBytes += vSize;
		StatusUpdate(pProgress, pLength, pBytes);
	}

	pBuffer.close();

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 IsCompleteHeader()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Determines if the full HTTP header has been received
 *				from the server.
 *
 *	@author		Josh Williams
 *	@date		27-Jun-2005
 *
 *	@param		pData
 *					Data buffer received from the socket.
 *	@param		pSize
 *					Number of bytes in pData.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZFileDownloader::IsCompleteHeader(const char *pData, int& pSize)
{
	const char *vPc;

	BEG_FUNC("%p, %p", pData, &pSize);

	if ((vPc = strstr(pData, "\r\n\r\n")) == NULL)
		return END_FUNC(false);
	else
	{
		pSize = vPc - pData + 4;
		ZTRACE("pSize => [%d]\n", pSize);
		return END_FUNC(true);
	}
}

/*------------------------------------------------------------------*
 *							GetResponseCode()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Attempts to extract the HTTP response code from the
 *				HTTP header received from the server.
 *
 *	@author		Josh Williams
 *	@date		27-Jun-2005
 *
 *	@param		pHeader
 *					Buffer that contains the header information received.
 *	@param		pCode
 *					Reference to hold the response code.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 * 29-Mar-2006	See Init().							Josh Williams	*
 *																	*
 *------------------------------------------------------------------*/
bool ZFileDownloader::GetResponseCode(const char *pHeader, int& pCode)
{
	char		vFirstLine[256];
	char		vCode[30];
	char		*vPc;

	BEG_FUNC("%p, %p", pHeader, &pCode);

	vPc = const_cast<char *>(strchr(pHeader, '\r'));
	if (vPc != NULL)
	{
		memset(vFirstLine, '\0', sizeof(vFirstLine));
		strncpy(vFirstLine, pHeader, vPc - pHeader);
		ZTRACE("First line => [%s]\n", vFirstLine);
		vPc = strchr(vFirstLine, ' ');
		if (vPc != NULL)
		{
			while (*vPc == ' ')
				vPc++;
			strcpy(vCode, vPc);
			vPc = strchr(vCode, ' ');
			if (vPc != NULL)
				*vPc = '\0';

			pCode = atoi(vCode);
			return END_FUNC(true);
		}
	}

	return END_FUNC(false);
}

/*------------------------------------------------------------------*
 *							GetHeaderField()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Attempts to extract of a field from the HTTP header.
 *
 *	@author		Josh Williams
 *	@date		27-Jun-2005
 *
 *	@param		pField
 *					Name of the field to retrieve the value for.
 *	@param		pValue
 *					Value returned, if available.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
int ZFileDownloader::GetHeaderField(const char *pHeader, const char *pField, char pValue[])
{
	char vBuffer[1024];

	memset(vBuffer, '\0', sizeof(vBuffer));

	char *vPc = const_cast<char *>(strstr(pHeader, pField));
	if (vPc != NULL)
	{
		strcpy(vBuffer, vPc);
		vPc = strstr(vBuffer, "\r\n");
		if (vPc != NULL)
			*vPc = '\0';
		else
			return -1;

		vPc = strchr(vBuffer, ':');
		if (vPc != NULL)
		{
			vPc++;
			while (*vPc == ' ')
				vPc++;
			memcpy(pValue, vPc, strlen(vPc));
			return strlen(pValue);
		}
		else
			return -1;
	}
	else
		return -1;
}

/*------------------------------------------------------------------*
 *							StatusUpdate()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		If requested, notifies our parent of progress.
 *
 *	@author		Josh Williams
 *	@date		29-Mar-2006
 *
 *	@param		pProgress
 *					Whether or not we should send a progress message.
 *	@param		pLength
 *					Total bytes to be received.
 *	@param		pBytes
 *					Number of bytes recieved thus far.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZFileDownloader::StatusUpdate(bool pProgress, long pLength, long pBytes)
{
	Q_UNUSED(pProgress);
	Q_UNUSED(pLength);
	Q_UNUSED(pBytes);
	/* TODO: Make this do something. */
}

} // End Namespace

/* vi: set ts=4: */
