/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "XRBase64.h"

/* System Headers */
#include <qstring.h>

/* Local Headers */
#include "Types.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */
const int ZXRBase64::MAX_LINE_LENGTH = 76;
const char ZXRBase64::smVec[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const char ZXRBase64::smPadding = '=';

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZXRBase64::ZXRBase64()
{

}

ZXRBase64::~ZXRBase64()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 19-Jan-2006 */
QString ZXRBase64::Encode(const QByteArray &vBinary)
{
	ZUINT		i = 0;
	QString		vResult;
	char		vOneLine[MAX_LINE_LENGTH + 2];
	int			vLength = 0;
	ZBYTE		vB0 = '\0', vB1 = '\0', vB2 = '\0';
	int			vBufSize = 0;

	memset(vOneLine, 0, MAX_LINE_LENGTH + 2);

	for (i = 0; i < vBinary.size(); i += 3)
	{
		vB0 = vBinary[static_cast<int>(i)];
		if (vBinary.size() > i + 2)
		{
			vB1 = vBinary[static_cast<int>(i)+1];
			vB2 = vBinary[static_cast<int>(i)+2];
			vBufSize = 3;
		}
		else if (vBinary.size() > i + 2)
		{
			vB1 = vBinary[static_cast<int>(i)+1];
			vB2 = 0;
			vBufSize = 1;
		}
		vOneLine[vLength++] = smVec[(vB0 & 0xFC) >> 2];
		vOneLine[vLength++] = smVec[((vB0 & 0x03) << 4) | (vB1 >> 4)];
		if (vBufSize > 1)
			vOneLine[vLength++] = smVec[((vB1 & 0x0F) << 2) | (vB2 >> 6)];
		else
			vOneLine[vLength++] = smPadding;

		if (vBufSize > 2)
			vOneLine[vLength++] = smVec[(vB2 & 0x3F)];
		else
			vOneLine[vLength++] = smPadding;

		if ((vLength + 4) > MAX_LINE_LENGTH)
		{
			vOneLine[vLength] = '\n';
			vResult.append(vOneLine);
			memset(vOneLine, 0, MAX_LINE_LENGTH + 2);
			vLength = 0;
		}
	}

	vResult.append(vOneLine);
	return vResult;
}

/* 19-Jan-2006 */
QByteArray ZXRBase64::Decode(QString pAscii)
{
	ZUINT		j;
	int			i;
	ZUINT		vLength = pAscii.length();
	const char	*vData = pAscii.ascii();
	ZUINT		vBinLength = 0;
	ZBYTE		vInBuf[4];
	int			vBufPos = 0;

	QByteArray vResult(((3 * vLength) / 4) + 1);

	memset(vInBuf, 0, 4);

	for (j = 0; j < vLength; j++)
	{
		i = ConvertToNumber(vData[j]);
		if (i >= 0)
		{
			vInBuf[vBufPos++] = (ZBYTE)i;
			if (vBufPos == 4)
			{
				vResult[static_cast<int>(vBinLength++)] = (vInBuf[0] << 2) | (vInBuf[1] >> 4);
				vResult[static_cast<int>(vBinLength++)] = (vInBuf[1] << 4) | (vInBuf[2] >> 2);
				vResult[static_cast<int>(vBinLength++)] = (vInBuf[2] << 6) | (vInBuf[3]);
				vBufPos = 0;
				memset(vInBuf, 0, 4);
			}
		}
	}

	if (vBufPos > 1)
		vResult[static_cast<int>(vBinLength++)] = (vInBuf[0] << 2) | (vInBuf[1] >> 4);

	if (vBufPos > 2)
		vResult[static_cast<int>(vBinLength++)] = (vInBuf[1] << 4) | (vInBuf[2] >> 2);

	vResult.resize(vBinLength);
	return vResult;
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/
int ZXRBase64::ConvertToNumber(char pByte)
{
	if (pByte >= 'A' && pByte <= 'Z')
		return (pByte - 'A');

	if (pByte >= 'a' && pByte <= 'z')
		return (pByte - 'a' + 26);

	if (pByte >= '0' && pByte <= '9')
		return (pByte - '0' + 52);

	if (pByte == '+')
		return (62);

	if (pByte == '/')
		return (63);

	return (-1);
}

} // End Namespace

/* vi: set ts=4: */
