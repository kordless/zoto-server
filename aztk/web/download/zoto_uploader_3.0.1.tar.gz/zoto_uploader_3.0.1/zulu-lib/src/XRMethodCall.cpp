/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "XRMethodCall.h"

/* System Headers */

/* Local Headers */
#include "XRVariant.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZXRMethodCall::ZXRMethodCall()
	: QDomDocument(), mMethod(""), mParams()
{

}

ZXRMethodCall::ZXRMethodCall(const QString &pMethod, const QValueList<QVariant> &pParams)
	: QDomDocument(), mMethod(pMethod), mParams(pParams)
{
	ToDomDoc(mMethod, mParams, *this);
}

ZXRMethodCall::~ZXRMethodCall()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 19-Jan-2006 */
bool ZXRMethodCall::ParseXmlRpc()
{
	return FromDomDoc(*this, mMethod, mParams);
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/* 19-Jan-2006 */
bool ZXRMethodCall::FromDomDoc(const QDomDocument &pDoc, QString &pMethod,
								QValueList<QVariant> &pParams)
{
	pMethod = "";
	pParams.clear();

	QDomNodeList	vNodes;
	QDomElement		vDocElem = pDoc.documentElement();
	QDomNode		vNode;

	if (vDocElem.tagName() != "methodCall")
	{
		return false;
	}

	vNode = vDocElem.firstChild();
	while (!vNode.isNull())
	{
		QDomElement vElem = vNode.toElement();
		if (!vElem.isNull())
		{
			if (vElem.tagName() == "methodName")
			{
				pMethod = vElem.text();
			}
			if (vElem.tagName() == "params")
			{
				QDomNode vParams = vElem.firstChild();
				while (!vParams.isNull())
				{
					QDomElement vParam = vParams.toElement();
					if (vParam.tagName() == "param")
					{
						QDomNode vValue = vParam.firstChild();
						if (vValue.isNull())
							return false;
						else
						{
							QDomElement vValueElem = vValue.toElement();
							pParams.push_back(ZXRVariant(vValueElem));
						}
					}
					vParams = vParams.nextSibling();
				}
			}
		}
		vNode = vNode.nextSibling();
	}
	return true;
}

/* 19-Jan-2006 */
void ZXRMethodCall::ToDomDoc(const QString &pMethod, const QValueList<QVariant> &pParams,
								QDomDocument &pDoc)
{
	QDomElement vRoot = pDoc.createElement("methodCall");
	pDoc.appendChild(vRoot);

	QDomElement vNode = pDoc.createElement("methodName");
	vRoot.appendChild(vNode);
	QDomText vText = pDoc.createTextNode(pMethod);
	vNode.appendChild(vText);

	QDomElement vParams = pDoc.createElement("params");
	vRoot.appendChild(vParams);

	QValueList<QVariant>::const_iterator vIt;


	for (vIt = pParams.constBegin(); vIt != pParams.constEnd(); vIt++)
	{
		QDomElement vParamNode;
		vParamNode = pDoc.createElement("param");
		vParamNode.appendChild(ZXRVariant(*vIt).ToDomElement(pDoc));
		vParams.appendChild(vParamNode);
	}
}

} // End Namespace

/* vi: set ts=4: */
