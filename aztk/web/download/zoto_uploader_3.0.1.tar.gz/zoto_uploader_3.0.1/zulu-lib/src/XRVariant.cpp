/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "XRVariant.h"

/* System Headers */
#include <qdatetime.h>

/* Local Headers */
#include "XRBase64.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZXRVariant::ZXRVariant(const QVariant &pValue)
{
	this->QVariant::operator=(pValue);
}

ZXRVariant::ZXRVariant(QDomElement &pRpcValue)
{
	FromDomElement(pRpcValue);
}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/* 19-Jan-2006 */
bool ZXRVariant::IsRpcType(const QVariant &pValue)
{
	bool vGood = true;

	if ((pValue.type() == QVariant::String) ||
		(pValue.type() == QVariant::Int) ||
		(pValue.type() == QVariant::Bool) ||
		(pValue.type() == QVariant::Double) ||
		(pValue.type() == QVariant::DateTime) ||
		(pValue.type() == QVariant::ByteArray))
	{
		return true;
	}
	else if (pValue.type() == QVariant::List)
	{
		QValueList<QVariant>::const_iterator vIt;
		for (vIt = pValue.toList().constBegin(); vIt != pValue.toList().constEnd(); vIt++)
		{
			vGood = vGood && IsRpcType(*vIt);
		}
		return vGood;
	}
	else if (pValue.type() == QVariant::Map)
	{
		QMap<QString, QVariant>::const_iterator vIt;
		for (vIt = pValue.toMap().constBegin(); vIt != pValue.toMap().constEnd(); vIt++)
		{
			vGood = vGood && IsRpcType(vIt.data());
		}
		return vGood;
	}

	return false;
}

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 19-Jan-2006 */
void ZXRVariant::FromDomElement(QDomElement &pElement)
{
	if (pElement.isNull())
		return;

	if (pElement.tagName() != "value")
		return;

	if (pElement.hasChildNodes())
	{
		QDomNode vNode = pElement.firstChild();
		QDomElement vType = vNode.toElement();
		if (vType.isNull())
		{
			this->QVariant::operator=(QVariant(pElement.text()));
		}

		if ((vType.tagName() == "i4") ||
			(vType.tagName() == "int"))
		{
			this->QVariant::operator=(QVariant(vType.text().toInt()));
		}
		else if (vType.tagName() == "boolean")
		{
			if (vType.text() == "0")
			{
				this->QVariant::operator=(QVariant(false));
			}
			else if (vType.text() == "1")
			{
				this->QVariant::operator=(QVariant(true));
			}
		}
		else if (vType.tagName() == "string")
		{
			this->QVariant::operator=(QVariant(vType.text()));
		}
		else if (vType.tagName() == "double")
		{
			this->QVariant::operator=(QVariant(vType.text().toDouble()));
		}
		else if (vType.tagName() == "dateTime.iso8601")
		{
			QString vTmpDateStr(vType.text());
			vTmpDateStr.insert(4, '-');
			vTmpDateStr.insert(7, '-');
			QVariant vTmpDate(QDateTime::fromString(vTmpDateStr, Qt::ISODate));
			if (vTmpDate.isValid())
			{
				this->QVariant::operator=(vTmpDate);
			}
		}
		else if (vType.tagName() == "base64")
		{
			this->QVariant::operator=(QVariant(ZXRBase64::Decode(vType.text())));
		}
		else if (vType.tagName() == "array")
		{
			this->operator=(ArrayFromDomElement(vType));
		}
		else if (vType.tagName() == "struct")
		{
			this->operator=(StructFromDomElement(vType));
		}
	}
}

/* 19-Jan-2006 */
QDomElement ZXRVariant::ToDomElement(QDomDocument &pDoc)
{
	QDomElement vRetElem = pDoc.createElement("value");
	QDomElement vTypeElem;
	QDomText	vText;

	QVariant::Type vThisType = type();
	if (vThisType == QVariant::String)
	{
		vTypeElem = pDoc.createElement("string");
		vText = pDoc.createTextNode(toString());
		vTypeElem.appendChild(vText);
	}
	else if ((vThisType == QVariant::Int) ||
			 (vThisType == QVariant::UInt))
	{
		vTypeElem = pDoc.createElement("int");
		vText = pDoc.createTextNode(toString());
		vTypeElem.appendChild(vText);
	}
	else if (vThisType == QVariant::Bool)
	{
		vTypeElem = pDoc.createElement("boolean");
		if (toBool())
			vText = pDoc.createTextNode("1");
		else
			vText = pDoc.createTextNode("0");
		vTypeElem.appendChild(vText);
	}
	else if (vThisType == QVariant::Double)
	{
		vTypeElem = pDoc.createElement("double");
		vText = pDoc.createTextNode(toString());
		vTypeElem.appendChild(vText);
	}
	else if (vThisType == QVariant::DateTime)
	{
		vTypeElem = pDoc.createElement("dateTime.iso8601");
		QString vTmpDateStr(toDateTime().toString("yyyyMMddThh::mm::ss"));
		vText = pDoc.createTextNode(vTmpDateStr);
		vTypeElem.appendChild(vText);
	}
	else if (vThisType == QVariant::Date)
	{
		vTypeElem = pDoc.createElement("dateTime.iso8601");
		QDateTime vTmpDate(toDate(), QTime(0, 0));
		QString vTmpDateStr(vTmpDate.toString("yyyyMMddThh::mm::ss"));
		vText = pDoc.createTextNode(vTmpDateStr);
		vTypeElem.appendChild(vText);
	}
	else if (vThisType == QVariant::ByteArray)
	{
		vTypeElem = pDoc.createElement("base64");
		vText = pDoc.createTextNode(ZXRBase64::Encode(toByteArray()));
		vTypeElem.appendChild(vText);
	}
	else if ((vThisType == QVariant::List) ||
			 (vThisType == QVariant::StringList))
	{
		vTypeElem = pDoc.createElement("array");
		QDomElement vDataElem = pDoc.createElement("data");
		vTypeElem.appendChild(vDataElem);
		QValueList<QVariant>::const_iterator vIt;
		for (vIt = toList().constBegin(); vIt != toList().constEnd(); vIt++)
		{
			vDataElem.appendChild(ZXRVariant(*vIt).ToDomElement(pDoc));
		}
	}
	else if (vThisType == QVariant::Map)
	{
		vTypeElem = pDoc.createElement("struct");
		QMap<QString, QVariant>::const_iterator vIt;
		for (vIt = toMap().constBegin(); vIt != toMap().constEnd(); vIt++)
		{
			QDomElement vMemElem = pDoc.createElement("member");
			QDomElement vNameElem = pDoc.createElement("name");
			vText = pDoc.createTextNode(vIt.key());
			vNameElem.appendChild(vText);
			vMemElem.appendChild(vNameElem);
			vMemElem.appendChild(ZXRVariant(vIt.data()).ToDomElement(pDoc));
			vTypeElem.appendChild(vMemElem);
		}
	}
	else if (canCast(QVariant::String))
	{
		vTypeElem = pDoc.createElement("string");
		vText = pDoc.createTextNode(toString());
		vTypeElem.appendChild(vText);
	}
	else
	{
		vTypeElem = pDoc.createElement("string");
		vText = pDoc.createTextNode("");
		vTypeElem.appendChild(vText);
	}

	vRetElem.appendChild(vTypeElem);
	return vRetElem;
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/* 19-Jan-2006 */
ZXRVariant ZXRVariant::ArrayFromDomElement(QDomElement &pElement)
{
	bool		vFailed = false;
	QDomNode	vNode = pElement.firstChild();
	QDomElement vElem = vNode.toElement();

	if (vElem.tagName() == "data")
	{
		vNode = vElem.firstChild();
		QValueList<QVariant>	vTmpList;
		while ((!vNode.isNull()) && (vFailed == false))
		{
			QDomElement vNewElem = vNode.toElement();
			ZXRVariant vTmpVar(vNewElem);
			if (vTmpVar.typeName() == 0)
			{
				vFailed = true;
			}
			else
			{
				vTmpList.push_back(vTmpVar);
			}
			vNode = vNode.nextSibling();
		}
		if (vFailed == false)
		{
			return QVariant(vTmpList);
		}
	}
	return QVariant();
}

/* 19-Jan-2006 */
ZXRVariant ZXRVariant::StructFromDomElement(QDomElement &pElement)
{
	QMap<QString, QVariant> vTmpMap;
	bool		vFailed = false;
	QDomNode	vNode = pElement.firstChild();

	while ((!vNode.isNull()) && (vFailed == false))
	{
		QDomElement vElem = vNode.toElement();
		if (vElem.tagName() == "member")
		{
			bool vHaveName = false, vHaveValue = false;
			QDomNode vOneNode = vElem.firstChild();
			QString vMemName;
			QVariant vMemValue;
			while (!vOneNode.isNull())
			{
				QDomElement vMemElem = vOneNode.toElement();
				if (vMemElem.tagName() == "name")
				{
					vHaveName = true;
					vMemName = vMemElem.text();
				}
				else if (vMemElem.tagName() == "value")
				{
					vHaveValue = true;
					vMemValue = ZXRVariant(vMemElem);
				}
				if (vHaveName && vHaveValue)
				{
					vTmpMap.insert(vMemName, vMemValue);
					vHaveName = vHaveValue = false;
				}
				vOneNode = vOneNode.nextSibling();
			}
		}
		vNode = vNode.nextSibling();
	}

	return QVariant(vTmpMap);
}

} // End Namespace

/* vi: set ts=4: */
