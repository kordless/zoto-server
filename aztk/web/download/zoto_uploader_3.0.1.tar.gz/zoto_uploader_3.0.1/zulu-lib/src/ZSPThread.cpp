/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "ZSPThread.h"

/* System Headers */

/* Local Headers */
#include "Events.h"
#include "App.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZZSPThread::ZZSPThread(QWidget *pParent, ZClient *pClient)
	: QThread(0), mUser(""), mPswdHash(""), mDisconnect(true), mParent(pParent),
		mAction(ZSP_VERSION), mClient(pClient)
{	

}

ZZSPThread::~ZZSPThread()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							ProcessUser()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Sets up the thread for making a ZSP call for
 *				authenticating a user.
 *
 *	@author		Josh Williams
 *	@date		21-Mar-2006
 *
 *	@param		pUser
 *					Username to be authenticated.
 *	@param		pPswdHash
 *					Password hash being authenticated.
 *	@param		pDisconnect
 *					Whether or not we should disconnect when
 *					the authentication process is complete.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZSPThread::ProcessUser(const QString &pUser, const QString &pPswdHash,
				bool pDisconnect /*=true*/)
{
	mUser = pUser;
	mPswdHash = pPswdHash;
	mDisconnect = pDisconnect;
	mAction = ZSP_AUTH;
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *								  run()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Thread processing function.  Either validates
 *				version or authenticates based on mAction member
 *				variable.
 *
 *	@author		Josh Williams
 *	@date		21-Mar-2006
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZZSPThread::run()
{
	QString		 vRespText;
	ZStatusEvent *vEvt = new ZStatusEvent();

	if (mAction == ZSP_VERSION)
		vEvt->mType = ZStatusEvent::VERSION;
	else if (mAction == ZSP_AUTH)
		vEvt->mType = ZStatusEvent::AUTH;

	/*
	 * Establish a connection to the Zoto server
	 */
	if ((mClient->ConnectServer()) != ZERR_SUCCESS)
	{
		mClient->Disconnect();
		vEvt->mErrcode = ZERR_CONNECT;
		QApplication::postEvent(mParent, vEvt);
		exit();
	}

	if (mAction == ZSP_VERSION)
	{
		vEvt->mErrcode = mClient->CheckVersion(vRespText);
		vEvt->setData(new QString(vRespText));
	}
	else
		vEvt->mErrcode = mClient->Authenticate(mUser, mPswdHash);

	if (mDisconnect)
		mClient->Disconnect();

	QApplication::postEvent(mParent, vEvt);

	exit();
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
