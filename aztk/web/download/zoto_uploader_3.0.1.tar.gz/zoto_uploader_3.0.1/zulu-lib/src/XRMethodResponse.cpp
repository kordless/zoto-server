/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "XRMethodResponse.h"

/* System Headers */

/* Local Headers */
#include "XRVariant.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZXRMethodResponse::ZXRMethodResponse()
	: QDomDocument(), mIsFault(false), mFaultCode(0), mFaultString(""), mResponse()
{

}

ZXRMethodResponse::ZXRMethodResponse(const QVariant &pResponse)
	: QDomDocument(), mIsFault(false), mFaultCode(0), mFaultString(""), mResponse(pResponse)
{
	ResponseToDomDoc(mResponse, *this);
}

ZXRMethodResponse::ZXRMethodResponse(int pFaultCode, const QString &pFaultString)
	: QDomDocument(), mIsFault(true), mFaultCode(pFaultCode), mFaultString(pFaultString),
		mResponse()
{
	FaultToDomDoc(mFaultCode, mFaultString, *this);
}

ZXRMethodResponse::~ZXRMethodResponse()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/* 19-Jan-2006 */
bool ZXRMethodResponse::GetFault(int &pFaultCode, QString &pFaultString) const
{
	if (mIsFault)
	{
		pFaultCode = mFaultCode;
		pFaultString = mFaultString;
		return true;
	}
	else
		return false;
}

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 19-Jan-2006 */
bool ZXRMethodResponse::ParseXmlRpc()
{
	bool vResult = FromDomDoc(*this, mResponse, mIsFault);
	if (mIsFault)
	{
		QMap<QString, QVariant>	vMap = mResponse.toMap();
		QMap<QString, QVariant>::const_iterator vIt;
		vIt = vMap.find("faultCode");
		mFaultCode = vIt.data().toInt();

		vIt = vMap.find("faultString");
		mFaultString = vIt.data().toString();
		mResponse.clear();
	}

	return vResult;
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/* 19-Jan-2006 */
void ZXRMethodResponse::FaultToDomDoc(int pFaultCode, const QString &pFaultString,
										QDomDocument &pDoc)
{
	QDomElement vRoot = pDoc.createElement("methodResponse");
	pDoc.appendChild(vRoot);

	QDomElement vFault = pDoc.createElement("fault");
	vRoot.appendChild(vFault);

	QMap<QString, QVariant> vFaultMap;

	vFaultMap.insert("faultCode", QVariant(pFaultCode));
	vFaultMap.insert("faultString", QVariant(pFaultString));

	vFault.appendChild(ZXRVariant(vFaultMap).ToDomElement(pDoc));
}

/* 19-Jan-2006 */
bool ZXRMethodResponse::FromDomDoc(const QDomDocument &pDoc, QVariant &pResponse, bool &pIsFault)
{
	QDomNodeList	vNodes;
	QDomElement		vDocElem = pDoc.documentElement();

	if (vDocElem.tagName() != "methodResponse")
	{
		qDebug("%s::cannot find methodResponse", __FILE__);
		return false;
	}

	QDomNode vNode = vDocElem.firstChild();

	while (!vNode.isNull())
	{
		QDomElement vElem = vNode.toElement();
		if (!vElem.isNull())
		{
			if (vElem.tagName() == "fault")
			{
				QDomNode	vFaultValue = vElem.firstChild();
				QDomElement	vFaultElem = vFaultValue.toElement();
				ZXRVariant	vFault(vFaultElem);
				if (vFault.type() == QVariant::Map)
				{
					if ((vFault.toMap().find("faultCode") != vFault.toMap().end()) &&
						(vFault.toMap().find("faultString") != vFault.toMap().end()))
					{
						pIsFault = true;
						pResponse = vFault;
						return true;
					}
				}
				else
				{
					qDebug("Cannot find fault map");
					return false;
				}
			}

			if (vElem.tagName() == "params")
			{
				QDomNode vParams = vElem.firstChild();
				if (!vParams.isNull())
				{
					QDomElement vParam = vParams.toElement();
					if (vParam.tagName() == "param")
					{
						QDomNode vValue = vParam.firstChild();
						if (vValue.isNull())
						{
							qDebug("Null value");
							return false;
						}
						else
						{
							QDomElement vValueElem = vValue.toElement();
							pResponse = ZXRVariant(vValueElem);
						}
					}
				}
				else
				{
					qDebug("params are null");
					return false;
				}
			}
		}

		vNode = vNode.nextSibling();
	}

	return true;
}

/* 19-Jan-2006 */
void ZXRMethodResponse::ResponseToDomDoc(const QVariant &pResponse, QDomDocument &pDoc)
{
	QDomElement vRoot = pDoc.createElement("methodResponse");
	pDoc.appendChild(vRoot);

	QDomElement vParamsXml = pDoc.createElement("params");
	vRoot.appendChild(vParamsXml);

	QDomElement vParamNode = pDoc.createElement("param");
	vParamNode.appendChild(ZXRVariant(pResponse).ToDomElement(pDoc));
	vParamsXml.appendChild(vParamNode);
}

} // End Namespace

/* vi: set ts=4: */
