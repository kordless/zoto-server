/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 * 17-Jun-2005	Added auto-private logic.						Josh Williams *
 *                                                                            *
 *============================================================================*/
#include "App.h"

/* System Headers */
#include <qmutex.h>
#include <qimage.h>
#include <fstream>
#include <time.h>
#if ZULU_PLATFORM == PLATFORM_WINDOWS
#include <windows.h>
#include <shellapi.h>
#include <process.h>
#endif

/* Local Headers */
#include "MD5Hasher.h"
#include "Types.h"
#include "Events.h"
#include "Log.h"
#include "Utils.h"

namespace ZOTO
{

DECLARE_CLASS( "ZApp" )

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZApp::ZApp(int& argc, char **argv)
	: QApplication(argc, argv), ZObject(), mVersMaj(ZOTO_VERS_MAJ), mVersMin(ZOTO_VERS_MIN),
		mVersBuild(ZOTO_VERS_BUILD), mVersString(ZOTO_VERS_STRING), mZspHost(""), mZspPort(0),
		mZapiHost(""), mZapiPort(0), mZapiPath(""), mCurrentUser(-1),
		mAppName(APP_NAME), mTracing(false)
{
	QSettings	vConfig;
	QString		vCurrentUser;

	SetConfigPath(vConfig);

	/*
	 * Grab the config values from the file/registry
	 */
	mDomain		= vConfig.readEntry(BuildConfigPath("/Domain"), ZOTO_DOMAIN);

	mZspHost	= vConfig.readEntry(BuildConfigPath("/ZSP/ZspHost"), ZSP_HOST);
	mZspPort	= vConfig.readNumEntry(BuildConfigPath("/ZSP/ZspPort"), ZSP_PORT);

	mZapiHost	= vConfig.readEntry(BuildConfigPath("/ZAPI/ZapiHost"), ZAPI_HOST);
	mZapiPort	= vConfig.readNumEntry(BuildConfigPath("/ZAPI/ZapiPort"), ZAPI_PORT);
	mZapiPath	= vConfig.readEntry(BuildConfigPath("/ZAPI/ZapiPath"), ZAPI_PATH);

	mTracing	= vConfig.readBoolEntry(BuildConfigPath("/Tracing"), false);
	vCurrentUser = vConfig.readEntry(BuildConfigPath("/CurrentUser"), "");
	LoadUsers(vConfig, vCurrentUser);

	if (mTracing)
	{
		ZLog::GetLog().InitTrace(qApp->applicationFilePath().latin1());
	}
	qInstallMsgHandler(TraceHandler);
}

ZApp::~ZApp()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							 Initialize()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Handles loading application configuration and
 *               initializing the ZSP client code.
 *
 *	@author		Josh Williams
 *	@date		22-Mar-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZApp::Initialize()
{
	BEG_FUNC(NULL);

	return END_FUNC(true);
}

/*------------------------------------------------------------------*
 *								Shutdown()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Kills the client connection.
 *
 *	@author		Josh Williams
 *	@date		22-Mar-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZApp::Shutdown()
{
	BEG_FUNC(NULL);

	END_FUNCV();
}

/*------------------------------------------------------------------*
 *							   LoadUser()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Loads a user's info from the resident user map.  If
 *				no user exists with the specified username, a new one
 *				is added to the map.
 *
 *	@author		Josh Williams
 *	@date		23-Mar-2006
 *
 *	@param		pUserName
 *					Username being loaded.
 *	@param 		pInfo
 *					Pointer to ZUserInfo class that will hold the
 *					retrieved user information.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
bool ZApp::LoadUser(const QString &pUserName, ZUserInfo **pInfo)
{
	QIntDictIterator<ZUserInfo>	vIt(mUserMap);

	BEG_FUNC("%s, %p", pUserName.latin1(), pInfo);

	/*
	 * See if this user already exists in the map.
	 */
	for ( ; vIt.current(); ++vIt)
	{
		if (vIt.current()->mUserName == pUserName)
		{
			*pInfo = vIt.current();
			return END_FUNC(true);
		}
	}

	/*
	 * no existing user found...set some defaults.
	 */
	*pInfo = new ZUserInfo();
	(*pInfo)->mUserName = pUserName;
	SaveUser(*pInfo);

	return END_FUNC(false);
}	

/*------------------------------------------------------------------*
 *							   SaveUser()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Saves this user's info in the list of valid Zoto users.
 *
 *	@author		Josh Williams
 *	@date		30-Dec-2005
 *
 *	@param		pUser
 *					User info to be stored.
 *
 *	@remarks	Also stores the user's information in the registry.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
short ZApp::SaveUser(ZUserInfo *pUser)
{
	int					vSize;
	QIntDictIterator<ZUserInfo> vIt(mUserMap);
	int					vIndex;
	QSettings			vConfig;
	QString				vPath;

	BEG_FUNC("%p", pUser);

	vSize = mUserMap.size();
	vIndex = vSize;
	vPath = "/Users/" + pUser->mUserName;

	SetConfigPath(vConfig);

	/*
	 * Check to see if this user already exists in the map.
	 */
	for ( ; vIt.current(); ++vIt)
	{
		if (vIt.current()->mUserName == pUser->mUserName)
		{
			vIndex = vIt.currentKey();
			mUserMap[vIndex]->mPswdHash = pUser->mPswdHash;
			mUserMap[vIndex]->mAuto = pUser->mAuto;
			mUserMap[vIndex]->mRemember = pUser->mRemember;
			mUserMap[vIndex]->mPrivate = pUser->mPrivate;
			mUserMap[vIndex]->mTagging = pUser->mTagging;
			mUserMap[vIndex]->mGalleries = pUser->mGalleries;
			mUserMap[vIndex]->mQuota = pUser->mQuota;
			mUserMap[vIndex]->mUsage = pUser->mUsage;
			mUserMap[vIndex]->mType = pUser->mType;
			mUserMap[vIndex]->mTags = pUser->mTags;
			mUserMap[vIndex]->mGalleryMap = pUser->mGalleryMap;
		}
	}

	/*
	 * If this is a new user, store them in the map.
	 */
	if (vIndex == vSize)
		mUserMap.insert(vIndex, pUser);

	vConfig.writeEntry(BuildConfigPath(vPath + "/UserHash"), pUser->mUserHash);
	vConfig.writeEntry(BuildConfigPath(vPath + "/PswdHash"), pUser->mPswdHash);
	vConfig.writeEntry(BuildConfigPath(vPath + "/AutoLogin"), pUser->mAuto);
	vConfig.writeEntry(BuildConfigPath(vPath + "/AutoPrivate"), pUser->mPrivate);
	vConfig.writeEntry(BuildConfigPath(vPath + "/Tagging"), pUser->mTagging);
	vConfig.writeEntry(BuildConfigPath(vPath + "/Galleries"), pUser->mGalleries);
	vConfig.writeEntry(BuildConfigPath(vPath + "/Remember"), pUser->mRemember);

	return END_FUNC(vIndex);
}

/*------------------------------------------------------------------*
 *							BuildConfigPath()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Builds the application specific config path (registry,
 *				.ini, etc)
 *	@author		Josh Williams
 *	@date		16-May-2005
 *
 *	@param		pSetting
 *					Setting we're trying to query.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
const QString ZApp::BuildConfigPath(const QString &pSetting) const
{
	BEG_FUNC("%p", &pSetting);
	QString vPath;
#if ZULU_PLATFORM == PLATFORM_WINDOWS || ZULU_PLATFORM == PLATFORM_MAC
	vPath = pSetting;
#elif ZULU_PLATFORM == PLATFORM_LINUX
	vPath = GetAppName().replace(" ", "_") + pSetting;
#else
#error Unsupported Platform
#endif
	return END_FUNC(vPath);
}

/*------------------------------------------------------------------*
 *							 SetConfigPath()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Sets the path for reading values from within the
 *				registry, file.
 *	@author		Josh Williams
 *	@date		05-Aug-2005
 *
 *	@param		pSettings
 *					QSettings object.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZApp::SetConfigPath(QSettings &pSettings) const
{
	BEG_FUNC("%p", &pSettings);

	/*
	 * Set the path to the application configuration file/key.
	 */
#if ZULU_PLATFORM == PLATFORM_WINDOWS || ZULU_PLATFORM == PLATFORM_MAC
	pSettings.setPath("Zoto.com", GetAppName(), QSettings::User);
#elif ZULU_PLATFORM == PLATFORM_LINUX
	pSettings.setPath("Zoto.com", GetAppName().replace(" ", "_"), QSettings::User);
#else
#error Unsupported platform!
#endif

	END_FUNCV();
}

/*------------------------------------------------------------------*
 *							IsSupportedImage()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Quick and dirty function to determine if a given URI
 *				points to a supported image or not.
 *
 *	@author		Josh Williams
 *	@date		02-Apr-2005
 *
 * 	@param		pPath
 * 					URI of the file in question.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
bool ZApp::IsSupportedImage(const QString &pPath)
{
	const char *vFormat;

	BEG_FUNC("%p[%s]", &pPath, pPath.latin1());
	
	vFormat = QImage::imageFormat(pPath);
	QStringList vFormats;

	if (vFormat == NULL)
		return END_FUNC(false);

	/*
	 * Get the list of Qt supported formats.
	 */
	vFormats = QImage::inputFormatList();

	QStringList::Iterator vIt = vFormats.begin();
    while (vIt != vFormats.end())
	{
		if ((*vIt).compare(vFormat) == 0)
			return END_FUNC(true);
		vIt++;
    }

	return END_FUNC(false);
}

/*------------------------------------------------------------------*
 *								MakeURL()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates a url from the criteria specified.
 *
 *	@author		Josh Williams
 *	@date		17-Apr-2006
 *
 * 	@param		pBase
 * 					Base URL to start from.
 * 	@param		pUser
 * 					Username for string replacement
 * 	@param		pGallery
 * 					Gallery name for string replacement
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS:                                                   *
 *  Date        Description                         Author          *
 *============  ==================================  =============== *
 *                                                                  *
 *------------------------------------------------------------------*/
QString ZApp::MakeURL(const QString &pBase, const QString &pUser /*=""*/,
							const QString &pGallery /*=""*/)
{
	QString vString = pBase;

	vString.replace("$DOMAIN$", ZULU_APP()->GetDomain());
	vString.replace("$USER$", pUser);
	vString.replace("$GALLERY$", pGallery);

	return vString;
}

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							TraceHandler()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Handles qDebug messages.
 *	@author		Josh Williams
 *	@date		05-May-2005
 *
 *	@param		pType
 *					Message type (debug, warning, etc)
 *	@param		pMsg
 *					Actual message to be output.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZApp::TraceHandler(QtMsgType pType, const char *pMsg)
{
#ifdef ZOTO_TRACE_ENABLE
	static bool				vFirstTime = true;
	static std::ofstream	vFile;
	static QMutex			vLogMutex;
	static char				vFileName[256];
	static char				*vPtr = NULL;
	static time_t			vNow = time(NULL);
	static bool				vFileOpen = false;

	if (!ZULU_APP()->TraceEnabled())
		return;
	
	vLogMutex.lock();

	if (vFirstTime)
	{
		strncpy(vFileName, qApp->applicationFilePath().latin1(), sizeof(vFileName));
		if ((vPtr = strstr(vFileName, ".exe")) != NULL)
		{	/* found the .exe extension.  replace it with .log */
			strftime(vPtr, sizeof(vFileName) - strlen(vFileName), "-gui_%m%d%Y_%H%M%S.log", localtime(&vNow));
		}
		else
		{	/* probably linux/mac.  just add .log */
			strftime(&vFileName[strlen(vFileName)], sizeof(vFileName) - strlen(vFileName),
					"-gui_%m%d%Y_%H%M%S.log", localtime(&vNow));
		}
		vFile.open(vFileName);
		if (vFile.good())
			vFileOpen = true;
		vFirstTime = false;
	}

	if (vFileOpen)
	{
		switch ( pType )
		{
		case QtDebugMsg:
			vFile << "Debug: " << pMsg << std::endl;
			break;
		case QtWarningMsg:
			vFile << "Warning: " << pMsg << std::endl;
			break;
		case QtFatalMsg:
			vFile << "Fatal: " << pMsg << std::endl;
			abort();                    // deliberately core dump
		}
	}

	vLogMutex.unlock();
#endif // ZOTO_TRACE_ENABLE
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							 SetConfigPath()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Retrieves the list of available usernames from the
 *				registry/file.
 *	@author		Josh Williams
 *	@date		29-Dec-2005
 *
 *	@param		pSettings
 *					QSettings object.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZApp::LoadUsers(QSettings &pSettings, const QString &pCurrentUser)
{
	ZUSHORT vCount = 0;
	QStringList::Iterator vIt;
	QStringList	vUsers;
	ZUserInfo	*vUser;
	QString		vPath;

	BEG_FUNC("%p, %s", &pSettings, pCurrentUser.latin1());

	/*
	 * Iterate over the list of user keys, adding an entry to
	 * the map for each one.
	 */
	vUsers = pSettings.subkeyList(BuildConfigPath("/Users"));

	for (vIt = vUsers.begin(); vIt != vUsers.end(); ++vIt)
	{
		vUser = new ZUserInfo();
		vUser->mUserName = *vIt;
		if (vUser->mUserName.lower().compare(pCurrentUser) == 0)
			mCurrentUser = vCount;
		vPath = "/Users/" + *vIt;
		vUser->mUserHash = pSettings.readEntry(BuildConfigPath(vPath + "/UserHash"), "");
		vUser->mPswdHash = pSettings.readEntry(BuildConfigPath(vPath + "/PswdHash"), "");
		vUser->mPrivate = pSettings.readBoolEntry(BuildConfigPath(vPath + "/AutoPrivate"), false);
		vUser->mTagging = pSettings.readBoolEntry(BuildConfigPath(vPath + "/Tagging"), true);
		vUser->mGalleries = pSettings.readBoolEntry(BuildConfigPath(vPath + "/Galleries"), false);
		vUser->mRemember = pSettings.readBoolEntry(BuildConfigPath(vPath + "/Remember"), true);
		vUser->mAuto	= pSettings.readBoolEntry(BuildConfigPath(vPath + "/AutoLogin"), false);
		mUserMap.insert(vCount++, vUser);
	}

	END_FUNCV();
}

} // End Namespace
