/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004 Zoto, Inc.  123 South Hudson, OKC, OK  73102			  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "XRClient.h"

/* System Headers */
#include <qbuffer.h>
#include <qtextstream.h>
#include <qtextcodec.h>

/* Local Headers */
#include "XRMethodCall.h"
#include "XRMethodResponse.h"
#include "Socket.h"

/* Macros */

namespace ZOTO
{

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZXRClient::ZXRClient(const QString &pServer, const QString &pPath, ZUSHORT pPort)
	: mHost(pServer), mPath(pPath)
{
	mIsDeflated = false;
	mAcceptCompressed = true;
	char vAddr[50];

	memset(vAddr, 50, '\0');

	ZSocket::GetIPbyName(mHost.latin1(), vAddr, sizeof(vAddr));

	qDebug("Opening xmlrpc connection to %s[%s]:%d", mHost.latin1(), vAddr, pPort);
	mConn.setHost(vAddr, pPort);

	connect(&mConn, SIGNAL(responseHeaderReceived(const QHttpResponseHeader &)),
			this, SLOT(ProcessHeaders(const QHttpResponseHeader &)));
	connect(&mConn, SIGNAL(requestFinished(int, bool)),
			this, SLOT(ProcessResponse(int, bool)));
}

ZXRClient::~ZXRClient()
{
	qDebug("####### XRClient DESTRUCTOR #######");
	mConn.abort();

	QMap<int, QBuffer*>::iterator vIt;

	for (vIt = mBufferMap.begin(); vIt != mBufferMap.end(); vIt++)
	{
		delete vIt.data();
	}
}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/* 23-Jan-2006 */
int ZXRClient::Call(const QString &pMethod, const QValueList<QVariant> &pParams)
{
	QByteArray		vPayload;
	int				vReqNum;
	ZXRMethodCall	vCall(pMethod, pParams);
	QTextStream		vPayloadStream(vPayload, IO_WriteOnly);

	vPayloadStream.setCodec(QTextCodec::codecForName("UTF8"));

	vCall.save(vPayloadStream, 0);

	QHttpRequestHeader vReqHeader("POST", mPath);
	vReqHeader.setValue("Host", mHost);
	vReqHeader.setValue("User-Agent", "Zoto Client Library");
	vReqHeader.setContentLength(vPayload.size());
	vReqHeader.setContentType("text/xml");
	if (mAcceptCompressed)
		vReqHeader.setValue("Accept-Encoding", "deflate");

	QBuffer *vBuffer = new QBuffer();
	vReqNum = mConn.request(vReqHeader, vPayload, vBuffer);
	qDebug("Made a call with id %d", vReqNum);
	mBufferMap.insert(vReqNum, vBuffer);

	return vReqNum;
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/* 23-Jan-2006 */
void ZXRClient::ProcessHeaders(const QHttpResponseHeader &pHeader)
{
	mIsDeflated = false;

	qDebug("Headers came in");
	if (pHeader.hasKey("Content-Encoding"))
	{
		if (pHeader.value("Content-Encoding") == "deflate")
			mIsDeflated = true;
	}
}

/* 23-Jan-2006 */
void ZXRClient::ProcessResponse(int pHttpResp, bool pError)
{
	qDebug("Processing response for id %d -> %s", pHttpResp, pError ? "true" : "false");
	if (pError)
	{
		qDebug("HTTP processing failed.  Emitting Fault()");
		emit Fault(pHttpResp, XR_TRANSPORT_ERROR, mConn.errorString());
		return;
	}

	if (mBufferMap.contains(pHttpResp))
	{
		qDebug("Valid http response value");
		ZXRMethodResponse vResponse;
		QString vErrString;
		bool vSuccess;

		if (mIsDeflated)
			vSuccess = vResponse.setContent(qUncompress(mBufferMap[pHttpResp]->buffer()), &vErrString);
		else
			vSuccess = vResponse.setContent(mBufferMap[pHttpResp]->buffer(), &vErrString);

		if (!vSuccess)
		{
			qDebug("Unable to set content.  Emitting Fault()");
			emit Fault(pHttpResp, XR_PARSE_ERROR_NOT_WELL_FORMED, vErrString);
			return;
		}

		if (vResponse.ParseXmlRpc())
		{
			qDebug("Response parsed");
			int vFaultCode;
			QString vFaultString;
			if (vResponse.GetFault(vFaultCode, vFaultString))
			{
				qDebug("%d -> %s", vFaultCode, vFaultString.latin1());
				qDebug("Received fault from server.  Emitting Fault()");
				emit Fault(pHttpResp, vFaultCode, vFaultString);
			}
			else
			{
				qDebug("Received valid response.  Emitting Response()");
				emit Response(pHttpResp, vResponse.GetResponse());
			}
		}
		else
		{
			qDebug("Unable to parse response.  Emitting Fault()");
			emit Fault(pHttpResp, XR_SERVER_ERROR_INVALID_XMLRPC, "Server error: Received bad XML-RPC grammar from remote server");
			return;
		}
	}

	if (mBufferMap.contains(pHttpResp))
	{
		delete mBufferMap[pHttpResp];
		mBufferMap.remove(pHttpResp);
	}
}

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
