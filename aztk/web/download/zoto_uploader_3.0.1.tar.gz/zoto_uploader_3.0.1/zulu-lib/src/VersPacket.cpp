/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "VersPacket.h"

/* System Headers */

/* System Headers */
#include <cstring>
#if ZULU_PLATFORM == PLATFORM_WINDOWS
#include <winsock2.h>
#elif ZULU_PLATFORM == PLATFORM_MAC
#include <netinet/in.h>
#elif ZULU_PLATFORM == PLATFORM_LINUX
#include <netinet/in.h>
#else
#error "Unsupported platform"
#endif

/* Local Headers */

/* Macros */

namespace ZOTO
{

DECLARE_CLASS( "ZVersPacket" )

/* Static Variables */

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZVersPacket::ZVersPacket()
	: ZPacket(ZSP_VERSION), mVersMaj(0), mVersMin(0), mVersBuild(0), mVersString("")
{

}

ZVersPacket::ZVersPacket(ZUSHORT pVersMaj, ZUSHORT pVersMin, ZUSHORT pVersBuild, const char *pString)
	: ZPacket(ZSP_VERSION), mVersMaj(pVersMaj), mVersMin(pVersMin), mVersBuild(pVersBuild),
		mVersString(pString)
{

}

ZVersPacket::~ZVersPacket()
{

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							SetVersString()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Sets the string to be appended to the version.
 *
 *	@author		Josh Williams
 *	@date		29-Sep-2006
 *
 *	@remarks	Adds an extra string, such as "a" or "rc0" to the end
 *				of the version (ex: "3.0.0a")
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZVersPacket::SetVersString(const char *pString)
{
	if (pString)
		mVersString = pString;
}


/*------------------------------------------------------------------*
 *								Build()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Builds a properly formatted version packet.
 *
 *	@author		Josh Williams
 *	@date		12-Apr-2005
 *
 *	@remarks	Function assumes that the major, minor and build
 *				values have already been Set().
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZVersPacket::Build()
{
	BEG_FUNC("");

	ZSP_VERSION_PACKET	*vVers;

	/*
	 * Build the outgoing VERSION packet
	 */
	mPacketLen  = VERSION_SIZE + mVersString.length();
	vVers = reinterpret_cast<ZSP_VERSION_PACKET *>(BuildHeader());
	vVers->vers_maj		= htons(mVersMaj);
	vVers->vers_min		= htons(mVersMin);
	vVers->vers_build	= htons(mVersBuild);
	memcpy(&mRaw[VERSION_SIZE], mVersString.c_str(), mVersString.length());

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *								Parse()								*
 *------------------------------------------------------------------*/
/**
 *	@brief		Attempts to convert a raw string received into a
 *				a properly formatted version packet.
 *
 *	@author		Josh Williams
 *	@date		12-Apr-2005
 *
 *	@param		pRaw
 *					The raw bytes received.
 *	@param		pSize
 *					Number of bytes received.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZVersPacket::Parse(ZBYTE *pRaw, ZUINT &pSize)
{
	BEG_FUNC("%p, %d", pRaw, pSize);

	ZSP_VERSION_PACKET	*vVers;
	ZUINT				vStringLen;
	ZRESULT				vRetval;

	vRetval = ExtractPacket(pRaw, pSize);
	if (vRetval != ZERR_SUCCESS)
		return END_FUNC(vRetval);

	vVers		= reinterpret_cast<ZSP_VERSION_PACKET*>(mRaw);
	vStringLen	= mPacketLen - VERSION_SIZE;

	char *vBuffer = new char[vStringLen+1];

	/*
	 * Populate the variables.
	 */
	mVersMaj	= ntohs(vVers->vers_maj);
	mVersMin	= ntohs(vVers->vers_min);
	mVersBuild	= ntohs(vVers->vers_build);
	memcpy(vBuffer, &mRaw[VERSION_SIZE], vStringLen);
	vBuffer[vStringLen] = '\0';
	mVersString = vBuffer;
	delete[] vBuffer;

	return END_FUNC(ZERR_SUCCESS);
}

/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

} // End Namespace

/* vi: set ts=4: */
