/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#include "Client.h"

/* System Headers */
#include <qfile.h>
#include <qfileinfo.h>
#include <qimage.h>
#include <qdir.h>
#include <qsettings.h>

#if ZULU_PLATFORM	== PLATFORM_WINDOWS
#include <windows.h>
#include <process.h>
#include <time.h>
#include <timeval.h>
#elif ZULU_PLATFORM == PLATFORM_MAC || ZULU_PLATFORM == PLATFORM_LINUX
#include <sys/time.h>
#else
#error Unsupported platform
#endif

/* Local Headers */
#include "App.h"
#include "MD5Hasher.h"
#include "Log.h"
#include "ErrorPacket.h"
#include "Header.h"
#include "VersPacket.h"
#include "VersRespPacket.h"
#include "AuthPacket.h"
#include "AuthRespPacket.h"
#include "FlagPacket.h"
#include "FlagRespPacket.h"
#include "FilePacket.h"
#include "FileRespPacket.h"
#include "DonePacket.h"
#include "DoneRespPacket.h"
#include "HeartbeatPacket.h"


static ZUSHORT CONNECT_TIMEOUT = 5;
static ZUSHORT RECEIVE_TIMEOUT = 20;

namespace ZOTO
{

DECLARE_CLASS( "ZClient" )

/********************************************************************
 *																	*
 *          C O N S T R U C T I O N / D E S T R U C T I O N         *
 *																	*
 ********************************************************************/
ZClient::ZClient(const QString &pHost, ZUSHORT pPort)
	: ZObject(), mHost(pHost), mPort(pPort), mConnected(false), 
		mPaused(false), mCancel(false),	mXferThread(0)
{

}

ZClient::~ZClient()
{
	mSocket.Close();
#if ZULU_PLATFORM	== PLATFORM_WINDOWS
	WSACleanup();
#endif

}

/********************************************************************
 *																	*
 *                        A T T R I B U T E S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                        O P E R A T I O N S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							 Initialize()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Prepares this client instance for use.  Creates the
 *				underlying socket.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::Initialize()
{
	ZRESULT vZReturn;

	BEG_FUNC(NULL);

#if ZULU_PLATFORM	== PLATFORM_WINDOWS
	static bool vWSARun = false;
	/* with Win32, we have to additionally initialize the winsock	*/
	/* interface, since native berkeley sockets apparently don't	*/
	/* do it for M$.												*/
	if (vWSARun == false)
	{
		WSADATA wsadata;
		WORD	wVer;
		wVer = MAKEWORD(2,0);
		if (WSAStartup(wVer, &wsadata) != 0)
	    {
	        ZERROR("Unable to initialize winsock!\n");
			return END_FUNC(ZERR_CREATE_SOCKET);
	    }
		vWSARun = true;
	}
#endif

	if ((vZReturn = CreateSocket()) != ZERR_SUCCESS)
		return END_FUNC(vZReturn);

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 ConnectServer()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Attempts to establish a network connection to the
 *				Zoto server.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::ConnectServer()
{
	ZRESULT	vZReturn = ZERR_SUCCESS;

	BEG_FUNC(NULL);

	ZTRACE("Attempting connection to Zoto server\n");
	ZTRACE(QString("Address: %1\n").arg(mHost));
	ZTRACE("Port:    %d\n", mPort);

	mConnected = false;

	mSocket.Close();
	if (CreateSocket() != ZERR_SUCCESS)
		return END_FUNC(ZERR_CREATE_SOCKET);

	if ((vZReturn = mSocket.Connect(mHost.latin1(), mPort, CONNECT_TIMEOUT)) != ZERR_SUCCESS)
	{
		ZTRACE("Failed to connect to the Zoto server\n");
		Disconnect(); // so the socket object gets reset
		return END_FUNC(vZReturn);
	}

	mConnected = true;

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 CheckVersion()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Determines if the currently running version of the
 *				Zoto Uploader is up to date.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::CheckVersion(QString& vLatestVersion)
{
	BEG_FUNC(NULL);

	ZVersPacket		vVers;
	ZVersRespPacket	vVersResp;
	ZRESULT			vZReturn = ZERR_SUCCESS;
	ZErrorPacket	*vError = NULL;

	/*
	 * Build the outgoing packet.
	 */
	vVers.SetVersMaj(ZULU_APP()->GetVersMaj());
	vVers.SetVersMin(ZULU_APP()->GetVersMin());
	vVers.SetVersBuild(ZULU_APP()->GetVersBuild());
	vVers.SetVersString(ZULU_APP()->GetVersString());
	ZTRACE("Current ZOTO version => [%d.%d.%d%s]\n",
	            vVers.GetVersMaj(), vVers.GetVersMin(), vVers.GetVersBuild(), vVers.GetVersString());

	/*
	 * Send it and wait for response.
	 */
	vZReturn = SendAndReceive(vVers, vVersResp, vError);
	if (vZReturn != ZERR_SUCCESS)
	{
		ZTRACE("Error checking client version with server\n");
		Disconnect();
		return END_FUNC(ZERR_COMM);
	}

	/*
	 * Check the return code.
	 */
	switch (vVersResp.GetReturnCode())
	{
	case ZSP_VERS_GOOD:
		ZTRACE("Version check successful!\nComment[%s]\n", vVersResp.GetReturnText());
		return END_FUNC(ZERR_SUCCESS);
	case ZSP_VERS_OLD:
		vLatestVersion = vVersResp.GetReturnText();
		ZTRACE(QString("New Zoto Uploader version [%1] available\n").arg(vLatestVersion));
		return END_FUNC(ZERR_NEW_VERSION);
	case ZSP_VERS_BAD:
		vLatestVersion = vVersResp.GetReturnText();
		ZTRACE(QString("Uploader out of date.  New version [%1] available\n").arg(vLatestVersion));
		Disconnect();
		return END_FUNC(ZERR_INVALID_VERSION);
	default:
		ZERROR("Unknown version response => [%d]\n", vVersResp.GetReturnCode());
		Disconnect();
		return END_FUNC(ZERR_COMM);
	}
}

/*------------------------------------------------------------------*
 *							 Authenticate()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Validates the user's credentials with the Zoto server.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 *
 *	@param		pUser
 *					Username to authenticate.
 *	@param		pPswdHash
 *					Password hash to authenticate.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 * 31-Oct-2005	Added username and password as		Josh Williams	*
 * 				arguments.											*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::Authenticate(const QString& pUser, const QString& pPswdHash)
{
	ZRESULT					vZReturn;
	ZAuthPacket				vAuth;
	ZAuthRespPacket			vAuthResp;
	ZErrorPacket			*vError = NULL;
	char					vHash[33];

	BEG_FUNC("%p, %p", &pUser, &pPswdHash);

	ZMD5Hasher::HashString(pUser.latin1(), pUser.length(), vHash, sizeof(vHash));

	/*
	 * Build the outgoing AUTH packet
	 */
	vAuth.SetUserName(pUser.latin1());
	vAuth.SetUserHash(vHash);
	vAuth.SetPswdHash(pPswdHash.latin1());

	ZTRACE("|---------------------------|\n");
	ZTRACE("|    * AUTHENTICATING *     |\n");
	ZTRACE("|---------------------------|\n");
	ZTRACE("User name: [%s]            \n", vAuth.GetUserName());
	ZTRACE("User hash: [%s]            \n", vAuth.GetUserHash());
	ZTRACE("Pswd hash: [%s]            \n", vAuth.GetPswdHash());

	/*
	 * Send it and wait for response.
	 */
	vZReturn = SendAndReceive(vAuth, vAuthResp, vError);
	if (vZReturn != ZERR_SUCCESS)
	{
		ZTRACE("Error authenticating with Zoto server\n");
		Disconnect();
		return END_FUNC(ZERR_COMM);
	}

	/*
	 * Check the return code.
	 */
	switch (vAuthResp.GetReturnCode())
	{
	case ZSP_AUTH_OK:
		ZTRACE("Authentication was successful.\n");
		return END_FUNC(ZERR_SUCCESS);
	case ZSP_AUTH_BAD:
		ZTRACE("Invalid username or password password\n");
		return END_FUNC(ZERR_BAD_AUTH);
	default:
		ZERROR("Unknown version response: [%d]\n", vAuthResp.GetReturnCode());
		return END_FUNC(ZERR_SERVER_ERROR);
	}
}

/*------------------------------------------------------------------*
 *							 Disconnect()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Severs the connection to the Zoto server.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::Disconnect()
{
	BEG_FUNC(NULL);

	if (mConnected)
		mSocket.Shutdown(SHUT_RDWR);

	mConnected = false;

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 	SendFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Calls the main transfer routine, either synchronously
 *				or asynchronously.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 *
 *	@param		pInfo
 *					Reference to a structure holding the transfer status
 *					information.
 *	@param		pCallback
 *					Optional function to be called to provide progress
 *					notifications.
 *	@param		pBackground
 *					Whether or not the file transfer logic should
 *					be run in a separate thread.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::SendFile(ZXferInfo& pInfo, ZSTAT_CALLBACK pCallback /*=NULL*/,
			bool pBackground /*=false*/)
{

	BEG_FUNC("%p, %p, %s", &pInfo, pCallback, pBackground ? "true" : "false");

	ZRESULT	vZReturn;

	/*
	 * Store the current file name so the thread function can access it.
	 */
	mCurrentInfo = pInfo;
	mCallback = pCallback;

	if (pBackground)
	{
#if ZULU_PLATFORM	== PLATFORM_WINDOWS
		mXferThread = _beginthread(_TransferFile, 0, this);
		if (mXferThread < 0)
#elif ZULU_PLATFORM == PLATFORM_MAC
		int vRetval = pthread_create(&mXferThread, NULL, _TransferFile, this);
		if (vRetval != 0)
#elif ZULU_PLATFORM == PLATFORM_LINUX
		int vRetval = pthread_create(&mXferThread, NULL, _TransferFile, this);
		if (vRetval != 0)
#else
#error Unsupported platform.
#endif
			vZReturn = ZERR_UNKNOWN;
		else
			vZReturn = ZERR_SUCCESS;
	}
	else
		vZReturn = TransferFile();

	return END_FUNC(vZReturn);
}

/*------------------------------------------------------------------*
 *							 CancelTransfer()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Terminates the transfer thread gracefully.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZClient::CancelTransfer()
{
	BEG_FUNC(NULL);

	mCancel = true;
	this->ResumeTransfer(); // Just in case we're paused
	mThreadLock.Lock(); // Wait for the thread to finish processing.
	mCancel = false;
	mThreadLock.Unlock();

	END_FUNCV();
}


/********************************************************************
 *																	*
 *                          O P E R A T O R S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          C A L L B A C K S                       *
 *																	*
 ********************************************************************/

/********************************************************************
 *																	*
 *                          I N T E R N A L S                       *
 *																	*
 ********************************************************************/

/*------------------------------------------------------------------*
 *							 CreateSocket()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates and initializes the network socket.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::CreateSocket()
{
	ZRESULT	vZReturn = ZERR_SUCCESS;

	BEG_FUNC(NULL);

	/*
	 * If the socket's already been used, reinitialize it before use.
	 */
	if (mSocket.GetStatus() != SS_UNALLOCATED)
	{
		Disconnect();
		mSocket.Close();
	}

	if ((vZReturn = mSocket.Create(0, SOCK_STREAM)) != ZERR_SUCCESS)
	{
		ZTRACE("Unable to create ZSocket.  Error: %d\n", mSocket.GetError());
		Disconnect();
		return END_FUNC(vZReturn);
	}

	return END_FUNC(ZERR_SUCCESS);
}

THREAD_FUNC ZClient::_TransferFile(void *pParam)
{
	static_cast<ZClient*>(pParam)->TransferFile();
	THREAD_RET;
}

/*------------------------------------------------------------------*
 *							 TransferFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Magic time.  This is the jewel that performs all the
 *				logic necessary for uploading a file to the Zoto server.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 *
 *	@remarks	For every file to be transfered, the server is first
 *				queried	as to whether or not this particular file is
 *				needed.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::TransferFile()
{
	BEG_FUNC(NULL);

	QFile			vFile;
	QFileInfo		vFileInfo;
	ZRESULT			vZReturn;
	bool			vNeeded = false;
	int				vBytes = 2048;
	char			vBuffer[2048];
	float			vProgress = 0.0f;
	struct timeval	vLastUpdate, vCurrent;
	double			vElapsed;
	ZULONG			vUpdateBytes = 0L;
	char			vFileDate[20];

	ZTRACE(QString("Attempting to upload file [%1]\n").arg(mCurrentInfo.mFile));

	mCurrentInfo.mTemp		= false;
	mCurrentInfo.mTempName	= "";
	mCurrentInfo.mStatus	= XFER_ACTIVE;
	mCurrentInfo.mProgress	= 0.0f;
	mCurrentInfo.mBytes		= 0L;

	mThreadLock.Lock();

	gettimeofday(&vLastUpdate, NULL);

	/*
	 * First off, let's make sure we can even open the file.
	 */
	vFile.setName(mCurrentInfo.mFile);
	if (vFile.open(IO_ReadOnly) != true)
	{
		ZTRACE(QString("Error opening file [%1]\n").arg(mCurrentInfo.mFile));
		ClientUpdate(XFER_FAILED, 0.0f, 0L, 0.0f, ZERR_OPEN_FILE);
		return END_FUNC(ThreadCleanup(ZERR_OPEN_FILE));
	}
	vFile.close();
	PauseWait();
	if (mCancel)
	{
		ZTRACE("Cancelled\n");
		return END_FUNC(ThreadCleanup(ZERR_CANCELLED));
	}

	/*
	 * Now, let's see if it's the right format.
	 */
	QString vFormat = QImage::imageFormat(mCurrentInfo.mFile);
	if (vFormat.compare("JPEG") == 0)
	{
		/*
		 * Right format.  Reopen it.
		 */
		vFile.open(IO_ReadOnly);
	}
	else
	{
		/*
		 * Need to convert.
		 */
		ZTRACE(QString("Converting image [%1] to JPEG\n").arg(mCurrentInfo.mFile));
		if ((vZReturn = CreateTempFile(vFile)) != ZERR_SUCCESS)
		{
			ZTRACE(QString("Error opening file [%1]\n").arg(mCurrentInfo.mTempName));
			ClientUpdate(XFER_FAILED, 0.0f, 0L, 0.0f, vZReturn);
			return END_FUNC(ThreadCleanup(vZReturn));
		}
	}

	mCurrentInfo.mSize = vFile.size();

	/*
	 * Ok, it's open.  Checksum it.
	 */
	if ((vZReturn = ComputeSum(vFile, mCurrentInfo.mMD5)) != ZERR_SUCCESS)
	{
		ZTRACE(QString("Error summing file [%1]\n").arg(vFile.name()));
		ClientUpdate(XFER_FAILED, 0.0f, 0L, 0.0f, vZReturn);
		return END_FUNC(ThreadCleanup(vZReturn));
	}
	PauseWait();
	if (mCancel)
	{
		ZTRACE("Cancelled\n");
		vFile.close();
		return END_FUNC(ThreadCleanup(ZERR_CANCELLED));
	}

	/*
	 * Get the date, either from the exif or from the modified date.
	 */
	memset(vFileDate, 0, sizeof(vFileDate));
	if ((vZReturn = GetFileDate(vFile, vFileDate)) != ZERR_SUCCESS)
	{
		ZTRACE(QString("Error getting file date for file [%1]\n").arg(vFile.name()));
		ClientUpdate(XFER_FAILED, 0.0f, 0L, 0.0f, vZReturn);
		return END_FUNC(ThreadCleanup(vZReturn));
	}
	PauseWait();
	if (mCancel)
	{
		ZTRACE("Cancelled\n");
		vFile.close();
		return END_FUNC(ThreadCleanup(ZERR_CANCELLED));
	}

	/*
	 * Cool.  File is open and MD5'd.  Does the server want it?
	 */
	if ((vZReturn = ServerFlag(vFile, vNeeded)) != ZERR_SUCCESS)
	{
		ZTRACE(QString("Error processing FLAG for file [%1]\n").arg(vFile.name()));
		ClientUpdate(XFER_FAILED, 0.0f, 0L, 0.0f, vZReturn);
		return END_FUNC(ThreadCleanup(vZReturn));
	}
	PauseWait();
	if (mCancel)
	{
		ZTRACE("Cancelled\n");
		vFile.close();
		return END_FUNC(ThreadCleanup(ZERR_CANCELLED));
	}

	if (vNeeded == false)
	{
		/*
		 * Server doesn't want this file (already uploaded)
		 */
		ZTRACE(QString("Skipping file %1.  Not needed...\n").arg(vFile.name()));
		vFile.close();
		if (mCurrentInfo.mTemp == true)
			DeleteTempFile();
		ClientUpdate(XFER_FAILED, mCurrentInfo.mProgress, vFile.size(), 0.0f, ZERR_DUPLICATE_FILE);
		mThreadLock.Unlock();
		return END_FUNC(ZERR_DUPLICATE_FILE);
	}
	else
	{
		/*
		 * Yay.  Server wants this file.  Send a file packet prior to uploading
		 */
		if ((vZReturn = ServerFile(vFile)) != ZERR_SUCCESS)
		{
			ZTRACE(QString("Unable to process FILE handshaking for file [%1]\n").arg(vFile.name()));
			ClientUpdate(XFER_FAILED, 0.0f, 0L, 0.0f, vZReturn);
			return END_FUNC(ThreadCleanup(vZReturn));
		}
		PauseWait();
		if (mCancel)
		{
			ZTRACE("Cancelled\n");
			vFile.close();
			return END_FUNC(ThreadCleanup(ZERR_CANCELLED));
		}

		/*
		 * Ok, let's do it.  Continue reading the file and sending until either
		 * complete, or an error is encountered.
		 */
		ClientUpdate(XFER_STARTING, mCurrentInfo.mProgress, 0, 0.0f, ZERR_SUCCESS);
		mSocket.EnableThrottling(true);
		while (!vFile.atEnd())
		{
			if ((vBytes = vFile.readBlock(vBuffer, vBytes)) == -1)
			{
				ZTRACE(QString("Error reading from file [%1].\n").arg(vFile.name()));
				ClientUpdate(XFER_FAILED, mCurrentInfo.mProgress, vFile.at(), 0.0f, ZERR_READ_FILE);
				return END_FUNC(ThreadCleanup(vZReturn));
			}
			if (vBytes == 0)
				break;

			/*
			 * At this point, we've read a block of data from the file.
			 * Try and send it to the server.
			 */
			if ((vZReturn = mSocket.Send(vBuffer, vBytes)) != ZERR_SUCCESS)
			{
				if (vZReturn == ZERR_TIMEOUT)
				{
					ZTRACE("Timed out sending data to the server\n");
					ClientUpdate(XFER_FAILED, 0.0f, 0L, 0.0f, vZReturn);
					return END_FUNC(ThreadCleanup(ZERR_TIMEOUT));
				}
				else
				{
					ZTRACE("Unknown error occurred in Send()\n");
					ClientUpdate(XFER_FAILED, 0.0f, 0L, 0.0f, vZReturn);
					return END_FUNC(ThreadCleanup(vZReturn));
				}
			}

			/*
			 * Alright, we've sent the chunk to the server.  Regroup.
			 */
			vUpdateBytes += vBytes;
			gettimeofday(&vCurrent, NULL);
			vElapsed = (vCurrent.tv_sec + vCurrent.tv_usec*1e-6) -
							(vLastUpdate.tv_sec + vLastUpdate.tv_usec*1e-6);

			long vOffset = vFile.at();
			if (vElapsed >= .25f || vOffset == -1)
			{
				vLastUpdate = vCurrent;
				if (vOffset == -1)
					vProgress = 1.0f;
				else
					vProgress = (double)vFile.at() / (double)vFile.size();
				double vSpeed = mSocket.GetSpeed();
               	ClientUpdate(XFER_ACTIVE, vProgress, vUpdateBytes, vSpeed, ZERR_SUCCESS);
				vUpdateBytes = 0L;
			}

			/*
			 * See if the user hit the pause/cancel buttons.
			 */
			PauseWait();
			if (mCancel)
			{
				ZTRACE("Cancelled\n");
				vFile.close();
				return END_FUNC(ThreadCleanup(ZERR_CANCELLED));
			}

			vBytes = 2048;

		} /* while() */

		/*
		 * We're done.  Close the file.
		 */
		vFile.close();

		ClientUpdate(XFER_ACTIVE, 1.0f, vUpdateBytes, mSocket.GetSpeed(), ZERR_SUCCESS);

		/*
		 * Phew.  Finished.  Now, make sure all went well in the transfer.
		 */
		ZTRACE("Sending done packet\n");
		if ((vZReturn = ServerDone()) != ZERR_SUCCESS)
		{
			ZTRACE("Error processing DONE logic with server\n");
			ClientUpdate(XFER_FAILED, mCurrentInfo.mProgress, vFile.at(), 0.0f, vZReturn);
			return END_FUNC(ThreadCleanup(vZReturn));
		}

		/*
		 * woot.
		 */
		ZTRACE("ServerDone() complete!\n");
		mThreadLock.Unlock();
		ClientUpdate(XFER_COMPLETE, 1.0f, vUpdateBytes, mSocket.GetSpeed(), ZERR_SUCCESS);

		/*
		 * If this was a temp file, delete it.
		 */
		if (mCurrentInfo.mTemp == true)
			DeleteTempFile();

	}

	ZTRACE("******************************\n");
	ZTRACE("******* THREAD EXITING *******\n");
	ZTRACE("******************************\n");

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 ServerFlag()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Queries the server to determine if the specified
 *				file is needed for upload.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 *
 *	@param		pFile
 *					File object being transferred.
 *	@param		pNeeded
 *					Reference to let the calling function know whether
 *					or not the server deemed an upload of this
 *					image necessary.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::ServerFlag(QFile& pFile, bool& pNeeded)
{
	ZRESULT			vZReturn;
	ZFlagPacket		vFlag;
	ZFlagRespPacket	vFlagResp;
	ZErrorPacket	*vError = NULL;
	char			vFileDate[20];

	BEG_FUNC("%p, %p", &pFile, &pNeeded);

	/*
	 * Get the date, either from the exif or from the modified date.
	 */
	memset(vFileDate, 0, sizeof(vFileDate));
	if ((vZReturn = GetFileDate(pFile, vFileDate)) != ZERR_SUCCESS)
	{
		ZTRACE("Error getting file date\n");
		Disconnect();
		return END_FUNC(vZReturn);
	}

	/*
	 * Build the outbound packet.
	 */
	QFileInfo vInfo(pFile.name());
	vFlag.SetImageId(mCurrentInfo.mMD5);
	vFlag.SetImageFormat(ZSP_JPEG);
	vFlag.SetImageSize(pFile.size());
	vFlag.SetImageDate(vFileDate);
	vFlag.SetImageName(mCurrentInfo.mName);

	/*
	 * Send it and wait for response.
	 */
	vZReturn = SendAndReceive(vFlag, vFlagResp, vError);
	if (vZReturn != ZERR_SUCCESS)
	{
		ZTRACE("Error checking flag with server.\n");
		Disconnect();
		return END_FUNC(ZERR_COMM);
	}

	/*
	 * Is it needed?
	 */
	pNeeded = vFlagResp.GetNeeded();

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 ServerFile()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Notifies the server that we are ready to upload an
 *				image.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 *
 *	@param		pFile
 *					File object being transferred.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::ServerFile(QFile& pFile)
{
	ZRESULT			vZReturn = ZERR_SUCCESS;
	ZFilePacket		vFile;
	ZFileRespPacket	vFileResp;
	ZErrorPacket	*vError = NULL;
	QFileInfo		vInfo;
	char			vFileDate[20];

	BEG_FUNC("%p", &pFile);

	/*
	 * Get the date, either from the exif or from the modified date.
	 */
	memset(vFileDate, 0, sizeof(vFileDate));
	if ((vZReturn = GetFileDate(pFile, vFileDate)) != ZERR_SUCCESS)
	{
		ZTRACE("Error getting file date\n");
		Disconnect();
		return END_FUNC(vZReturn);
	}

	/*
	 * Build the outbound packet.
	 */
	vInfo.setFile(pFile);
	vFile.SetImageId(mCurrentInfo.mMD5);
	vFile.SetImageFormat(ZSP_JPEG);
	vFile.SetImageSize(pFile.size());
	vFile.SetImageDate(vFileDate);
	vFile.SetImageName(mCurrentInfo.mName);

	/*
	 * Send it and wait for response.
	 */
	vZReturn = SendAndReceive(vFile, vFileResp, vError);
	if (vZReturn != ZERR_SUCCESS)
	{
		ZTRACE("Error checking flag with server.\n");
		Disconnect();
		return END_FUNC(ZERR_COMM);
	}

	/*
	 * Check the return code.
	 */
	if (vFileResp.GetReturnCode() != ZSP_FILE_OK)
	{
		ZTRACE("Server rejected our file request.\n");
		ZTRACE("Error - [%d:%s]\n", vFileResp.GetReturnCode(),
			vFileResp.GetReturnText());
		Disconnect();
		return END_FUNC(ZERR_SERVER_ERROR);
	}

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 ServerDone()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Verifies with the server that an image upload
 *				completed successfully.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::ServerDone()
{
	ZRESULT			vZReturn;
	ZDonePacket		vDone;
	ZDoneRespPacket	vDoneResp;
	ZErrorPacket	*vError = NULL;

	BEG_FUNC(NULL);

	ZTRACE("Setting Image ID to [%s]\n", mCurrentInfo.mMD5);
	vDone.SetImageId(mCurrentInfo.mMD5);

	/*
	 * Send it and wait for response.
	 */
	vZReturn = SendAndReceive(vDone, vDoneResp, vError);
	if (vZReturn != ZERR_SUCCESS)
	{
		ZTRACE("Error verifying upload with server.\n");
		Disconnect();
		return END_FUNC(vZReturn);
	}

	/*
	 * Check the return code.
	 */
	if (vDoneResp.GetReturnCode() != ZSP_DONE_OK)
	{
		ZTRACE("Server rejected our done packet.\n");
		ZTRACE("Error - [%d:%s]\n", vDoneResp.GetReturnCode(),
			vDoneResp.GetReturnText());
		Disconnect();
		return END_FUNC(ZERR_SERVER_ERROR);
	}

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							SendAndReceive()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Sends a ZSP packet to the Zoto server and waits for
 *				a response.
 *
 *	@author		Josh Williams
 *	@date		05-Apr-2005
 *
 *	@param		pSend
 *					Packet to be transmitted.
 *	@param		pReceive
 *					Reference to packet to be populated on receive.
 *	@param		pError
 *					Pointer to hold address of error packet in case
 *					of failure.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::SendAndReceive(ZPacket& pSend, ZPacket& pReceive,
									ZErrorPacket *pError)
{
	BEG_FUNC("%p, %p", &pSend, &pReceive);

	ZRESULT     			vZReturn;
	ZUSHORT         		vRemLen;
	ZUINT					vBytes = 0;
	int						vRecvBytes = 0;
	static ZBYTE    		vBuffer[1025];
 	ZUSHORT					vCount = 0;
	static ZHeader			vHeader;
	static ZErrorPacket		vError;
	static ZHeartbeatPacket	vHeartbeat;
	bool					vBypassRecv = false;

	/*
	 * First, we need to build and send the packet.
	 */
	if ((vZReturn = pSend.Build()) != ZERR_SUCCESS)
		return END_FUNC(vZReturn);

	vZReturn = mSocket.Send(pSend.GetRaw(), pSend.GetPacketLen());
	if (vZReturn != ZERR_SUCCESS)
	{
		ZTRACE("Error sending packet\n");
		Disconnect();
		return END_FUNC(ZERR_COMM);
	}

	/*
	 * Main receive loop.  This loop will continue until either:
	 * a.  A full packet is received, or
	 * b.  The socket is closed
	 */
	while (vCount < 5)
	{
     	vCount++;
		vRecvBytes = 1024 - vBytes;

		/*
		 *	Let's, like, try and receive something.
		 */
		if (vBypassRecv)
		{
			vZReturn = ZERR_SUCCESS;
			vRecvBytes = vBytes;
			vBytes = 0;
			vBypassRecv = false;
		}
		else
		{
			vZReturn = mSocket.Receive((char *)&vBuffer[vBytes], vRecvBytes, RECEIVE_TIMEOUT);
		}

		switch (vZReturn)
		{
		case ZERR_SUCCESS:
			break;
		case ZERR_INVALID_STATUS:
			ZTRACE("Not connected?\n");
			Disconnect();
			return END_FUNC(ZERR_COMM);
		case ZERR_TIMEOUT:
			ZTRACE("Timed out.\n");
			Disconnect();
			return END_FUNC(ZERR_TIMEOUT);
		default:
			ZTRACE("Bad things happened in Receive()\n");
			ZTRACE("Got [%s]\n", Z_TO_STRING(vZReturn));
			Disconnect();
			return END_FUNC(ZERR_COMM);
		}

		/*
		 * We received something.  Check the length.
		 */
		vBytes += vRecvBytes;
		if (vRecvBytes <= 0)
		{
			ZTRACE("Socket closed\n");
			Disconnect();
			return END_FUNC(ZERR_COMM);
		}
		else if (vRecvBytes < static_cast<int>(HEADER_SIZE))
		{
			ZTRACE("Incomplete header received\n");
			continue;
		}

		/*
		 * Ok.  We've successfully received AT LEAST a good header.
		 * Let's see if we've got a full packet.
		 */
		vHeader.Parse(vBuffer, vBytes);
		ZTRACE("===================================\n");
		ZTRACE("Received a complete header\n");
		ZTRACE("Type    => [%d]\n", vHeader.GetPacketType());
		ZTRACE("Payload => [%d]\n", vHeader.GetPayloadLen());
		ZTRACE("vBytes  => [%d]\n", vBytes);
		for (ZUINT i = 0; i < vBytes; i++)
			ZTRACE("vBuffer[%d] => [%d]\n", i, vBuffer[i]);

		if (vBytes < vHeader.GetPacketLen())
		{
			ZTRACE("haven't received complete packet yet.  continuing...\n");
		    continue; // Not a complete packet yet
		}

		/*
		 * Full packet.  Is it an error packet?
		 */
		if (vHeader.GetPacketType() == ZSP_ERROR)
		{
			ZTRACE("Received error packet from the server\n");
			ZUINT vErrorLen = vHeader.GetPacketLen();
			vError.Parse(vBuffer, vErrorLen);
			pError = &vError; // Store it so the calling function can process
			return END_FUNC(ZERR_SERVER_ERROR);
		}

		/*
		 * Maybe a heartbeat?
		 */
		if (vHeader.GetPacketType() == ZSP_HEARTBEAT)
		{
			ZTRACE("Got heartbeat (keep-alive) from the server\n");
			ZTRACE("vBytes before parse: %d\n", vBytes);
			vHeartbeat.Parse(vBuffer, vBytes);
			ZTRACE("vBytes after parse: %d\n", vBytes);
			vCount = 0;
			if (vBytes > 0)
				vBypassRecv = true;
			continue;
		}

		/*
		 * Ok.  It's a full packet, and it's not an error.  Is it the right type?
		 */
		if (vHeader.GetPacketType() != pReceive.GetPacketType())
		{
			ZERROR("Packet type mismatch\nExpecting [%d], received [%d]\n",
						pReceive.GetPacketType(), vHeader.GetPacketType());
			return END_FUNC(ZERR_COMM);
		}

		/*
		 * OMGLOLwtF!!!!!1  Sweet jesus, it worked.
		 */
		ZTRACE("complete packet received\n");
		pReceive.Parse(vBuffer, vBytes);
		ZTRACE("packet length: %d\n", pReceive.GetPacketLen());
		vRemLen = vBytes - pReceive.GetPacketLen();
		/*
		if (vRemLen > 0)
		{
			// copy the remaining bytes to the front of the buffer
            memcpy(vBuffer, &vBuffer[pReceive.GetPacketLen()], vRemLen);
   	        // clear the rest of the buffer
       	    memset(&vBuffer[vRemLen], '\0', 1024 - vRemLen);
           	vBytes = vRemLen;
		}
		else
		{
			memset(vBuffer, '\0', 1024);
			vBytes = 0;
		}
		*/

		break;
	}

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 ClientUpdate()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Called to notify the calling process of upload progress.
 *
 *	@author		Josh Williams
 *	@date		10-Mar-2005
 *
 *	@param		pStat
 *					Current status of the upload process.
 *	@param		pProgress
 *					Percentage of upload complete.
 *	@param		pBytes
 *					Number of bytes uploaded since the last update.
 *	@param		pSpeed
 *					Speed at which we are currently transmitting.
 *	@param		pErrCode
 *					Error encountered during upload, or ZERR_SUCCESS.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::ClientUpdate(eZXferStat pStat, double pProgress,
										long pBytes, double pSpeed, ZRESULT pErrCode)
{
	BEG_FUNC("%d, %f, %d, %f, %d", pStat, pProgress, pBytes, pSpeed, pErrCode);

	if (mCallback != NULL)
	{
		mCurrentInfo.mStatus	= pStat;
		mCurrentInfo.mProgress	= pProgress;
		mCurrentInfo.mBytes		= pBytes;
		mCurrentInfo.mSpeed		= pSpeed;
		mCurrentInfo.mErrcode	= pErrCode;
		mCallback(&mCurrentInfo);
	}

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 ComputeSum()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Calculates the MD5 sum of the specified file.
 *
 *	@author		Josh Williams
 *	@date		10-Mar-2005
 *
 *	@param		pFile
 *					File object to be checksum'd.
 *	@param		pChecksum
 *					Buffer to hold the MD5 sum.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::ComputeSum(QFile& pFile, char *pChecksum)
{
	static char			vBuffer[1024];
	static char			vDigest[33];
	static int			vBytes = 0;
	static ZMD5Hasher	vHasher;
	ZRESULT				vZReturn = ZERR_SUCCESS;

	BEG_FUNC("%p, %p", &pFile, pChecksum);

	ZTRACE(QString("Trying to hash [%1]\n").arg(pFile.name()));
	pFile.reset();

	if (pFile.atEnd())
	{
		ZERROR("Error at end of file!");
		return END_FUNC(ZERR_READ_FILE);
	}

	if (pFile.status() != IO_Ok)
	{
		ZERROR("Unable to open file\n");
		return END_FUNC(ZERR_OPEN_FILE);
	}

	vHasher.Init();
	vBytes = pFile.readBlock(vBuffer, 1024);
	if (vBytes == 0)
	{
		ZERROR("Unable to read file.\n");
		return END_FUNC(ZERR_READ_FILE);
	}

	while (vBytes > 0)
	{
		vHasher.Update((ZBYTE *)vBuffer, vBytes);
		vBytes = pFile.readBlock(vBuffer, 1024);
	}

	pFile.reset();

	vHasher.Final();

	vZReturn = vHasher.GetDigestString(vDigest, sizeof(vDigest));
	if (vZReturn != ZERR_SUCCESS)
	{
		return END_FUNC(vZReturn);
	}

	vDigest[32] = '\0';

	memcpy(pChecksum, vDigest, 32);

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							 ThreadCleanup()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Closes down the socket and releases the thread lock.
 *
 *	@author		Josh Williams
 *	@date		02-Dec-2004
 *
 *	@param		pResult
 *					Value to be returned on completion.
 *
 *	@remarks	Only call this function if the thread is shutting down
 *				abnormally, as the socket will be closed, preventing
 *				further processing.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::ThreadCleanup(ZRESULT pResult)
{
	Disconnect();
	mThreadLock.Unlock();
	mSocket.EnableThrottling(false);

	/*
	 * Remove the temporary file, if it exists.
	 */
	if (mCurrentInfo.mTemp == true)
		DeleteTempFile();

	return pResult;
}

/*------------------------------------------------------------------*
 *								GetFileDate()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Retrieves the creation date of the file.
 *
 *	@author		Josh Williams
 *	@date		05-May-2005
 *
 *	@param		pFile
 *					URI of the file being processed.
 *	@param		pDate
 *					Buffer to hold the formatted date.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::GetFileDate(const QFile& pFile, char *pDate)
{
	QString		vDateTime;
	QFileInfo	vInfo(pFile);

	BEG_FUNC("%p, %p", &pFile, pDate);

	/*
	 * coded on the blessed day of Cinco dey Mayo.  Viva la Tequila!
	 */
	vDateTime = vInfo.created().toString("yyyy-MM-dd hh:mm:ss");

	memcpy(pDate, vDateTime.latin1(), 19);

	ZTRACE("File creation date => [%s]\n", pDate);
	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							CreateTempFile()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Creates a temporary file in JPEG format.
 *
 *	@author		Josh Williams
 *	@date		07-Jul-2005
 *
 *	@param		pFile
 *					Reference to the file object to hold the temp file.
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::CreateTempFile(QFile& pFile)
{
	QString		vTempPath;
	QDir		vDir;
	char		vTempMD5[33];
	QFile		vFile;
	ZRESULT		vZReturn;

	BEG_FUNC(NULL);

	/*
	 * If we don't already have a temp directory, create one.
	 */
	vTempPath = qApp->applicationDirPath();
	vTempPath += "/temp/";
	vDir.setPath(vTempPath);
	ZTRACE(QString("Checking temp path [%1]\n").arg(vTempPath));
	if (vDir.exists() == false)
	{
		ZTRACE("Creating temp directory\n");
		if (vDir.mkdir(vTempPath))
			ZTRACE("Temp directory created\n");
		else
		{
			ZTRACE("Unable to create temp directory\n");
			return END_FUNC(ZERR_OPEN_FILE);
		}
	}


	/*
	 * Get a temporary MD5
	 */
	vFile.setName(mCurrentInfo.mFile);
	if (vFile.open(IO_ReadOnly) != true)
	{
		ZTRACE(QString("Error opening file [%1]\n").arg(mCurrentInfo.mFile));
		return END_FUNC(ZERR_OPEN_FILE);
	}

	memset(vTempMD5, '\0', sizeof(vTempMD5));
	if ((vZReturn = ComputeSum(vFile, vTempMD5)) != ZERR_SUCCESS)
	{
		ZTRACE("Error summing file\n");
		return END_FUNC(vZReturn);
	}
	vFile.close();

	/*
	 * Convert the file.
	 */
	ZTRACE("Converting the file\n");
	mCurrentInfo.mTemp = true;
	mCurrentInfo.mTempName = vTempPath;
	mCurrentInfo.mTempName += "ZOTO_";
	mCurrentInfo.mTempName += vTempMD5;
	mCurrentInfo.mTempName += ".jpg";
	ZTRACE(QString("Temp name built as [%1]\n").arg(mCurrentInfo.mTempName));
	QImage vImg(mCurrentInfo.mFile);
	ZTRACE("Temp pix opened\n");
	if (vImg.isNull())
	{
		ZTRACE("NULL Image!\n");
		return END_FUNC(ZERR_OPEN_FILE);
	}
	vImg.save(mCurrentInfo.mTempName, "JPEG", 100);
	ZTRACE("Temp pix saved\n");
	pFile.setName(mCurrentInfo.mTempName);
	ZTRACE("File converted\n");

	/*
	 * Try to open it.
	 */
	if (pFile.open(IO_ReadOnly) != true)
	{
		ZTRACE(QString("Error opening file [%1]\n").arg(mCurrentInfo.mTempName));
		return END_FUNC(ZERR_OPEN_FILE);
	}

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *							DeleteTempFile()						*
 *------------------------------------------------------------------*/
/**
 *	@brief		Removes the temporary jpeg file created when uploading
 *				an image from an alternate format (.gif, .bmp, etc)
 *
 *	@author		Josh Williams
 *	@date		07-Jul-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
ZRESULT ZClient::DeleteTempFile()
{
	BEG_FUNC(NULL);

	/*
	 * For sanity's sake, triple check that this was a temp file.
	 */
	if (mCurrentInfo.mTemp == true)
	{
		ZTRACE(QString("Deleting temporary file [%1]\n").arg(mCurrentInfo.mTempName));
		QFile::remove(mCurrentInfo.mTempName);
	}

	mCurrentInfo.mTemp = false;

	return END_FUNC(ZERR_SUCCESS);
}

/*------------------------------------------------------------------*
 *								PauseWait()							*
 *------------------------------------------------------------------*/
/**
 *	@brief		Checks to see if we're paused and if so, waits for
 *				resume signal.
 *
 *	@author		Josh Williams
 *	@date		14-Sep-2005
 */
/*------------------------------------------------------------------*
 * MODIFICATIONS													*
 *	Date		Description							Author			*
 * ===========	==================================	===============	*
 *																	*
 *------------------------------------------------------------------*/
void ZClient::PauseWait()
{
	BEG_FUNC(NULL);

	if (mPaused)
	{
		ZTRACE("We are paused\n");
		mPauseWait.wait();
	}
	else
		ZTRACE("We are NOT paused\n");
	END_FUNCV();
}

} // End Namespace

/* vi: set ts=4: */
