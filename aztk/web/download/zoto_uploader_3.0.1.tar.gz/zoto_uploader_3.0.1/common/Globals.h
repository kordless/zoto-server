/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 * 06-Jul-2005	Bumped version number to 2.5.2.				   Josh Williams  *
 *                                                                            *
 *============================================================================*/
#if !defined(__GLOBALS_H_INCLUDED__)
#define __GLOBALS_H_INCLUDED__

#include "Platform.h"

/* System Includes */
#ifndef PYTHON_MODULE
#include <typeinfo>
#endif // PYTHON_MODULE

/* Local Includes */
#include "config.h"

#ifndef PYTHON_MODULE
template <class T>
T ZMAX(T a, T b)
{
	return (a > b ? a : b);
}

template <class T>
T ZMIN(T a, T b)
{
	return (a < b ? a : b);
}
#endif // PYTHON_MODULE

#define ZAPI_KEY				"68046733e4659165a4f59a1918cb1408"
#define ZOTO_MAIN_URL			"http://www.$DOMAIN$/"
#define ZOTO_USER_HOME_URL		"http://www.$DOMAIN$/$USER$/"
#define ZOTO_FORGOT_USER_URL	"http://www.$DOMAIN$/general/login/forgot"
#define ZOTO_FORGOT_PSWD_URL	"http://www.$DOMAIN$/general/login/forgot"
#define ZOTO_DOWNLOAD_URL		"http://www.$DOMAIN$/quick_start_guide/"
#define ZOTO_GALLERY_URL		"http://www.$DOMAIN$/$USER$/albums/$ALBUM$"

/* Return codes */
/** AUTH **/
#define ZSP_AUTH_OK			110
#define ZSP_AUTH_BAD		111

/** VERSION **/
#define	ZSP_VERS_GOOD		410
#define ZSP_VERS_OLD		415
#define ZSP_VERS_BAD		420
#define ZSP_VERS_FUBAR		425

/** FILE **/
#define ZSP_FILE_OK			300
#define ZSP_FILE_NO_FLAG	301
#define ZSP_FILE_BAD		304

/** DONE **/
#define ZSP_DONE_OK			350
#define ZSP_DONE_BAD_SUM	351
#define ZSP_DONE_BAD_SYNC	352
#define ZSP_DONE_BAD_SYNC2	353
#define ZSP_DONE_CORRUPT	354
#define ZSP_DONE_BAD_WRITE	355


#define MUTEX_NAME			"ZULU_MUTEX"
#define INVIS_NAME			"ZULU_INVIS_WIN"
#define LOGIN_NAME			"Zoto Sign In"
#define MAIN_NAME			APP_NAME

#endif // __GLOBALS_H_INCLUDED__

/* vi: set ts=4: */
