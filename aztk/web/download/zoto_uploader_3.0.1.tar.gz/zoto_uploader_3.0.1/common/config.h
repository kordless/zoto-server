#define APP_NAME			"Zoto Uploader"
#define ZOTO_VERS_MAJ		3
#define ZOTO_VERS_MIN		0
#define ZOTO_VERS_BUILD		1
#define ZOTO_VERS_STRING	""
#define ZOTO_DOMAIN			"zoto.com"
#define ZSP_HOST			ZOTO_DOMAIN
#define ZSP_PORT			35001
#define ZAPI_HOST			ZOTO_DOMAIN
#define ZAPI_PORT			80
#define ZAPI_PATH			"/RPC2/"
