/*============================================================================*
 *                                                                            *
 *	This file is part of the Zoto Software Suite.  							  *
 *																			  *
 *	Copyright (C) 2004, 2005 Zoto, Inc.  123 South Hudson, OKC, OK  73102	  *
 *																			  *
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation; either version 2 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program; if not, write to the Free Software               *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
 *                                                                            *
 *============================================================================*
 *                                  CHANGELOG                                 *
 *   Date       Description                                    Author         *
 * -----------  ---------------------------------------------  -------------- *
 *                                                                            *
 *============================================================================*/
#if !defined(__TYPES_H_INCLUDED__)
#define __TYPES_H_INCLUDED__

#include "Platform.h"

#ifndef PYTHON_MODULE
#include <qvaluelist.h>
#include <qmap.h>
#include <qintdict.h>
#include <qdict.h>
#include <qpixmap.h>
#endif // PYTHON_MODULE

typedef unsigned int	ZUINT;
typedef unsigned char	ZBYTE;
typedef unsigned long	ZULONG;
typedef unsigned short	ZUSHORT;

#if ZULU_PLATFORM	== PLATFORM_WINDOWS

typedef int             socklen_t;
typedef unsigned int	THREAD_HANDLE;
#define THREAD_FUNC		void
#define THREAD_RET		return

#elif ZULU_PLATFORM	== PLATFORM_MAC

typedef int				SOCKET;
#include <pthread.h>
typedef pthread_t		THREAD_HANDLE;
#define THREAD_FUNC		void*
#define THREAD_RET		return NULL

#elif ZULU_PLATFORM == PLATFORM_LINUX

typedef int				SOCKET;
#include <pthread.h>
typedef pthread_t		THREAD_HANDLE;
#define THREAD_FUNC		void*
#define THREAD_RET		return NULL
#else

#error "Platform undefined"

#endif

//==================================//
//           PACKET TYPES			//
//==================================//
enum eZSPType
{
	ZSP_NONE			= 0x00, //  0
	/* Client Commands */
	ZSP_QUIT			= 0x01, //  1
	ZSP_AUTH			= 0x02, //  2
	ZSP_VERSION			= 0x03, //  3
	ZSP_FLAG			= 0x04, //  4
	ZSP_FILE			= 0x05, //  5
	ZSP_DONE			= 0x06, //  6
	/* Server Responses */
	ZSP_QUIT_RESP		= 0x15, // 21
	ZSP_AUTH_RESP		= 0x16, // 22
	ZSP_VERSION_RESP	= 0x17, // 23
	ZSP_FLAG_RESP		= 0x18, // 24
	ZSP_FILE_RESP		= 0x19, // 25
	ZSP_DONE_RESP		= 0x1A, // 26
	ZSP_HEARTBEAT		= 0x1B, // 27
	/* Error Packet */
	ZSP_ERROR			= 0x32  // 50
};

//==================================//
//           IMAGE TYPES			//
//==================================//
enum ZSPImgTypes
{
	ZSP_JPEG			= 1,
	ZSP_PNG,
	ZSP_GIF,
	ZSP_BMP,
	ZSP_TIFF,
	ZSP_TARGA
};

//==================================//
//		  PACKET DEFINITIONS		//
//==================================//
#pragma pack(1)

typedef struct
{
	ZBYTE	packet_type;
	ZUSHORT	payload_length;
} ZSP_HEADER;

typedef struct
{
	ZSP_HEADER	header;
	char		user_hash[32];
	char		pswd_hash[32];
	/* char[]	user_name */
} ZSP_AUTH_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	ZUSHORT		return_code;
	/* char[]	return_string */
} ZSP_AUTH_RESP_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	ZUSHORT		vers_maj;
	ZUSHORT		vers_min;
	ZUSHORT		vers_build;
	/* char[]	vers_string; */
} ZSP_VERSION_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	ZUSHORT		return_code;
	/* char[]	comment (ex. [beta]) */
} ZSP_VERSION_RESP_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	char		image_id[32];
	int			image_format;
	int			image_size;
	char		image_date[19];
	/* char[]	image_name */
} ZSP_FLAG_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	ZUSHORT		image_needed;
	char		image_id[32];
} ZSP_FLAG_RESP_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	char		image_id[32];
	int			image_format;
	int			image_size;
	char		image_date[19];
	/* char[]	image_name */
} ZSP_FILE_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	char		image_id[32];
	ZUSHORT		return_code;
	/* char[]	return_string */
} ZSP_FILE_RESP_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	char		image_id[32];
} ZSP_DONE_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	char		image_id[32];
	ZUSHORT		return_code;
	/* char[]	return_string */
} ZSP_DONE_RESP_PACKET;

typedef struct
{
	ZSP_HEADER	header;
} ZSP_HEARTBEAT_PACKET;

typedef struct
{
	ZSP_HEADER	header;
	ZUSHORT		error_code;
	/* char[]	error_string */
} ZSP_ERROR_PACKET;

#pragma pack()

//==================================//
//      PACKET SIZE MACROS			//
//==================================//
#define HEADER_SIZE			sizeof(ZSP_HEADER)
#define QUIT_SIZE			sizeof(ZSP_QUIT)
#define AUTH_SIZE			sizeof(ZSP_AUTH_PACKET)
#define VERSION_SIZE		sizeof(ZSP_VERSION_PACKET)
#define FLAG_SIZE			sizeof(ZSP_FLAG_PACKET)
#define FILE_SIZE			sizeof(ZSP_FILE_PACKET)
#define DONE_SIZE			sizeof(ZSP_DONE_PACKET)
#define QUIT_RESP_SIZE		sizeof(ZSP_QUIT_RESP_PACKET)
#define AUTH_RESP_SIZE		sizeof(ZSP_AUTH_RESP_PACKET)
#define VERSION_RESP_SIZE	sizeof(ZSP_VERSION_RESP_PACKET)
#define FLAG_RESP_SIZE		sizeof(ZSP_FLAG_RESP_PACKET)
#define FILE_RESP_SIZE		sizeof(ZSP_FILE_RESP_PACKET)
#define DONE_RESP_SIZE		sizeof(ZSP_DONE_RESP_PACKET)
#define HEARTBEAT_SIZE		sizeof(ZSP_HEARTBEAT_PACKET)
#define ERROR_SIZE			sizeof(ZSP_ERROR_PACKET)

#ifndef PYTHON_MODULE
enum eZErrorCode
{
	ZERR_SUCCESS = 0,
	ZERR_UNKNOWN = 100,		// 100
	ZERR_ALREADY_IN_USE,	// 101
	ZERR_OPEN_FILE,			// 102
	ZERR_INVALID_STATUS,	// 103
	ZERR_READ_FILE,			// 104
	ZERR_BAD_AUTH,          // 105
	ZERR_INVALID_VERSION,   // 106
	ZERR_NEW_VERSION,		// 107
	ZERR_CREATE_SOCKET,     // 108
	ZERR_CONNECT,           // 109
	ZERR_COMM,              // 110
	ZERR_SERVER_ERROR,		// 111
	ZERR_NULL_POINTER,		// 112
	ZERR_DUPLICATE_FILE,	// 113
	ZERR_INVALID_VALUE,		// 114
	ZERR_TIMEOUT,			// 115
	ZERR_RESOLVE_ERROR,		// 116
	ZERR_NET,				// 117
	ZERR_BIND,				// 118
	ZERR_CONN_REFUSED,		// 119
	ZERR_CANCELLED,         // 120
	ZERR_FUBAR_VERSION,		// 121
	ZERR_MAX				// 122
};

/* XMLRPC fault codes */
#define XR_PARSE_ERROR_NOT_WELL_FORMED -32700 
#define XR_PARSE_ERROR_UNSUPPORTED_ENCODING -32701 
#define XR_PARSE_ERROR_INVALID_CHAR -32702 
#define XR_SERVER_ERROR_INVALID_XMLRPC -32600 
#define XR_SERVER_ERROR_METHOD_NOT_FOUND -32601 
#define XR_SERVER_ERROR_INVALID_PARAMS -32602 
#define XR_SERVER_ERROR_INTERNAL_ERROR -32603
#define XR_APPLICATION_ERROR -32500
#define XR_SYSTEM_ERROR -32400
#define XR_TRANSPORT_ERROR -32300

typedef eZErrorCode ZRESULT;


namespace ZOTO
{

enum eZXferStat
{
	XFER_STARTING = 1,
	XFER_ACTIVE,
	XFER_COMPLETE,
	XFER_FAILED
};

/**
 *	@class		ZFileInfo
 *
 *	@brief		Quick and dirty collection of important information about
 *				a file to be uploaded.
 *	@author		Josh Williams (josh@zoto.com)
 *	@version	0.1.0
 *	@date		24-Dec-2005
 */
class ZFileInfo
{
public:
	QString		mName;
	ZULONG		mKey;
	ZULONG		mSize;
	ZUSHORT		mRotate;
	ZULONG		mIndex;
};
typedef QMap<ZULONG, ZFileInfo> ZFileList;

/**
 *	@class		ZXferInfo
 *
 *	@brief		Provides information to callers about file upload progress.
 *	@author		Josh Williams
 *	@version	0.2.0
 *	@date		24-Dec-2004
 */
class _ZuluExport ZXferInfo
{
public:
	ZXferInfo()
		: mBatch(0L), mFile(""), mName(""), mTemp(false), mTempName(""), mSize(0L),
			mID(0), mStatus(XFER_ACTIVE), mProgress(0.0f), mBytes(0L), mSpeed(0.0f),
			mErrcode(ZERR_SUCCESS)
	{
		memset(mMD5, '\0', sizeof(mMD5));
	}
	ZXferInfo(const ZXferInfo& rhs)
		: mBatch(rhs.mBatch), mFile(rhs.mFile.copy()), mName(rhs.mName.copy()), mTemp(rhs.mTemp),
			mTempName(rhs.mTempName.copy()), mSize(rhs.mSize), mID(rhs.mID),
			mStatus(rhs.mStatus), mProgress(rhs.mProgress), mBytes(rhs.mBytes),
			mSpeed(rhs.mSpeed), mErrcode(rhs.mErrcode)
	{
		memcpy(mMD5, rhs.mMD5, sizeof(mMD5));
	}
	~ZXferInfo() {}
public:
	ZULONG		mBatch;		/**< Batch this info packet belongs to */
	QString		mFile;		/**< Absolute file path being uploaded*/
	QString		mName;		/**< Name of the file being reported on */
	bool		mTemp;		/**< Whether or not a temp file was created */
	QString		mTempName;	/**< Name of the temp file, if applicable */
	ZULONG		mSize;		/**< Size of the file, in bytes */
	int			mID;		/**< Unique identifier for this uploaded file */
	char		mMD5[33];	/**< MD5 has of the file's data (Zoto id) */
	eZXferStat	mStatus;	/**< Transfer status */
	double		mProgress;	/**< Upload progress (out of 100) */
	long		mBytes;		/**< Bytes uploaded this push */
	double		mSpeed;		/**< Speed this push */
	ZRESULT		mErrcode;	/**< Error code (result) */
};

/**
 *	@class		ZGalleryInfo
 *
 *	@brief		Stores information about a gallery.
 *	@author		Josh Williams (josh@zoto.com)
 *	@version	0.1.0
 *	@date		29-Mar-2006
 */
class _ZuluExport ZGalleryInfo
{
public:
	QString		mName;		/**< Url name of this gallery */
	QString		mTitle;		/**< Gallery title */
	QString		mDesc;		/**< Gallery description */
	int			mImgCount;	/**< Number of images in this gallery */
	bool		mPwProtect;	/**< Whether or not this gallery is password protected */
	QString		mPassword;	/**< Password for the gallery (if applicable) */
	int			mTemplate;	/**< Template for this gallery uses */
	QString		mUpdated;	/**< Last time this gallery was updated */
	QString		mWrapper;
};
typedef QDict<ZGalleryInfo> ZGalleryMap;

/**
 *	@class		ZTemplateInfo
 *
 *	@brief		Stores information about a template.
 *	@author		Josh Williams (josh@zoto.com)
 *	@version	0.1.0
 *	@date		29-Mar-2006
 */
class ZTemplateInfo
{
public:
	int			mId;
	QString		mName;
	QString		mSampleUrl;
	QPixmap		mThumb;
};
typedef QIntDict<ZTemplateInfo> ZTemplateMap;

/**
 *	@class		ZUserInfo
 *
 *	@brief		Stores information about a user.
 *
 *	@author		Josh Williams (josh@zoto.com)
 *	@version	0.1.0
 *	@date		29-Mar-2006
 */
class ZUserInfo
{
public:
	ZUserInfo()
		: mUserName(""), mUserHash(""), mPswdHash(""), mAuto(false), mRemember(false),
			mPrivate(false), mTagging(false), mGalleries(false), mQuota(0), mUsage(0),
			mImgCount(0), mType("")
		{
			mGalleryMap.setAutoDelete(true);
			mTemplateMap.setAutoDelete(true);
		}
public:
	QString			mUserName;
	QString			mUserHash;
	QString			mPswdHash;
	bool			mAuto;			/**< Auto-login */
	bool			mRemember;		/**< Remember upload settings */
	bool			mPrivate;		/**< Mark photos as private on upload */
	bool			mTagging;		/**< Tag photos on upload */
	bool			mGalleries;		/**< Gallerize images on upload */
	int				mQuota;			/**< Upload quota */
	int				mUsage;			/**< Disk space used online */
	int				mImgCount;		/**< Number of images uploaded */
	QString			mType;			/**< Account type */
	QStringList		mTags;			/**< List of tags */
	ZGalleryMap		mGalleryMap;	/**< List of galleries */
	ZTemplateMap	mTemplateMap;	/**< List of gallery templates */
	QStringList		mWrappers;		/**< List of gallery wrappers */
};
typedef QIntDict<ZUserInfo> ZUserMap;

} // End Namespace
#endif // PYTHON_MODULE

#endif // __TYPES_H_INCLUDED__

/* vi: set ts=4: */
